/**
 * @file lcm.h
 * @brief LCM interface.
 * @author Michael Kaess
 * @version $Id: Lcm.h 4232 2011-04-02 20:18:18Z hordurj $
 *
 * [insert iSAM license]
 *
 */

#pragma once

#include <vector>
#include <list>

#include <lcm/lcm.h>

#include <isam/Slam.h>
#include <isam/Pose3d.h>

class Lcm {
  lcm_t* lcm;
public:
  /**
   * Default constructor, sets up lcm connection.
   */
  Lcm();

  ~Lcm();

  void send_reset() const;

  /**
   * Sends a set of nodes (poses, landmarks...).
   * @param nodes Vector of nodes.
   * @param id Collection id (also determines color).
   * @param name Collection name.
   * @param type Type of object (pose, tree etc.)
   */
  void send_nodes(const std::vector<isam::Pose3d, Eigen::aligned_allocator<isam::Pose3d> >& nodes,
      int id,
      char* name,
      int type) const;

  /**
   * Sends a set of links (measurements, odometry constraints...).
   * @param links Vector of links.
   * @param id Collection id (also determines color).
   * @param name Collection name.
   * @param collection1 Links start from elements of this collection id.
   * @param collection2 Links end at elements of this collection id.
   */
  void send_links(const std::vector<std::pair<int,int> >& links,
      int id, char* name, int collection1, int collection2) const;

  /**
   * Sends a set of covariances (2D or 3D)
   * @param covariances Covariances matrices in same order as elements they refer to.
   * @param id Collection id (also determines color).
   * @param name Collection name.
   * @param collection Collection number that the covariances refer to.
   * @param is_3d True if 3D covariances.
   */
  void send_covariances(const std::list<Eigen::MatrixXd>& covariances,
      int id, char* name, int collection, bool is_3d) const;

};
