/**
 * @file Optimizer.cpp
 * @brief Class implementing batch and incremental nonlinear equation solvers
 * @author David Rosen
 * @author Michael Kaess
 *
 * [insert iSAM license]
 *
 */

#include "isam/Optimizer.h"
#include "isam/OptimizationInterface.h"

using namespace std;
using namespace Eigen;

namespace isam {

/**Should we use the Powell's Dog-Leg stopping criteria for all of the batch algorithms, or should we allow each algorithm to have its own stopping criteria?
 * NB:  Using the PDL stopping criteria can lead to slower performance, since it results in non-essential computations to find the gradient direction vector.
 */

//#define USE_PDL_STOPPING_CRITERIA


//UTILITY FUNCTIONS

void Optimizer::relinearize(const Properties& prop) {
  //We're going to relinearize about the current estimate.
  function_system.estimate_to_linpoint();

  // prepare factorization
  SparseSystem jac = function_system.jacobian();

  // factorization and new rhs based on new linearization point will be in _R
  VectorXd h_gn = compute_gauss_newton_step(jac, &function_system._R); // modifies _R

  if(prop.method == DOG_LEG) {
    //Compute the gradient and cache it.
    gradient = mul_SparseMatrixTrans_Vector(jac, jac.rhs());

    //compute alpha
    double alpha = (gradient.squaredNorm()) / (jac * gradient).squaredNorm();

    //Compute dog-leg step.
    VectorXd h_dl = compute_dog_leg(alpha, -gradient, -h_gn, Delta); //NOTE:  Here we use -h_gn because of the weird sign change in the exmap functions.

    //Update the estimate.
    function_system.apply_exmap(-h_dl);  //NOTE:  Here we use -h_dl because of the weird sign change in the exmap functions.

    //Update the estimate of Delta
    double L_0, L_h, F_0, F_h;

    F_0 = L_0 = jac.rhs().squaredNorm(); //Get the value of the sum-of-squared errors at the current linearization point.

    F_h = function_system.weighted_errors(ESTIMATE).squaredNorm(); //Get the value of the sum-of-squared errors at the new estimate.

    L_h = (jac.rhs() + jac*h_dl).squaredNorm();  //Get the value of the linearized approximation to the sum-of-squared errors at the new estimate.

    double rho = (F_0 - F_h) / (L_0 - L_h);  //Compute gain ratio.

    if(rho < 0)
    {
      //The sum-of-squared errors is actually GREATER at the new estimate, so DO NOT ACCEPT IT; overwrite new estimate with current linearization point.
      function_system.linpoint_to_estimate();
    }
    if(rho < .25)
    {
      Delta /= 2;
    }
    if(rho > .75)
    {
      Delta = max(Delta, 3*h_dl.norm());
    }
  } //Dog-leg update

  else //We're using straight-up Gauss-Newton, so just apply the update directly.
  {
    function_system.apply_exmap(h_gn);
  }
}

void Optimizer::permute_vector(const VectorXd& v, VectorXd& p, const int* permutation) {
  for(int i = 0; i < v.size(); i++)
  {
    p(permutation[i]) = v(i);
  }
}




VectorXd Optimizer::compute_gauss_newton_step(const SparseSystem& jacobian,
                                              SparseSystem* R, double lambda) {
  VectorXd delta_ordered;
  _cholesky->factorize(jacobian, &delta_ordered, lambda);
  if (R != NULL) {
    _cholesky->get_R(*R);
  }

  // delta has new ordering,
  // need to return result with default ordering
  int nrows = delta_ordered.size();
  VectorXd delta(nrows);
  permute_vector(delta_ordered, delta, _cholesky->get_order());

  return delta;
}


VectorXd Optimizer::compute_dog_leg(double alpha, const VectorXd& h_sd,
                                    const VectorXd& h_gn, double delta) {
  if (h_gn.norm() <= delta)
  {
    return h_gn;
  }
  else if ((alpha * (h_sd.norm())) >= delta)
  {
    return (delta / h_sd.norm()) * h_sd;
  }
  else
  {
    // complicated case: calculate intersection of trust region with
    // line between Gauss Newton and steepest descent solutions
    VectorXd a = alpha * h_sd;
    VectorXd b = h_gn;
    double c = a.dot(b - a);
    double b_a_norm2 = (b - a).squaredNorm();
    double a_norm2 = a.squaredNorm();
    double delta2 = delta * delta;
    double sqrt_term = sqrt(c * c + b_a_norm2 * (delta2 - a_norm2));
    double beta;
    if (c <= 0)
    {
      beta = (-c + sqrt_term) / b_a_norm2;
    }
    else
    {
      beta = (delta2 - a_norm2) / (c + sqrt_term);
    }
    return (alpha * h_sd + beta * (h_gn - alpha * h_sd));
  }
}



bool Optimizer::powells_dog_leg_update(double epsilon1, double epsilon3,
    SparseSystem& jacobian, VectorXd& f_x, VectorXd& grad) {
  jacobian = function_system.jacobian();
  f_x = function_system.weighted_errors(LINPOINT);
  grad = mul_SparseMatrixTrans_Vector(jacobian, f_x); // todo: replace internal with cholmod? - mul_SparseMatrixTrans_Vector
  return (f_x.lpNorm<Eigen::Infinity> () <= epsilon3) || (grad.lpNorm<
      Eigen::Infinity> () <= epsilon1);
}



//BEGIN OPTIMIZATION FUNCTIONS


//Gauss-Newton

void Optimizer::gauss_newton(const Properties& prop, int* num_iterations) {
  //Batch optimization
	int num_iter = 0;

	function_system.estimate_to_linpoint();  //Set the new linearization point to be the current estimate.
	SparseSystem jacobian = function_system.jacobian(); //Compute Jacobian about current estimate.

	//Get the current error residual vector
	VectorXd r = function_system.weighted_errors(LINPOINT);

#ifdef USE_PDL_STOPPING_CRITERIA
	//Compute the current gradient direction vector
	VectorXd g =  mul_SparseMatrixTrans_Vector(jacobian, r);
#else
	double error = r.squaredNorm();
	double error_new;
	double error_diff = prop.epsilon_rel*error + 1;  //We haven't computed a step yet, so this initialization is to ensure that we never skip over the while loop as a result of failing change-in-error check
#endif

	VectorXd delta = compute_gauss_newton_step(jacobian);  //Compute Gauss-Newton step h_{gn} to get to the next estimated optimizing point.

	while (
			//We ALWAYS use these criteria
			((prop.max_iterations <= 0) || (num_iter < prop.max_iterations))
			&& (delta.norm() > prop.epsilon2)

#ifdef USE_PDL_STOPPING_CRITERIA  //PDL stopping criteria

			&&  (r.lpNorm<Eigen::Infinity>() > prop.epsilon3)
			&& (g.lpNorm<Eigen::Infinity>() > prop.epsilon1)

#else  //Custom stopping criteria for GN
			&& (error > prop.epsilon_abs)
			&& (fabs(error_diff) > prop.epsilon_rel * error)
#endif

			) //end while conditional
  {
    num_iter++;

    function_system.apply_exmap(delta);  //Apply the Gauss-Newton step h_{gn} to
    function_system.estimate_to_linpoint();  //Set the new linearization point to be the current estimate.
    jacobian = function_system.jacobian();  //Relinearize about the new current estimate
    r = function_system.weighted_errors(LINPOINT);  //Compute the error residual vector at the new estimate.

#ifdef USE_PDL_STOPPING_CRITERIA
    g = mul_SparseMatrixTrans_Vector(jacobian, r);
#else
    //Update the error difference in errors between the previous and current estimates.
    error_new = r.squaredNorm();
    error_diff = error - error_new;
    error = error_new;  //Record the absolute error at the current estimate
#endif

    delta = compute_gauss_newton_step(jacobian);  //Compute Gauss-Newton step h_{gn} to get to the next estimated optimizing point.
    if (!prop.quiet)
    {
      cout << "Iteration " << num_iter << ": residual ";

#ifdef USE_PDL_STOPPING_CRITERIA
      cout << r.squaredNorm();
#else
      cout << error;
#endif
      cout << endl;
    }
  }//end while

  if (num_iterations != NULL)
  {
    *num_iterations = num_iter;
  }
  _cholesky->get_R(function_system._R);
}

void Optimizer::levenberg_marquardt(const Properties& prop, int* num_iterations)
{
  int num_iter = 0;
  double lambda = prop.lm_lambda0;
  function_system.estimate_to_linpoint(); // using linpoint as current estimate below

  //Get the current Jacobian at the linearization point
  SparseSystem jacobian = function_system.jacobian();

  //Get the error residual vector at the current linearization point
  VectorXd r = function_system.weighted_errors(LINPOINT);

  double error = r.squaredNorm();  //Record the absolute sum-of-squares error (i.e., objective function value) here.


#ifdef USE_PDL_STOPPING_CRITERIA
  //Compute the gradient direction vector at the current linearization point
  VectorXd g = mul_SparseMatrixTrans_Vector(jacobian, r);
#endif

  double error_diff, error_new;

  // solve at J'J + lambda*diag(J'J)
  VectorXd delta = compute_gauss_newton_step(jacobian, &function_system._R, lambda);

  while (
		  //We ALWAYS use these stopping criteria
		  ((prop.max_iterations <= 0) || (num_iter < prop.max_iterations))
		  && (delta.norm() > prop.epsilon2)

#ifdef USE_PDL_STOPPING_CRITERIA
		 &&  (r.lpNorm<Eigen::Infinity>() > prop.epsilon3)
		 && (g.lpNorm<Eigen::Infinity>() > prop.epsilon1)
#else
		 && (error > prop.epsilon_abs)
#endif
		  )//end while conditional
  {
    num_iter++;

    function_system.linpoint_to_estimate(); // remember the last accepted linearization point
    function_system.self_exmap(delta);  //Apply the delta vector DIRECTLY TO THE LINEARIZATION POINT!
    error_new = function_system.weighted_errors(LINPOINT).squaredNorm();
    error_diff = error - error_new;
    //  feedback
    if (!prop.quiet)
    {
      cout << "LM Iteration " << num_iter << ": (lambda=" << lambda
          << ") ";
      if (error_diff > 0.)
      {
        cout << "residual: " << error_new << endl;
      }
      else
      {
        cout << "rejected" << endl;
      }
    }
    // decide if acceptable
    if (error_diff > 0.)
    {

#ifndef USE_PDL_STOPPING_CRITERIA
    	if(error_diff < prop.epsilon_rel * error)
    	{
    		break;
    	}
#endif

      //Update lambda
      lambda /= prop.lm_lambda_factor;

      error = error_new;  //Record the error at the newly-accepted estimate.

      jacobian = function_system.jacobian();  //Relinearize around the newly-accepted estimate.

#ifdef USE_PDL_STOPPING_CRITERIA
      r = function_system.weighted_errors(LINPOINT);
      g = mul_SparseMatrixTrans_Vector(jacobian, r);
#endif
    }
    else
    {
      // reject new estimate
      lambda *= prop.lm_lambda_factor;
      function_system.estimate_to_linpoint(); // restore previous estimate
    }

    //Compute the step for the next iteration.
    delta = compute_gauss_newton_step(jacobian, &function_system._R, lambda);

  } //end while

  if (num_iterations != NULL)
  {
    *num_iterations = num_iter;
  }
  function_system.linpoint_to_estimate(); // copy current estimate contained in linpoint
}



//Powell's Dog-Leg




void Optimizer::powells_dog_leg(int* num_iterations, double delta0, int max_iterations,
                                double epsilon1, double epsilon2, double epsilon3) {
  // Batch optimization
  int num_iter = 0;
  // current estimate is used as new linearization point
  function_system.estimate_to_linpoint(); // todo: if R is not updated at all (ie found==true before first iteration below), we return the wrong linearization point...
  //^Should now be fixed using bool run_once; // todo: ??


  double delta = delta0;
  SparseSystem jacobian(1, 1);
  VectorXd f_x;
  VectorXd grad;

  bool found = powells_dog_leg_update(epsilon1, epsilon3, jacobian, f_x, grad);

  while ((not found) && (max_iterations == 0 || num_iter < max_iterations))
  {
    num_iter++;
    cout << "PDL Iteration " << num_iter << " residual: "
        << f_x.squaredNorm() << endl;
    // compute alpha
    double alpha = grad.squaredNorm()
            / (jacobian * grad).squaredNorm(); // todo: replace internal with cholmod? - operator(*)
    // steepest descent
    VectorXd h_sd = -grad;
    // solve Gauss Newton
    VectorXd h_gn = compute_gauss_newton_step(jacobian, &function_system._R);
    //    cout << "Gauss-Newton: " << endl << h_gn << endl;
    //    cout << "Steepest: " << endl << h_sd << endl;
    // compute dog leg h_dl
    function_system.linpoint_to_estimate(); //x0 = x; // remember (and return) linearization point of R
    VectorXd h_dl = compute_dog_leg(alpha, h_sd, h_gn, delta);
    // evaluate new solution, update estimate and trust region
    if (h_dl.norm() <= epsilon2)
    { // todo   *(x.norm() + epsilon2)) {
      found = true;
    }
    else
    {
      // new estimate
      //      cout << "exmapping with: " << endl << h_dl << endl;
      function_system.self_exmap(h_dl); // change linearization point directly (original LP saved in estimate)
      // calculate gain ratio rho
      VectorXd f_x_new = function_system.weighted_errors(LINPOINT);
      double L_0 = f_x.squaredNorm();
      double L_h_dl = (f_x + jacobian * h_dl).squaredNorm();
      //      cout << f_x.squaredNorm() << "-" << f_x_new.squaredNorm() << "  " << L_0 << "-" << L_h_dl << endl;
      double rho = (f_x.squaredNorm() - f_x_new.squaredNorm()) / (L_0
          - L_h_dl); // dropped 0.5 from all terms
      //      cout << "rho: " << rho << endl;
      if (rho > 0)
      {
        // accept new estimate
        cout << "accepted" << endl;
        f_x = f_x_new; // todo: no need to recalculate f_x below
        found = powells_dog_leg_update(epsilon1, epsilon3,
            jacobian, f_x, grad);
      }
      else
      {
        // reject new estimate, overwrite with last saved one
        cout << "rejected" << endl;
        function_system.estimate_to_linpoint();
      }
      if (rho > 0.75)
      {
        delta = max(delta, 3.0 * h_dl.norm());
        //        cout << "delta-max " << delta << endl;
      }
      else if (rho < 0.25)
      {
        delta *= 0.5;
        //        cout << "delta*0.5 " << delta << endl;
        found = (delta <= epsilon2); // todo   *(x.norm() + epsilon2));
      }
    }
  }
  if (num_iterations)
  {
    *num_iterations = num_iter;
  }
  // overwrite potentially rejected linearization point with last saved one (could be identical if it was accepted in the last iteration)

  function_system.swap_estimates();

}


void Optimizer::augment_sparse_linear_system(SparseSystem& W, const Properties& prop)
{
  if(prop.method == DOG_LEG)
  {
    //We're using the incremental version of Powell's Dog-Leg, so we need to form the updated gradient.

    const VectorXd& f_new = W.rhs();

    //Allocate the new gradient vector
    VectorXd g_new (W.num_cols());

    //Compute W^T \cdot f_new
    VectorXd increment = mul_SparseMatrixTrans_Vector(W, f_new);


    //Set g_new = (g_old 0)^T + W^T f_new.
    g_new.head(gradient.size()) = gradient + increment.head(gradient.size());
    g_new.tail(W.num_cols() - gradient.size()) = increment.tail(W.num_cols() - gradient.size());

    //Cache the new gradient vector
    gradient = g_new;
  }

  //Apply Givens to QR factorize the newly augmented sparse system.
  for (int i=0; i<W.num_rows(); i++)
  {
    SparseVector new_row = W.get_row(i);
    function_system._R.add_row_givens(new_row, W.rhs()(i));
  }
}


void Optimizer::update_estimate(const Properties& prop) {
  //Solve for the Gauss-Newton step.
  VectorXd h_gn_reordered = function_system._R.solve();
  VectorXd h_gn(h_gn_reordered.size());

  //Obsoleted; use permute_vector() here
  /**
  for (int i=0; i<deltaReordered.size(); i++)
  {
  h_gn(i) = deltaReordered(function_system._R.a_to_r()[i]);
  }
  */

  permute_vector(h_gn_reordered, h_gn, function_system._R.r_to_a()); //Permute from R-ordering to J ordering.

  if(prop.method == GAUSS_NEWTON)
  {
    function_system.apply_exmap(h_gn);
  }
  else  //method == DOG_LEG
  {
    //Compute alpha.  Note that since the variable ordering of the factor R differs from that of the original Jacobian J,
    //we must first rearrange the ordering of the elements in the gradient.

    VectorXd reordered_gradient(gradient.size());

    permute_vector(gradient, reordered_gradient, function_system._R.a_to_r());  //Permute from J-ordering to R-ordering

    double alpha = (gradient.squaredNorm()) / (function_system._R * reordered_gradient).squaredNorm();


     //NOTE:  The negatives prepended to "compute_dog_leg()" and "h_gn" are due to the weird sign change in the exmap functions.
    function_system.apply_exmap(-compute_dog_leg(alpha, -gradient, -h_gn, Delta));
  }
}


void Optimizer::batch_optimize(const Properties& prop, int* num_iterations) {

  switch (prop.method)
    {
    case (GAUSS_NEWTON):
      {
        gauss_newton(prop, num_iterations);
        break;
      }
    case(DOG_LEG):
      {
        double delta0 = 1.0;
        powells_dog_leg(num_iterations, delta0, prop.max_iterations, prop.epsilon1, prop.epsilon2, prop.epsilon3); // modifies x0,R
        break;
      }
    case (LEVENBERG_MARQUARDT):
      {
        levenberg_marquardt(prop, num_iterations);

        break;
      }
    }

}

}
