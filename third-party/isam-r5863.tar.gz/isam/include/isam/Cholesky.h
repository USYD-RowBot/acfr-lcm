/**
 * @file Cholesky.h
 * @brief Cholesky batch factorization using SuiteSparse by Tim Davis.
 * @author Michael Kaess
 * @version $Id: Cholesky.h 4133 2011-03-22 20:40:38Z kaess $
 *
 * [insert iSAM license]
 *
 */

#pragma once

#include <Eigen/Dense>

#include "SparseSystem.h"

namespace isam {

class Cholesky {
public:
  virtual ~Cholesky() {}

  virtual void factorize(const SparseSystem& Ab, Eigen::VectorXd* delta = NULL, double lambda = 0.) = 0;
  virtual void get_R(SparseSystem& R) = 0;
  virtual int* get_order() = 0;

  static Cholesky* Create();
protected:
  Cholesky() {}
};

}
