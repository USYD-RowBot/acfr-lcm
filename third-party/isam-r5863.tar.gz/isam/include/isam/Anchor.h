/**
 * @file slam2d.h
 * @brief Provides specialized nodes and factors for 2D SLAM.
 * @author Michael Kaess
 * @author Hordur Johannsson
 * @version $Id: Anchor.h 5797 2011-12-07 03:50:41Z kaess $
 *
 * [insert iSAM license]
 *
 */

#pragma once

#include <string>
#include <sstream>
#include <Eigen/Dense>

#include "Node.h"
#include "Factor.h"
#include "Pose2d.h"
#include "Point2d.h"
//#include "slam2d.h"
//#include "slam3d.h"
#include "Slam.h"

namespace isam {

typedef NodeT<Pose2d> Pose2d_Node;

/**
 * A anchor node
 */
class Anchor2d_Node : public Pose2d_Node {
public:
  Anchor2d_Node(Slam* slam);
  ~Anchor2d_Node();

  /**
   * Add a prior to the anchor. The prior will be removed
   * if this anchor is merged with another anchor's frame.
   */
  void set_prior();

  /**
   * Add a new anchor to this frame.
   */
  void add_anchor(Anchor2d_Node* a);

  /**
   * Merges the node with anchor a.
   *
   * @param a the node to merge with.
   * @param old_origin the pose of this frame in the new frame.
   *
   * Usage: b.merge(a);
   *
   * All anchors in a's frame will be merged with the b's frame.
   *
   */
  void merge(Anchor2d_Node* a, Pose2d old_origin);

  Anchor2d_Node* parent() { return _parent; }
private:
  Anchor2d_Node* _parent;
  std::vector<Anchor2d_Node*> _childs;
  Factor* _prior;
  Slam* _slam;
};

}


