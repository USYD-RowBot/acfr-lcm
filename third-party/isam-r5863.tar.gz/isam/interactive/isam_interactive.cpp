/**
 * @file isam.cpp
 * @brief Main isam program.
 * @author Michael Kaess
 * @version $Id: isam.cpp 4307 2011-04-10 14:05:06Z kaess $
 *
 * [insert iSAM license]
 *
 */

// for writing out fully converged least-squares solution
//#define GROUND_TRUTH

#include <iostream>
#include <map>
#include <vector>

#include <Eigen/Dense>

#include <isam/isam.h>
#include <isam/slam2d.h>

#include "slam_parser/interface/parser_interface.h"
#include "slam_parser/interface/abstract_slam_interface.h"

#include "fast_output.h"

using namespace std;
using namespace isam;
using namespace Eigen;

Slam slam;
vector<Pose2d_Node*> _nodes;
vector<Pose3d_Node*> _nodes3;
unsigned int _step;

class SlamInterface : public SlamParser::AbstractSlamInterface
{
public:
  SlamInterface()
  {
    _verbose = false;
    _is_3d = false;
  }

  bool addNode(const std::string& tag, int id, int dimension, const std::vector<double>& values)
  {
    if (_verbose) {
      cerr << "ADDING NODE " << tag << " id=" << id << " dim=" << dimension;
      if (values.size()) {
        cerr << "\tpose=";
        for (size_t i = 0; i < values.size(); ++i)
          cerr << " " << values[i]; 
      }
      cerr << endl;
    }

    if (!_is_3d && dimension==6) {
      _is_3d = true;
    }

    // todo: ignores optional values for initialization
    if (_is_3d) {
      Pose3d_Node* new_pose_node = new Pose3d_Node();
      _nodes3.resize(_step+1);
      _nodes3[_step] = new_pose_node;
      slam.add_node(new_pose_node);
    } else {
      Pose2d_Node* new_pose_node = new Pose2d_Node();
      _nodes.resize(_step+1);
      _nodes[_step] = new_pose_node;
      slam.add_node(new_pose_node);
    }
    if (_step==0) {
      // add prior - todo: only on first node for now
      if (_is_3d) {
        Pose3d pose0;
        Noise noise = SqrtInformation(100. * Matrix<double, 6, 6>::Identity());
        Pose3d_Factor* prior = new Pose3d_Factor(_nodes3[0], pose0, noise);
        slam.add_factor(prior);
      } else {
        Pose2d pose0;
        Noise noise = SqrtInformation(100. * Matrix<double, 3, 3>::Identity());
        Pose2d_Factor* prior = new Pose2d_Factor(_nodes[0], pose0, noise);
        slam.add_factor(prior);
      }
    }
    _step++; // todo: should be in sync with id

    return true;
  }

  bool addEdge(const std::string& tag, int id, int dimension, int v1, int v2, const std::vector<double>& measurement, const std::vector<double>& information)
  {
    if (_verbose) {
      cerr << "ADDING EDGE " << tag << " id=" << id << " dim=" << dimension
           << " (" << v1 << " <-> " << v2 << ")" << " measurement=";
      for (size_t i = 0; i < measurement.size(); ++i)
        cerr << " " << measurement[i]; 
      cerr << " information=";
      for (size_t i = 0; i < information.size(); ++i)
        cerr << " " << information[i]; 
      cerr << endl;
    }

    if (dimension==6) {
      MatrixXd infmat(6,6);
      int i = 0;
      for (int r=0; r<6; r++) {
        int _r = (r<3)?r:(8-r); // swap yaw/pitch/roll
        for (int c=r; c<6; c++) {
          int _c = (c<3)?c:(8-c);
          infmat(_r,_c) = information[i];
          if (_r!=_c) {
            infmat(_c,_r) = information[i];
          }
          i++;
        }
      }
      // note: yaw/pitch/roll order in iSAM
      Pose3d measure(measurement[0], measurement[1], measurement[2],
                     measurement[5], measurement[4], measurement[3]);
      Pose3d_Pose3d_Factor* factor = new Pose3d_Pose3d_Factor(_nodes3[v1], _nodes3[v2], measure, Information(infmat));
      slam.add_factor(factor);
    } else {
      const vector<double>& i = information;
      Matrix3d infmat;
      infmat <<
        i[0], i[1], i[2],
        i[1], i[3], i[4],
        i[2], i[4], i[5];
      Pose2d measure(measurement[0], measurement[1], measurement[2]);
      Pose2d_Pose2d_Factor* factor = new Pose2d_Pose2d_Factor(_nodes[v1], _nodes[v2], measure, Information(infmat));
      slam.add_factor(factor);
    }

    return true;
  }

  bool fixNode(const std::vector<int>& nodes)
  {
    if (_verbose) {
      cerr << "FIXING NODE";
      for (size_t i = 0; i < nodes.size(); ++i)
        cerr << " " << nodes[i]; 
      cerr << endl;
    }

    return true;
  }

  inline void printVertex(size_t i) {
    static char buffer[5000];
    if (_is_3d) {
      const Pose3d& p = _nodes3[i]->value();
#if 1
      char* b = buffer;
      memcpy(b, "VERTEX_XYZRPY ", 14);
      b += 14;
      b += modp_itoa10(i, b);
      *b++ = ' ';
      b += modp_dtoa(p.x(), b, 6);
      *b++ = ' ';
      b += modp_dtoa(p.y(), b, 6);
      *b++ = ' ';
      b += modp_dtoa(p.z(), b, 6);
      *b++ = ' ';
      b += modp_dtoa(p.roll(), b, 6);
      *b++ = ' ';
      b += modp_dtoa(p.pitch(), b, 6);
      *b++ = ' ';
      b += modp_dtoa(p.yaw(), b, 6);
      *b++ = '\n';
      cout.write(buffer, b - buffer);
#else
      printf("VERTEX_XYZRPY %li %g %g %g %g %g %g\n", i,
             p.x(), p.y(), p.z(), p.roll(), p.pitch(), p.yaw());
#endif
    } else {
      const Pose2d& p = _nodes[i]->value();
#if 1
      char* b = buffer;
      memcpy(b, "VERTEX_XYT ", 11);
      b += 11;
      b += modp_itoa10(i, b);
      *b++ = ' ';
      b += modp_dtoa(p.x(), b, 6);
      *b++ = ' ';
      b += modp_dtoa(p.y(), b, 6);
      *b++ = ' ';
      b += modp_dtoa(p.t(), b, 6);
      *b++ = '\n';
      cout.write(buffer, b - buffer);
#else
      printf("VERTEX_XYT %li %g %g %g\n", i, v.x(), v.y(), v.t());
#endif
    }
  }

  bool queryState(const std::vector<int>& nodes)
  {
    if (_verbose) {
      cerr << "QUERY STATE";
      for (size_t i = 0; i < nodes.size(); ++i)
        cerr << " " << nodes[i]; 
      cerr << endl;
    }

    // actually output the values to the evaluator
    // If a SLAM algorithm is running we would need to copy its estimate
    cout << "BEGIN" << endl;
    if (nodes.size() == 0) {
      // print all nodes
      size_t n = (_is_3d)?_nodes3.size():_nodes.size();
      for (size_t i = 0; i < n; i++) {
        printVertex(i);
      }
    } else {
      for (size_t i = 0; i < nodes.size(); ++i) {
        printVertex(nodes[i]);
      }
    }
    cout << "END" << endl;

    return true;
  }

  bool solveState()
  {
    if (_verbose) {
      cerr << "SOLVE STATE" << endl;
    }
#ifdef GROUND_TRUTH
    slam.batch_optimization();
#else
    slam.update();
#endif

    return true;
  }

protected:

  bool _verbose;

  bool _is_3d;

};

int main(int argc, char* argv[]) {

  Properties prop;
  prop.verbose = false;
  prop.quiet = true;
#ifdef GROUND_TRUTH
  prop.max_iterations = 100;
  prop.epsilon = 1e-8;
  prop.epsilon_abs = 0.00001;
  prop.epsilon_rel = 0.000000001;
  prop.quiet = false;
  //  prop.method = LEVENBERG_MARQUARDT;
#endif
  slam.set_properties(prop);
 
  SlamInterface slamInterface;
  SlamParser::ParserInterface parserInterface(&slamInterface);

  while (parserInterface.parseCommand(cin))
  {
    // do something additional if needed
  }

  return 0;  
}
