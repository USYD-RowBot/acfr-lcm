import os
import sys
import numpy
import scipy.stats

def load_file(filename):
    fd = open(filename) #open in read-only mode.
    string_data = (fd.read()).split()  #Read the entire contents of the file as a single string, and then split it into a list of tokens delimited by any whitespace.
    numeric_data = map(float, string_data)  #Construct a new list by iterating through the list 'string_data' and applying the function 'float()' to each element (i.e,. convert from a list of strings to a list containing the /numerical values/ of those strings.
    fd.close()
    #Now make this into a NumPy array
    np_array = numpy.array(numeric_data, dtype=float)
    return np_array

def process_file(filename):
    #Get the numerical values stored in this file as a NumPy array
    arr = load_file(filename)

    #Compute some elementary statistics from this data and store in a list.
    stats = []
    stats.append(arr.min())
    stats.append(arr.max())
    stats.append(arr.mean())
    stats.append(numpy.median(arr))
    stats.append(arr.std())
    
    #Now apply D'Agostino and Pearson's omnibus test for normality ()
    (k2, p) = scipy.stats.normaltest(arr)
    stats.append(k2)
    stats.append(p)

    #Now get the name that we should use for referencing this data by scraping it from the filename
    (head, tail) = os.path.split(filename)
    (base_filename, ext) = os.path.splitext(tail)

    #Return the tuple of the base name of the file from which this array was taken, and the list of statistical data calculated from the file contents.
    return (base_filename, stats)

def print_stats(name, stats):
    hr_string = name.replace('_',' ') + " statistics:"  #Replace underscores with spaces and add a colon
    print hr_string
    print "Min: %f" % stats[0]
    print "Max: %f" % stats[1]
    print "Mean: %f" % stats[2]
    print "Median: %f" % stats[3]
    print "Standard deviation: %f" % stats[4]
    print "D'Agostino and Pearson's Omnibus statistic: %f" % stats[5]
    print "p-value for normal distribution (null hypothesis): %E" % stats[6]
    print ""
    
def process_sublist(directory, sublist):
     for file_name in sublist:
        target_file = os.path.join(directory, file_name)
        (base_name, stats) = process_file(target_file)
        print_stats(base_name, stats)    

if __name__=="__main__":
    
    #Get the name of the directory in which the files are kept.
    if len(sys.argv) == 1:
        directory = os.getcwd()
    elif len(sys.argv) == 2:
        directory = sys.argv[1]
    else:
        print "Usage:  python " + sys.argv[0] + " <directory of files to process>"
        exit(1);


    print "Examining files in directory %s" % directory
    print ""

    dir_list = os.listdir(directory)
    
    #os.listdir returns a list of files and subdirectories in the current directory; however, it does not return them in anyparticular order.  We want to process the files in an order that makes the output from this program easier to parse (i.e., that groups like types of data together in the output stream).  We also want to do this in a way that is 'pythonic'

    #First, return only those names that point to actual files (i.e., no directories)
    #Note the use of the inline lambda function definition: pythonic :-D!
    file_list = filter(lambda file_name :  os.path.isfile(os.path.join(directory, file_name)), dir_list)

    #Process the batch results first

    print "BATCH RESULTS:\n"
    print "BACTH ACCURACY RESULTS:\n"
    #Output batch chi-squares results
    batch_chi_squares_files = filter(lambda file_name : (file_name.find("chi") > -1) and (file_name.find("batch") > -1), file_list)
    process_sublist(directory, batch_chi_squares_files)

    #Output batch SSE results
    batch_SSE_files = filter(lambda file_name: (file_name.find("SSE") >-1) and (file_name.find("batch") > -1), file_list)
    process_sublist(directory, batch_SSE_files)

    print "BATCH TIMING RESULTS:\n"
    #Output batch timing results
    batch_timing_files = filter(lambda file_name: (file_name.find("time") >-1) and (file_name.find("batch") > -1), file_list)
    process_sublist(directory, batch_timing_files)
    
    #Also output the number of iterations.
    batch_iterations_files = filter(lambda file_name : file_name.find("iterations") > -1, file_list)
    process_sublist(directory, batch_iterations_files)

    print "INCREMENTAL RESULTS:\n"
    print "INCREMENTAL ACCURACY RESULTS:\n"
    
    incremental_chi_squares_files = filter(lambda file_name : (file_name.find("chi") >-1 ) and (file_name.find("incremental" ) > -1), file_list)
    process_sublist(directory, incremental_chi_squares_files)

    incremental_SSE_files =  filter(lambda file_name : (file_name.find("SSE") >-1 ) and (file_name.find("incremental") > -1), file_list)
    process_sublist(directory, incremental_SSE_files)
    
    print "INCREMENTAL TIMING RESULTS:\n"
    
    incremental_timing_files = filter(lambda file_name : (file_name.find("time") > -1) and (file_name.find("incremental") > -1), file_list)
    process_sublist(directory, incremental_timing_files)
