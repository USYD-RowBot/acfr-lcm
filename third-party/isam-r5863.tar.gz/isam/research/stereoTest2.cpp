/**
 * @file stereoTest.cpp
 * @brief Test stereo code.
 * @author Michael Kaess
 * @version $Id: stereoTest2.cpp 5821 2011-12-13 23:18:06Z kaess $
 */

// Simulates linear motion of a stereo camera, and pairwise
// observation of sets of points. Points are randomly distributed in
// image space and for a given disparity range that starts at 0 for
// homogeneous and at a positive value for nonhomogeneous
// parameterization. Noise is added to all measurements.


#include <isam/isam.h>
#include <isam/slam_stereo.h>

//#define VISUALIZE

#ifdef VISUALIZE
#include <lcm/lcm.h>
#include <visualization/viewer.hpp>
#include <visualization/pointcloud.hpp>
#endif

using namespace std;
using namespace isam;
using namespace Eigen;

const int SIZE_X = 640;
const int SIZE_Y = 480;

const int NUM_POINTS = 200;
const int NUM_CAMERAS = 100;

const bool HOMOGENEOUS = true;

const bool ADD_NOISE = true;

const double PIXEL_SIGMA = 0.5;

const Pose3d origin(0., 0., 0., 0., 0., 0.);

const double f = 370;
const Vector2d pp(SIZE_X/2, SIZE_Y/2);
const double b = 0.12;

// utility functions

double sample_unif(double a, double b) {
  return (b-a)*rand()/double(RAND_MAX) + a;
}

#include <boost/random/linear_congruential.hpp>
#include <boost/random/normal_distribution.hpp>
#include <boost/random/variate_generator.hpp>
static boost::minstd_rand generator(27u);
double sample_normal(double sigma = 1.0) {
  typedef boost::normal_distribution<double> Normal;
  Normal dist(0.0, sigma);
  boost::variate_generator<boost::minstd_rand&, Normal> norm(generator, dist);
  double tmp = norm();
  //  cout << tmp << endl;
  return(tmp);
}

StereoMeasurement add_noise(const StereoMeasurement& m) {
  if (!ADD_NOISE) {
    return m;
  } else {
    double u, v, u2;
    bool done = false;
    while (!done) {
      double sigma = PIXEL_SIGMA;
      u = m.u  + sample_normal(sigma);
      v = m.v  + sample_normal(sigma);
      u2 = m.u2 + sample_normal(sigma);
      done = (u2<=u); // ensure valid stereo measurement
    }
    return StereoMeasurement(u, v, u2);
  }
}

Pose3d add_noise(const Pose3d& p) {
  if (!ADD_NOISE) {
    return p;
  } else {
    double sigma = 0.05;
    double sigma0 = 0.001; // small noise
    return Pose3d(p.x() + sample_normal(sigma),
                  p.y() + sample_normal(sigma),
                  p.z() + sample_normal(sigma),
                  p.yaw()   + sample_normal(sigma),
                  p.pitch() + sample_normal(sigma0),
                  p.roll()  + sample_normal(sigma0));
  }
}

#ifdef VISUALIZE
class Vis {

  lcm_t* _lcm;
  Viewer* _viewer;

public:

  Vis() {
    _lcm = lcm_create(NULL);
    _viewer = new Viewer(_lcm);
  }

  ~Vis() {
    lcm_destroy(_lcm);
  }

  void draw(const vector<Pose3d_Node*>& pose_nodes,
            const vector<Point3d_Node*>& point_nodes,
            const vector<Point3dh_Node*>& pointh_nodes) {
    ObjectCollection pc(1, "Poses");
    for (unsigned int i=0; i<pose_nodes.size(); i++) {
      pc.add(i, pose_nodes[i]->value());
    }
    _viewer->sendCollection(pc, true);
    
    PointCloudCollection tc(2, "Points", VS_POINT3D_LIST_COLLECTION_T_POINT);
    PointCloudPtr points(new PointCloud(0));
    for (unsigned int i=0; i<point_nodes.size(); i++) {
      Pose3d pose;
      pose.of_point3d(point_nodes[i]->value().to_point3d());
      points->addPoint(pose.x(), pose.y(), pose.z());
    }
    for (unsigned int i=0; i<pointh_nodes.size(); i++) {
      Pose3d pose;
      pose.of_point3d(pointh_nodes[i]->value().to_point3d());
      points->addPoint(pose.x(), pose.y(), pose.z());
    }
    
    tc.add(boost::make_shared<PointCloudPtr>(points));
    _viewer->sendCollection(tc, true);
  }

};
#endif

class Simulation {

  Slam slam;

#ifdef VISUALIZE
  Vis viewer;
#endif

  StereoCamera camera;

  vector<Pose3d> poses;
  vector<Pose3d> odometry;

  vector<Pose3d_Node*> pose_nodes;
  vector<Point3d_Node*> point_nodes;
  vector<Point3dh_Node*> pointh_nodes;

public:

  void generate_trajectory() {
    poses.push_back(origin);

    for (int i=1; i<NUM_CAMERAS; i++) {
      Pose3d odo(0.1,0.,0., 0.,0.,0.);
      Pose3d pose = poses[i-1].oplus(odo);
      odometry.push_back(odo);
      poses.push_back(pose);
    }

    // add noise
    for (int i=1; i<NUM_CAMERAS; i++) {
      odometry[i-1] = add_noise(odometry[i-1]);
    }
  }

  void setup_pose_graph() {
    // cameras
    Pose3d_Node* pose0 = new Pose3d_Node();
    slam.add_node(pose0);
    pose_nodes.push_back(pose0);

    // create a prior on the camera position
    MatrixXd eye6 = Matrix<double, 6, 6>::Identity();
    Pose3d_Factor* prior = new Pose3d_Factor(pose0, poses[0], SqrtInformation(1000000*eye6)); // todo: why does this affect convergence??
    slam.add_factor(prior);
    
    // odometry measurements
    for (int i=1; i<NUM_CAMERAS; i++) {
      Pose3d_Node* pose = new Pose3d_Node();
      slam.add_node(pose);
      pose_nodes.push_back(pose);
      Pose3d_Pose3d_Factor* odo = new Pose3d_Pose3d_Factor(pose_nodes[i-1], pose_nodes[i], odometry[i-1], SqrtInformation(eye6));
      slam.add_factor(odo);
    }
  }

  void add_stereo_data(int frame) {
    Pose3d x0 = poses[frame-1];
    Pose3d x1 = poses[frame];

    vector<StereoMeasurement> measurements0, measurements1;
    vector<Point3dh> points;
    const double MIN_DISPARITY = 30.;
    for (int j=0; j<NUM_POINTS; j++) {
      double u = sample_unif(MIN_DISPARITY, SIZE_X);
      double v = sample_unif(0., SIZE_Y);
      // avoid 0 disparity (point at infinity) for nonhomogeneous case
      double u2 = sample_unif(u-MIN_DISPARITY, (HOMOGENEOUS) ? (u) : (u-4.0));
      StereoMeasurement measure(u,v,u2);
      measurements0.push_back(measure);
      Point3dh point = camera.backproject(x0, measure);
      //      std::cout << "point " << point.to_point3d() << std::endl;
      points.push_back(point);
      StereoMeasurement measure1(camera.project(x1, point));
      measurements1.push_back(measure1);
    }

    // add noise
    for (int j=0; j<NUM_POINTS; j++) {
      measurements0[j] = add_noise(measurements0[j]);
      measurements1[j] = add_noise(measurements1[j]);
    }

    // add to graph

    Noise noise = SqrtInformation((1./PIXEL_SIGMA) * Matrix<double, 3, 3>::Identity());

    Pose3d_Node* pose0 = pose_nodes[frame-1];
    Pose3d_Node* pose1 = pose_nodes[frame];

    for (int j=0; j<NUM_POINTS; j++) {

      if (HOMOGENEOUS) {

        Point3dh_Node* point = new Point3dh_Node();
        slam.add_node(point);
        pointh_nodes.push_back(point);
        Stereo_Factor* factor0 = new Stereo_Factor(pose0, point, &camera, measurements0[j], noise);
        slam.add_factor(factor0);
        Stereo_Factor* factor1 = new Stereo_Factor(pose1, point, &camera, measurements1[j], noise);
        slam.add_factor(factor1);

      } else {

        Point3d_Node* point = new Point3d_Node();
        slam.add_node(point);
        point_nodes.push_back(point);
        Stereo_Factor* factor0 = new Stereo_Factor(pose0, point, &camera, measurements0[j], noise);
        slam.add_factor(factor0);
        Stereo_Factor* factor1 = new Stereo_Factor(pose1, point, &camera, measurements1[j], noise);
        slam.add_factor(factor1);

      }
    }
  }

  void run() {

    cout << "simulation" << endl;

    Properties prop;
    camera = StereoCamera(f, pp, b);

    //prop.method = DOG_LEG;
    prop.method = LEVENBERG_MARQUARDT;
    //prop.force_numerical_jacobian = true;
    prop.mod_batch = 1;
    prop.mod_solve = 1;
    prop.max_iterations = 100;
    slam.set_properties(prop);

    generate_trajectory();

    setup_pose_graph();

    // create simulated stereo data

    for (int frame=1; frame<NUM_CAMERAS; frame++) {
      add_stereo_data(frame);
      //      slam.batch_optimization();
    }

#ifdef VISUALIZE
    viewer.draw(pose_nodes, point_nodes, pointh_nodes);
#endif

    // optimize

    slam.print_stats();

    double t0 = tic();
    slam.batch_optimization();
    cout << "Batch optimization time: " << toc(t0) << endl;

#ifdef VISUALIZE
    viewer.draw(pose_nodes, point_nodes, pointh_nodes);
#endif

    slam.print_stats();

#if 0
    for (int i=0; i<NUM_POINTS; i++) {
      VectorXd diff = points[i].normalize().vector() - point_nodes[i]->vector();
      cout << diff << endl;
    }
#endif

    for (int i=0; i<NUM_CAMERAS; i++) {
      cout << pose_nodes[i]->value() << endl;
    }

  }

};

int main() {

  Simulation sim;

  sim.run();

  return 0;
}
