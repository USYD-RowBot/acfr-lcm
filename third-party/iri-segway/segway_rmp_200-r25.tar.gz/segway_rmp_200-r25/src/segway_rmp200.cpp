#include "segway_rmp200.h"
#include "segway_rmp200_exceptions.h"
#include "ftdiexceptions.h"
#include <iostream>
#include <string>

CSegwayRMP200::CSegwayRMP200(std::string& segway_id)
{
  if(segway_id.size()==0)
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Invalid saegway identifier - empty string","");
  }
  else
  {
    this->id = segway_id;				
    this->comm_dev=NULL;
    this->ftdi_server = CFTDIServer::instance();
    this->ftdi_server->add_custom_PID(SEGWAY_PID);
    this->event_server = CEventServer::instance(); 
    this->thread_server = CThreadServer::instance();
    // initialize internal variables
    this->left_wheel_velocity=0.0;
    this->right_wheel_velocity=0.0;
    this->pitch_angle=0.0;
    this->pitch_rate=0.0;
    this->roll_angle=0.0;
    this->roll_rate=0.0;
    this->yaw_rate=0.0;
    this->servo_frames=0.0;
    this->left_wheel_displ=0.0;
    this->right_wheel_displ=0.0;
    this->forward_displ=0.0;
    this->yaw_displ=0.0;
    this->left_torque=0.0;
    this->right_torque=0.0;
    this->mode=(op_mode)-1;
    this->gain_schedule=(gain)-1;
    this->ui_battery=0.0;
    this->powerbase_battery=0.0;
    // command variables
    this->vT=0; 
    this->vR=0;
    // create the feedback and command threads
    this->read_thread_id = segway_id;
    this->read_thread_id += "_read_thread";		
    this->thread_server->create_thread(this->read_thread_id);
    this->thread_server->attach_thread(this->read_thread_id,this->start_read_thread,this);		
    this->command_thread_id = segway_id;
    this->command_thread_id += "_command_thread";
    this->thread_server->create_thread(this->command_thread_id);
    this->thread_server->attach_thread(this->command_thread_id,this->start_command_thread,this);		
    // create the finish events
    this->read_finish_event = segway_id;
    this->read_finish_event += "_finish_read_thread";
    this->event_server->create_event(this->read_finish_event);
    this->command_finish_event = segway_id;
    this->command_finish_event += "_finish_command_thread";
    this->event_server->create_event(this->command_finish_event);

  }
}

std::string& CSegwayRMP200::get_id(void)
{
  return this->id;
}

unsigned char CSegwayRMP200::compute_checksum(segway_packet *packet)
{
  int i;

  unsigned short int checksum=0;
  unsigned short int checksum_high=0;

  for(i=0;i<17;i++)
    checksum += (short)packet->data[i];
  checksum_high = (unsigned short)(checksum >> 8);
  checksum &= 0xFF;
  checksum +=checksum_high;
  checksum_high = (unsigned short)(checksum >> 8);
  checksum &= 0xFF;
  checksum +=checksum_high;
  checksum = (~checksum + 1) & 0xFF;
 
  return (unsigned char)checksum;
}

bool CSegwayRMP200::read_packet(segway_packet *packet,int *packet_len)
{
  int read_data=0,len=0,pos=0;
  unsigned char *data=NULL;

  if(packet==NULL)
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Invalid packet structure",this->id);
  } 
  else
  {
    len=this->comm_dev->get_num_data();
    data=new unsigned char[len];
    try{
      read_data=this->comm_dev->read(data,len);
    }catch(CException &e){
      /* handle exception */
      throw;
    }
    if(read_data!=len)
    {
      /* handle exceptions */
      throw CSegwayRMP200Exception(_HERE_,"Unexpected error while reading the USB device",this->id);
    }
    while(pos<len)
    {
      if((*packet_len)==0)
      {
        if(data[pos]==0xF0)
        {
          packet->data[(*packet_len)]=data[pos];
          (*packet_len)++;
        }
      }
      else
      { 
        if((*packet_len)==1)
        {
          if(data[pos]==0x55)
          {
            packet->data[(*packet_len)]=data[pos];
            (*packet_len)++;
          }
          else
            (*packet_len)=0;
        }
        else
        {
          if((*packet_len)==2)
          {
            if(data[pos]==0xAA || data[pos]==0xBB)
            {
              packet->data[(*packet_len)]=data[pos];
              (*packet_len)++;
            }
            else
              (*packet_len)=0;
          }
          else
          {
            packet->data[(*packet_len)]=data[pos];
            (*packet_len)++;
            if((*packet_len)==18)
            {
              (*packet_len)=0;
              if(data!=NULL)
                delete[] data;
              return true;
            }
          }
        }
      }
      pos++;
    }
  }

  if(data!=NULL)
    delete[] data;
  return false;
}

void CSegwayRMP200::parse_packet(segway_packet *packet)
{
  short int command;
  int i=0;

  if(this->compute_checksum(packet)!=packet->data[17])
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Invalid packet checksum, a transmission error ocurred",this->id);
  }
  if(packet->data[2]==0xaa)
  {
    this->access_status.enter();
    command=(packet->data[4]*256+packet->data[5])/32;
    switch(command)
    {
      case 0x0400: break;
      case 0x0401: this->pitch_angle=((float)((short int)(((int)packet->data[9]<<8)+(int)packet->data[10])))/7.8;
                   this->pitch_rate=((float)((short int)(((int)packet->data[11]<<8)+(int)packet->data[12])))/7.8;
                   this->roll_angle=((float)((short int)(((int)packet->data[13]<<8)+(int)packet->data[14])))/7.8;
                   this->roll_rate=((float)((short int)(((int)packet->data[15]<<8)+(int)packet->data[16])))/7.8;
                   break;
      case 0x0402: this->left_wheel_velocity=((float)((short int)(((int)packet->data[9]<<8)+(int)packet->data[10])))/332.0;
                   this->right_wheel_velocity=((float)((short int)(((int)packet->data[11]<<8)+(int)packet->data[12])))/332.0;
                   this->yaw_rate=((float)((short int)(((int)packet->data[13]<<8)+(int)packet->data[14])))/7.8;
                   this->servo_frames=((float)((unsigned short int)(((int)packet->data[15]<<8)+(int)packet->data[16])))*0.01;
                   break; 
      case 0x0403: this->left_wheel_displ=((float)((int)(((int)packet->data[11]<<24)+((int)packet->data[12]<<16)+((int)packet->data[9]<<8)+(int)packet->data[10])))/33125.0; 
                   this->right_wheel_displ=((float)((int)(((int)packet->data[15]<<24)+((int)packet->data[16]<<16)+((int)packet->data[13]<<8)+(int)packet->data[14])))/33125.0;
                   break;
      case 0x0404: this->forward_displ=((float)((int)(((int)packet->data[11]<<24)+((int)packet->data[12]<<16)+((int)packet->data[9]<<8)+(int)packet->data[10])))/33125.0;;
                   this->yaw_displ=((float)((int)(((int)packet->data[15]<<24)+((int)packet->data[16]<<16)+((int)packet->data[13]<<8)+(int)packet->data[14])))/33125.0;
                   break;
      case 0x0405: this->left_torque=((float)((short int)(((int)packet->data[9]<<8)+(int)packet->data[10])))/1094.0;
                   this->right_torque=((float)((short int)(((int)packet->data[11]<<8)+(int)packet->data[12])))/1094.0;
                   break;
      case 0x0406: this->mode=(op_mode)(packet->data[9]*256+packet->data[10]);
                   this->gain_schedule=(gain)(((int)packet->data[11]<<8)+(int)packet->data[12]);
                   this->ui_battery=1.4+(float)(((int)packet->data[13]<<8)+(int)packet->data[14])*0.0125;
                   this->powerbase_battery=(float)(((int)packet->data[15]<<8)+(int)packet->data[16])/4.0;
                   break;
      case 0x0407: break;
      case 0x0680: break;
      case 0x0688: break;
      default: /* handle exceptions */
               break;
    }
  }
  this->access_status.exit();
}

void *CSegwayRMP200::start_read_thread(void *param)
{
  CSegwayRMP200 *segway = (CSegwayRMP200 *) param;

  segway->read_thread();
}

void CSegwayRMP200::read_thread(void)
{
  std::list<std::string> event_list;
  segway_packet packet;
  int packet_len=0;
  bool end=false;

  event_list.push_back(this->comm_rx_event);
  while(!end)
  {
    try{
      this->event_server->wait_all(event_list);
      if(this->read_packet(&packet,&packet_len))
        this->parse_packet(&packet);
      if(this->event_server->event_is_set(this->read_finish_event))
      {
        this->event_server->reset_event(this->read_finish_event);
        end=true; 
      }
    }catch(CException &e){
      /* handle exceptions */
      std::cout << e.what()  << std::endl;
      throw;
    }								
  }

  pthread_exit(NULL);
}

void *CSegwayRMP200::start_command_thread(void *param)
{
  CSegwayRMP200 *segway = (CSegwayRMP200 *) param;

  segway->command_thread();
}
 
void CSegwayRMP200::command_thread(void)
{
  segway_packet packet={0xF0,0x55,0x00,0x00,0x00,0x00,0x04,0x13,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
  bool end=false;
  short int vT,vR;

  while(!end)
  {
    usleep(100000);
    this->access_command.enter();
    vT=this->vT;
    vR=this->vR;
    this->access_command.exit();		
    packet.data[9]=((unsigned char *)&vT)[1];
    packet.data[10]=((unsigned char *)&vT)[0];
    packet.data[11]=((unsigned char *)&vR)[1];
    packet.data[12]=((unsigned char *)&vR)[0];
    packet.data[17]=this->compute_checksum(&packet);
    try{
      this->comm_dev->write(packet.data,18);
    }catch(CException &e){
      throw;
    }
    if(this->event_server->event_is_set(this->command_finish_event))
    {
      this->event_server->reset_event(this->command_finish_event);
      end=true;
    }
  }

  pthread_exit(NULL);
}

// configuration functions
void CSegwayRMP200::set_velocity_scale_factor(float factor)
{
  short int value;
  segway_packet packet={0xF0,0x55,0x00,0x00,0x00,0x00,0x04,0x13,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

  if(factor < 0.0 || factor > 1.0)
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Invalid scale factor for velocity",this->id);
  }
  else
  {
    if(this->comm_dev==NULL)
    {
      /* handle exception */
      throw CSegwayRMP200Exception(_HERE_,"Communciation device not set",this->id);
    }
    else
    {
      value=(short int)(factor*16);
      packet.data[13]=0;
      packet.data[14]=10;
      packet.data[15]=((unsigned char *)&value)[1];
      packet.data[16]=((unsigned char *)&value)[0];
      packet.data[17]=this->compute_checksum(&packet);
      try{
        this->comm_dev->write(packet.data,18);
      }catch(CException &e){
        throw;
      }
    }
  }
}

void CSegwayRMP200::set_acceleration_scale_factor(float factor)
{
  short int value;
  segway_packet packet={0xF0,0x55,0x00,0x00,0x00,0x00,0x04,0x13,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

  if(factor < 0.0 || factor > 1.0)
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Invalid scale factor for acceleration",this->id);
  }
  else
  {
    if(this->comm_dev==NULL)
    {
      /* handle exceptions */
      throw CSegwayRMP200Exception(_HERE_,"Communciation device not set",this->id);
    }
    else
    {
      value=(short int)(factor*16);
      packet.data[13]=0;
      packet.data[14]=11;
      packet.data[15]=((unsigned char *)&value)[1];
      packet.data[16]=((unsigned char *)&value)[0];
      packet.data[17]=this->compute_checksum(&packet);
      try{
        this->comm_dev->write(packet.data,18);
      }catch(CException &e){
        throw;
      }
    }
  }
}

void CSegwayRMP200::set_turnrate_scale_factor(float factor)
{
  short int value;
  segway_packet packet={0xF0,0x55,0x00,0x00,0x00,0x00,0x04,0x13,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

  if(factor < 0.0 || factor > 1.0)
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Invalid scale factor for turn rate",this->id);
  }
  else
  {
    if(this->comm_dev==NULL)
    {
      /* handle exceptions*/
      throw CSegwayRMP200Exception(_HERE_,"Communciation device not set",this->id);
    }
    else
    {
      value=(short int)(factor*16);
      packet.data[13]=0;
      packet.data[14]=12;
      packet.data[15]=((unsigned char *)&value)[1];
      packet.data[16]=((unsigned char *)&value)[0];
      packet.data[17]=this->compute_checksum(&packet);
      try{
        this->comm_dev->write(packet.data,18);
      }catch(CException &e){
        throw;
      }
    }
  }
}

void CSegwayRMP200::set_gain_schedule(gain value)
{
  segway_packet packet={0xF0,0x55,0x00,0x00,0x00,0x00,0x04,0x13,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

  if(this->comm_dev==NULL)
  { 
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Communciation device not set",this->id);
  }
  else
  {
    packet.data[13]=0;
    packet.data[14]=13;
    packet.data[15]=((unsigned char *)&value)[1];
    packet.data[16]=((unsigned char *)&value)[0];
    packet.data[17]=this->compute_checksum(&packet);
    try{
      this->comm_dev->write(packet.data,18);
    }catch(CException &e){
      throw;
    }
  }
}

void CSegwayRMP200::set_currentlimit_scale_factor(float factor)
{
  short int value;
  segway_packet packet={0xF0,0x55,0x00,0x00,0x00,0x00,0x04,0x13,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

  if(factor < 0.0 || factor > 1.0)
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Invalid scale factor for current limit",this->id);
  }
  else
  {
    if(this->comm_dev==NULL)
    { 
      /* handle exceptions */
      throw CSegwayRMP200Exception(_HERE_,"Communciation device not set",this->id);
    }
    else
    {
      value=(short int)(factor*256);
      packet.data[13]=0;
      packet.data[14]=14;
      packet.data[15]=((unsigned char *)&value)[1];
      packet.data[16]=((unsigned char *)&value)[0];
      packet.data[17]=this->compute_checksum(&packet);
      try{
        this->comm_dev->write(packet.data,18);
      }catch(CException &e){
        throw;
      }
    }
  }
}

void CSegwayRMP200::lock_balance(void)
{
  segway_packet packet={0xF0,0x55,0x00,0x00,0x00,0x00,0x04,0x13,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

  if(this->comm_dev==NULL)
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Communciation device not set",this->id);
  }
  else
  {
    packet.data[13]=0;
    packet.data[14]=15;
    packet.data[15]=0;
    packet.data[16]=1;
    packet.data[17]=this->compute_checksum(&packet);
    try{
      this->comm_dev->write(packet.data,18);
    }catch(CException &e){
      throw;
    }
  }
}

void CSegwayRMP200::unlock_balance(void)
{
  segway_packet packet={0xF0,0x55,0x00,0x00,0x00,0x00,0x04,0x13,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

  if(this->comm_dev==NULL)
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Communciation device not set",this->id);
  }
  else
  {
    packet.data[13]=0;
    packet.data[14]=15;
    packet.data[15]=0;
    packet.data[16]=0;
    packet.data[17]=this->compute_checksum(&packet);
    try{
     this->comm_dev->write(packet.data,18);
    } catch(CException &e){
      throw;
    } 
  }
}

void CSegwayRMP200::set_operation_mode(op_mode mode)
{
  segway_packet packet={0xF0,0x55,0x00,0x00,0x00,0x00,0x04,0x13,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

  if(this->comm_dev==NULL)
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Communciation device not set",this->id);
  }
  else
  {
    packet.data[13]=0;
    packet.data[14]=16;
    packet.data[15]=((unsigned char *)&mode)[1];
    packet.data[16]=((unsigned char *)&mode)[0];
    packet.data[17]=this->compute_checksum(&packet);
    try{
      this->comm_dev->write(packet.data,18);
    }catch(CException &e){
      throw;
    }
  }
}

void CSegwayRMP200::reset_right_wheel_integrator(void)
{
  segway_packet packet={0xF0,0x55,0x00,0x00,0x00,0x00,0x04,0x13,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

  if(this->comm_dev==NULL)
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Communciation device not set",this->id);
  }
  else
  {
    packet.data[13]=0;
    packet.data[14]=50;
    packet.data[15]=0;
    packet.data[16]=1;
    packet.data[17]=this->compute_checksum(&packet);
    try{
      this->comm_dev->write(packet.data,18);
    }catch(CException &e){
      throw;
    }
  }
}

void CSegwayRMP200::reset_left_wheel_integrator(void)
{
  segway_packet packet={0xF0,0x55,0x00,0x00,0x00,0x00,0x04,0x13,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

  if(this->comm_dev==NULL)
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Communciation device not set",this->id);
  }
  else
  {
    packet.data[13]=0;
    packet.data[14]=50;
    packet.data[15]=0;
    packet.data[16]=2;
    packet.data[17]=this->compute_checksum(&packet);
    try{
      this->comm_dev->write(packet.data,18);
    }catch(CException &e){
     throw;
    } 
  }
}

void CSegwayRMP200::reset_yaw_integrator(void)
{
  segway_packet packet={0xF0,0x55,0x00,0x00,0x00,0x00,0x04,0x13,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

  if(this->comm_dev==NULL)
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Communciation device not set",this->id);
  }
  else
  {
    packet.data[13]=0;
    packet.data[14]=50;
    packet.data[15]=0;
    packet.data[16]=4;
    packet.data[17]=this->compute_checksum(&packet);
    try{
      this->comm_dev->write(packet.data,18);
    }catch(CException &e){
      throw;
    }
  }
}

void CSegwayRMP200::reset_forward_integrator(void)
{
  segway_packet packet={0xF0,0x55,0x00,0x00,0x00,0x00,0x04,0x13,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

  if(this->comm_dev==NULL)
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Communciation device not set",this->id);
  }
  else
  {
    packet.data[13]=0;
    packet.data[14]=50;
    packet.data[15]=0;
    packet.data[16]=8;
    packet.data[17]=this->compute_checksum(&packet);
    try{
      this->comm_dev->write(packet.data,18);
    }catch(CException &e){
      throw;
    }
  }
} 

// status functions
float CSegwayRMP200::get_pitch_angle(void)
{
  return this->pitch_angle;
}

float CSegwayRMP200::get_pitch_rate(void)
{
  return this->pitch_rate;
}

float CSegwayRMP200::get_roll_angle(void)
{
  return this->roll_angle;
}

float CSegwayRMP200::get_roll_rate(void)
{
  return this->roll_rate;
}

float CSegwayRMP200::get_left_wheel_velocity(void)
{
  return this->left_wheel_velocity;
}

float CSegwayRMP200::get_right_wheel_velocity(void)
{
  return this->right_wheel_velocity;
}

float CSegwayRMP200::get_yaw_rate(void)
{
  return this->yaw_rate;
}

float CSegwayRMP200::get_servo_frames(void)
{
  return this->servo_frames;
}

float CSegwayRMP200::get_left_wheel_displacement(void)
{
  this->left_wheel_displ;
}

float CSegwayRMP200::get_right_wheel_displacement(void)
{
  return this->right_wheel_displ;
}

float CSegwayRMP200::get_forward_displacement(void)
{
  return this->forward_displ;
}

float CSegwayRMP200::get_yaw_displacement(void)
{
  return this->yaw_displ;
}

float CSegwayRMP200::get_left_motor_torque(void)
{
  return this->left_torque;
}

float CSegwayRMP200::get_right_motor_torque(void)
{
  return this->right_torque;
}

op_mode CSegwayRMP200::get_operation_mode(void)
{
  return this->mode;
}

gain CSegwayRMP200::get_gain_schedule(void)
{
  return this->gain_schedule;
}

float CSegwayRMP200::get_ui_battery_voltage(void)
{
  return this->ui_battery;
}

float CSegwayRMP200::get_powerbase_battery_voltage(void)
{
  return this->powerbase_battery;
}

void CSegwayRMP200::connect(std::string& desc_serial)
{
  TFTDIconfig ftdi_config;

  if(this->comm_dev!=NULL)
    this->close();
  this->comm_dev=this->ftdi_server->get_device(desc_serial);
  ftdi_config.baud_rate = 460800;
  ftdi_config.word_length = -1;
  ftdi_config.stop_bits = -1;
  ftdi_config.parity = -1;
  ftdi_config.read_timeout = 1000;
  ftdi_config.write_timeout = 1000;
  ftdi_config.latency_timer = 1;
  this->comm_dev->config(&ftdi_config);
  this->comm_rx_event=this->comm_dev->get_rx_event_id();
  this->thread_server->start_thread(this->read_thread_id);
  this->thread_server->start_thread(this->command_thread_id);
}

void CSegwayRMP200::reset(void)
{
  segway_packet packet={0xF0,0x55,0x00,0x00,0x00,0x00,0x04,0x12,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

  if(this->comm_dev==NULL)
  {
    /* handle exceptions */
    throw CSegwayRMP200Exception(_HERE_,"Communciation device not set",this->id);
  }
  else
  {
    packet.data[17]=this->compute_checksum(&packet);
    try{
      this->comm_dev->write(packet.data,18);
    }catch(CException &e){
      throw;
    }
  }

}
	
void CSegwayRMP200::move(float vT,float vR)
{
  this->access_command.enter();
  this->vT = (short int)(vT*3.6*147.0/1.609344);
  this->vR = (short int)(vR*2048.0);
  this->access_command.exit();
}

void CSegwayRMP200::stop(void)
{
  this->access_command.enter();
  this->vT = 0;
  this->vR = 0;
  this->access_command.exit();
}

void CSegwayRMP200::close()
{
  //kill threads
  if(this->comm_dev!=NULL)
  {
    this->event_server->set_event(this->read_finish_event);
    this->event_server->set_event(this->command_finish_event);
    this->thread_server->end_thread(this->read_thread_id);
    this->thread_server->end_thread(this->command_thread_id);
    this->comm_dev->close();
    delete this->comm_dev;
    this->comm_dev=NULL;
  }
}

CSegwayRMP200::~CSegwayRMP200()
{
  this->close();		
}

std::ostream& operator<< (std::ostream& out, CSegwayRMP200& segway)
{
  segway.access_status.enter();
  out << "Pitch angle: " << segway.pitch_angle << " degrees" << std::endl;
  out << "Pitch rate " << segway.pitch_rate << " degrees/s" << std::endl;
  out << "Roll angle: " << segway.roll_angle << " degrees" << std::endl;
  out << "Roll rate: " << segway.roll_rate << " degrees/s" << std::endl;
  out << "Left wheel velocity: " << segway.left_wheel_velocity << " m/s" << std::endl;
  out << "Right wheel velocity: " << segway.right_wheel_velocity << " m/s" << std::endl;
  out << "Yaw rate: " << segway.yaw_rate << " degrees/s" << std::endl;
  out << "Servo frames: " << segway.servo_frames << " frames/s" << std::endl;
  out << "Left wheel displacement: " << segway.left_wheel_displ << " m" << std::endl;
  out << "Right wheel displacement: " << segway.right_wheel_displ << " m" << std::endl;
  out << "Forward displacement: " << segway.forward_displ << " m" << std::endl;
  out << "Yaw displacement: " << segway.yaw_displ << " rev" << std::endl;
  out << "Left motor torque: " << segway.left_torque << " Nm" << std::endl;
  out << "Right motor torque: " << segway.right_torque << " Nm" << std::endl;
  if(segway.mode==tractor)
    out << "Operation mode: tractor" << std::endl;
  else if(segway.mode==balance)
    out << "Operation mode: balance" << std::endl;
  else 
    out << "Operation mode: power down" << std::endl;
  if(segway.gain_schedule==light)
    out << "Gain schedule: light" << std::endl;
  else if(segway.gain_schedule==tall)
    out << "Gain schedule: tall" << std::endl;
  else 
    out << "Gain schedule: heavy" << std::endl;
  out << "UI battery voltage: " << segway.ui_battery << " V" << std::endl;
  out << "Powerbase battery voltage: " << segway.powerbase_battery << " V" << std::endl;
  segway.access_status.exit();

  return out;
}
