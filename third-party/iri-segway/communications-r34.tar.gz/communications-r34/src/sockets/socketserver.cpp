#include "socketserver.h"
#include "socketexceptions.h"
#include "eventexceptions.h"
#include <errno.h>
#include <iostream>
#include <sstream>
#include <string>
#include <string.h>

int CSocketServer::counter=0;

CSocketServer::CSocketServer(const std::string &sock_id) : CSocket(sock_id)
{
  this->current_clients=0;
  this->max_clients=0;
  this->state=server_created;
  // clear the client list
  this->client_list.clear();
  // clear the new connection event id
  this->new_connection_event_id.clear();
  this->connect_thread_id.clear();
  this->disconnect_thread_id.clear();
  // set up server information
  this->info.port=-1;
  this->info.address.clear();
  // create the threads
  this->connect_thread_id=sock_id + "_connect_thread";
  this->thread_server->create_thread(this->connect_thread_id);
  this->thread_server->attach_thread(this->connect_thread_id,connect_thread,this);
  this->disconnect_thread_id=sock_id + "_disconnect_thread";
  this->thread_server->create_thread(this->disconnect_thread_id);
  this->thread_server->attach_thread(this->disconnect_thread_id,disconnect_thread,this);
  // create the events
  this->new_connection_event_id=sock_id+"_new_connection_event";
  this->event_server->create_event(this->new_connection_event_id);
  this->update_list_event_id=sock_id+"_update_list_event";
  this->event_server->create_event(this->update_list_event_id);
  this->finish_connect_thread_event_id=sock_id+"_finish_connect_thread_event";
  this->event_server->create_event(this->finish_connect_thread_event_id);
  this->finish_disconnect_thread_event_id=sock_id+"_finish_disconnect_thread_event";
  this->event_server->create_event(this->finish_disconnect_thread_event_id);
}

void CSocketServer::hard_open(void *comm_dev)
{
  TSocket_info *info=(TSocket_info *)comm_dev;
  sockaddr_in sock;

  memset(&sock,0,sizeof(sock));
  CSocket::hard_open();
  if(comm_dev==NULL)
  {
    /* handle exceptions */
    throw CSocketException(_HERE_,"Invalid server information",this->comm_id);
  }
  else
  {
    // set non-blocking operation
    if(fcntl(this->socket_fd,F_SETFL,O_NONBLOCK)<0)
    {
      /* handle exceptions */
      std::cout << "error" << std::endl;
    }
    else
    {
      if(this->state==server_created)
      {
        sock.sin_family=AF_INET;
        if(inet_aton(info->address.c_str(),&sock.sin_addr)==0)
        {
          /* handle exceptions */
          throw CSocketException(_HERE_,"Impossible to convert IP address",this->comm_id);
        } 
        else
        {
          sock.sin_port=htons(info->port);
          if(::bind(this->socket_fd,(struct sockaddr *)&sock,sizeof(sock))<0)
          {
            /* handle exceptions */
            throw CSocketException(_HERE_,"Impossible to bind the socket to the desired IP address and port.",this->comm_id);
          }
          else
          {
            this->server_access.enter();
            this->state=server_binded;
            this->info.port=info->port;
            this->info.address=info->address;
            this->server_access.exit();
          }
        }
      }
      else
      {
        /* handle exceptions */
        throw CSocketException(_HERE_,"The server is not created.",this->comm_id);
      } 
    }
  }
}
void CSocketServer::hard_config(void *config)
{
  int num_listen=*((int *)config);

  CSocket::hard_config();
  if(config==NULL)
  {
    /* handle exceptions */
    throw CSocketException(_HERE_,"Invalid configuration information",this->comm_id);
  }
  else
  {
    if(this->state==server_binded)
    {
      if(::listen(this->socket_fd,num_listen)<0)
      {
        /* handle exceptions */
        throw CSocketException(_HERE_,"Impossible to listen to the desired IP address and port.",this->comm_id);
      }
      else
      {
        this->server_access.enter();
        this->state=server_listening;
        this->server_access.exit();
      }
    }
    else
    {
      /* handle exceptions */
      throw CSocketException(_HERE_,"The server is not binded",this->comm_id);
    }
  }
}

int CSocketServer::hard_wait_comm_event(void)
{
  std::string wait_event=this->comm_id+"_wait_event";
  std::list<std::string> events;

  this->event_server->create_event(wait_event);
  events.push_back(wait_event);

  this->event_server->wait_first(events);

  return -1;
}

void CSocketServer::hard_close(void)
{
  CSocket::hard_close();
  this->stop_server();
  this->state=server_created;
  this->info.port=-1;
  this->info.address.clear();
}

void CSocketServer::set_max_clients(int max_clients)
{
  this->server_access.enter();
  this->max_clients = max_clients;
  this->server_access.exit();
}

int CSocketServer::get_max_clients(void)
{
  return this->max_clients;
}

int CSocketServer::get_num_current_clients(void)
{
  return this->current_clients;
}

void CSocketServer::start_server(void)
{
  if(this->state!=server_listening)
  {
    /* handle exceptions */
    throw CSocketException(_HERE_,"The server is not properly configured to accept connections",this->comm_id);
  }
  else
  { 
    this->server_access.enter();
    this->state=server_on;
    this->server_access.exit();
    this->thread_server->start_thread(this->connect_thread_id);
    this->thread_server->start_thread(this->disconnect_thread_id);
  }
}

void CSocketServer::stop_server(void)
{
  std::list<TClient_info_int *>::iterator it;

  if (this->state==server_on)
  {
    this->event_server->set_event(this->finish_connect_thread_event_id);
    this->thread_server->end_thread(this->connect_thread_id);
    this->event_server->set_event(this->finish_disconnect_thread_event_id);
    this->thread_server->end_thread(this->disconnect_thread_id);
    this->server_access.enter();
    this->state=server_listening;
    this->server_access.exit();
    // remove all clients from the list
    // activate the disconnect event    
    for(it=this->client_list.begin();it!=this->client_list.end();it++)
      this->event_server->set_event((*it)->disconnect_event_id);
  }
  else
  {
    /* handle exceptions */ 
    throw CSocketException(_HERE_,"Server is not running", this->comm_id);
  }
}

void CSocketServer::broadcast(unsigned char *data, const int len)
{
  std::list<TClient_info_int *>::iterator it;
  int written=0;

  try{
    this->server_access.enter();
    for(it=this->client_list.begin();it!=this->client_list.end();it++)
    {
      if((written=(*it)->socket->write(data,len))!=len)
      {
        this->server_access.exit();
        /* handle exceptions */
        throw CSocketException(_HERE_,"Error while writing to the client",(*it)->client_id);
      }
    }
    this->server_access.exit();
  }catch(CException &e){
    /* handle exceptions */
    this->server_access.exit();
    throw;
  }
}

int CSocketServer::write_to(const std::string &sock_id, unsigned char *data, const int len)
{
  std::list<TClient_info_int *>::iterator it;

  try{
    this->server_access.enter();
    for(it=this->client_list.begin();it!=this->client_list.end();it++)
    {
      if((*it)->client_id==sock_id)
      {
        this->server_access.exit();
        return (*it)->socket->write(data,len);
      }
    }
    this->server_access.exit();
    throw CSocketException(_HERE_,"Unknown socket identifier",sock_id);
  }catch(CException &e){
    /* handle exceptions */
    this->server_access.exit();
    throw;
  }
}

int CSocketServer::read_from(const std::string &sock_id, unsigned char *data, const int len)
{
  std::list<TClient_info_int *>::iterator it;

  try{
    this->server_access.enter();
    for(it=this->client_list.begin();it!=this->client_list.end();it++)
    {
      if((*it)->client_id==sock_id)
      {
        this->server_access.exit();
        return (*it)->socket->read(data,len);
      }
    }
    this->server_access.exit();
    throw CSocketException(_HERE_,"Unknown socket identifier",sock_id);
  }catch(CException &e){
    /* handle exceptions */
    this->server_access.exit();
    throw;
  }
}

int CSocketServer::get_num_data_from(const std::string &sock_id)
{
  std::list<TClient_info_int *>::iterator it;

  try{
    this->server_access.enter();
    for(it=this->client_list.begin();it!=this->client_list.end();it++)
    {
      if((*it)->client_id==sock_id)
      {
        this->server_access.exit();
        return (*it)->socket->get_num_data();
      }
    }
    this->server_access.exit();
    throw CSocketException(_HERE_,"Unknown socket identifier",sock_id);
  }catch(CException &e){
    /* handle exceptions */
    this->server_access.exit();
    throw;
  }
}

string CSocketServer::get_new_connection_event_id(void)
{
  return this->new_connection_event_id;
}

TClient_info *CSocketServer::get_new_client(void)
{
  TClient_info *client,*client_queue;

  this->server_access.enter(); 
  if(this->new_clients.size()>0)
  {
    client_queue=this->new_clients.front();
    client=new TClient_info;
    client->client_id=client_queue->client_id;
    client->IP=client_queue->IP;
    client->port=client_queue->port;
    client->disconnect_event_id=client_queue->disconnect_event_id;
    client->rx_event_id=client_queue->rx_event_id;
    this->new_clients.pop();
    this->server_access.exit(); 
    return client;
  }
  else
  { 
    this->server_access.exit(); 
    return NULL;
  }
}

void CSocketServer::free_client(TClient_info *info)
{
  std::list<TClient_info_int *>:: iterator it;
  sockaddr_in sock;

  this->server_access.enter();
  for(it=this->client_list.begin();it!=this->client_list.end();it++)
  {
    if((*it)->client_id==info->client_id)
    {
      (*it)->socket->close();
      delete (*it)->socket;
      this->current_clients--;
      it=this->client_list.erase(it);
      this->event_server->delete_event(info->disconnect_event_id);
      delete info;
      if(this->socket_fd==-1)
      {
        memset(&sock,0,sizeof(sock));
        sock.sin_family=AF_INET;
        inet_aton(this->info.address.c_str(),&sock.sin_addr);
        sock.sin_port=htons(this->info.port);
        this->CSocket::hard_open();
        ::bind(this->socket_fd,(struct sockaddr *)&sock,sizeof(sock));
        ::listen(this->socket_fd,1);
        this->state=server_on;          
      }
      this->server_access.exit();
      return;
    }
  }
  this->server_access.exit();
  throw CSocketException(_HERE_,"No such client",this->comm_id);
}

void *CSocketServer::connect_thread(void *param)
{
  CSocketServer *server=(CSocketServer *)param;
  TClient_info_int *client_info_int;
  std::stringstream sock_id;
  TClient_info *client_info;
  struct sockaddr_in client;
  int new_fd,len=0;
  bool end=false;

  while(!end)
  {
    if(server->state==server_on)
    {
      server->server_access.enter();
      try{
        len=sizeof(client);
        server->server_access.exit();
        if((new_fd=::accept(server->socket_fd,(struct sockaddr *)&client,(socklen_t *)&len))<0)
        {
          if(errno==EWOULDBLOCK)
          {
            if(server->event_server->event_is_set(server->finish_connect_thread_event_id))
              end=true;
            else
              usleep(100000);
          }
          else
          {  
            /* handle exceptions */
            throw CSocketException(_HERE_,"Unexpected error while accepting new connections.",server->comm_id);
          }
        }
        else
        {
          server->server_access.enter();
          server->counter++;
          sock_id.str("");
          sock_id << "client_socket_" << server->counter;
          // initialize the internal client info
          client_info_int=new TClient_info_int; 
          client_info_int->socket=CSocket::create_socket(sock_id.str(),new_fd);
          client_info_int->socket->open(NULL);
          client_info_int->socket->config(NULL);
          client_info_int->client_id=sock_id.str();
          client_info_int->disconnect_event_id=sock_id.str()+"_disconnect";
          server->event_server->create_event(client_info_int->disconnect_event_id);
          // initialize the external client info
          client_info=new TClient_info;
          client_info->client_id=sock_id.str();
          client_info->IP=inet_ntoa(client.sin_addr);
          client_info->port=(int)(ntohs(client.sin_port));
          client_info->disconnect_event_id=client_info_int->disconnect_event_id;
          client_info->rx_event_id=client_info_int->socket->get_rx_event_id();
          // signal the connection of a new client
          server->new_clients.push(client_info);
          server->client_list.push_back(client_info_int);
          server->current_clients++;
          server->event_server->set_event(server->new_connection_event_id);
          server->event_server->set_event(server->update_list_event_id);
          if(server->current_clients==server->max_clients)
          {
            server->CSocket::hard_close(); 
            server->state=server_created;
          }
          server->server_access.exit();
        }
      }catch(CException &e){
        server->server_access.exit();
        std::cout << e.what() << std::endl;
      }
    }
    else
    {
      if(server->event_server->event_is_set(server->finish_connect_thread_event_id))
        end=true;
      sleep(1);
    }
  }
  
  pthread_exit(NULL);
}

void *CSocketServer::disconnect_thread(void *param)
{
  std::list<TClient_info_int *>:: iterator it_client;
  CSocketServer *server=(CSocketServer *)param;
  std::list<std::string>:: iterator it_event;
  std::list<std::string> events;
  int event_id=0,i=0;
  bool end=false;

  events.clear();
  events.push_back(server->update_list_event_id);
  events.push_back(server->finish_disconnect_thread_event_id);
  while(!end)
  {
    try{
      event_id=server->event_server->wait_first(events);
      server->server_access.enter();
      if(event_id==0)
      {
        events.clear();
        events.push_back(server->update_list_event_id);
        events.push_back(server->finish_disconnect_thread_event_id);
        for(it_client=server->client_list.begin();it_client!=server->client_list.end();it_client++)
          events.push_back((*it_client)->socket->get_connection_closed_event());
      }
      else
      {
        if(event_id==1)
          end=true;
        else
        {
          it_event=events.begin();
          it_client=server->client_list.begin();
          for(i=0;i<(event_id-2);i++) 
          { 
            it_event++;
            it_client++;
          }
          it_event++;
          if(!server->event_server->event_is_set((*it_client)->disconnect_event_id))
            server->event_server->set_event((*it_client)->disconnect_event_id);
          events.erase(it_event);
        }
      }
      server->server_access.exit();
    }catch(CException &e){
      std::cout << e.what() << std::endl;
    }
  }

  pthread_exit(NULL);
}

CSocketServer::~CSocketServer()
{
  this->event_server->delete_event(this->new_connection_event_id);
  this->new_connection_event_id="";
  this->event_server->delete_event(this->update_list_event_id);
  this->update_list_event_id="";
  this->event_server->delete_event(this->finish_connect_thread_event_id);
  this->finish_connect_thread_event_id="";
  this->event_server->delete_event(this->finish_disconnect_thread_event_id);
  this->finish_disconnect_thread_event_id="";
  this->thread_server->delete_thread(this->connect_thread_id);
  this->connect_thread_id="";
  this->thread_server->delete_thread(this->disconnect_thread_id);
  this->disconnect_thread_id="";
  this->info.port=-1;
  this->info.address.clear();
}
