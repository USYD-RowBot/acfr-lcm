#include "socket.h"
#include "socketexceptions.h"
#include <string.h>

CSocket::CSocket(const std::string &comm_id) : CComm(comm_id)
{
  struct hostent *host;
  char name[1024];

  this->connection_closed_event.clear();
  this->connection_closed_event+=comm_id;
  this->connection_closed_event+="_closed";
  this->event_server->create_event(this->connection_closed_event);
  this->cloned=false;
}

CSocket::CSocket(const std::string &comm_id,const int fd) : CComm(comm_id)
{
  struct hostent *host;
  char name[200];

  if(fd<0)
  {
    /* handle exceptions */
    throw CSocketException(_HERE_, "Invalid file descriptor",comm_id);
  }
  else
  {
    this->connection_closed_event.clear();
    this->connection_closed_event+=comm_id;
    this->connection_closed_event+="_closed";
    this->event_server->create_event(this->connection_closed_event);
    this->cloned=true;
    this->socket_fd=fd;
  }
}

CSocket *CSocket::create_socket(const std::string &comm_id, const int fd)
{
  CSocket *new_socket;

  new_socket=new CSocket(comm_id,fd);

  return new_socket;
}

std::string CSocket::get_connection_closed_event(void)
{
  return this->connection_closed_event;
}

void CSocket::hard_open(void *comm_dev)
{
  int yes=1;

  if(!this->cloned)
  {
    if((this->socket_fd=socket(AF_INET,SOCK_STREAM,0))<0)
    {
      /* handle exceptions */
      throw CSocketException(_HERE_,"Error opening socket", this->comm_id);
    }
    else
    {
      if(setsockopt(this->socket_fd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(int))<0)
      {
        /* handle exceptions */
        throw CSocketException(_HERE_,"Impossible to change socket options",this->comm_id);
      }
    }
  }
}

void CSocket::hard_config(void *config)
{
  /* do nothing */
}

int CSocket::hard_read(unsigned char *data, int len)
{
  int num_read=0;

  if(!this->event_server->event_is_set(this->connection_closed_event))
  {
    if((num_read=::read(this->socket_fd,data,len))==-1)
    {
      /* handle exceptions */
      throw CSocketException(_HERE_,"Error while reading from the socket.",this->comm_id);
    }
  }

  return num_read;
}

int CSocket::hard_write(unsigned char *data, int len)
{
  int num_write=0;
  
  if(!this->event_server->event_is_set(this->connection_closed_event))
  {
    if((num_write=::write(this->socket_fd,data,len))==-1)
    {
      /* handle exceptions */
      throw CSocketException(_HERE_,"Error while writing to the socket.",this->comm_id);
    }
  }

  return num_write;
}

int CSocket::hard_get_num_data(void)
{
  int num;

  if(!this->event_server->event_is_set(this->connection_closed_event))
  {
    if(ioctl(this->socket_fd,FIONREAD,&num)==-1)
    {
      /* handle exceptions */
      throw CSocketException(_HERE_,"Error while getting the number of bytes available from the socket.",this->comm_id);
    }
  }

  return num;
}

int CSocket::hard_wait_comm_event(void)
{
  fd_set receive_set,error_set;
  int max_fd,wait_result=0;

  max_fd=this->socket_fd+1;
  FD_ZERO(&receive_set);
  FD_SET(this->socket_fd,&receive_set);
  FD_ZERO(&error_set);
  FD_SET(this->socket_fd,&error_set);
  wait_result=select(max_fd,&receive_set,NULL,&error_set,NULL);
  if(wait_result==-1)
  {
    /* handle exceptions */
    throw CSocketException(_HERE_,"Error while waiting for socket events",this->comm_id);
  }
  else
  {
    if(FD_ISSET(this->socket_fd,&receive_set))/* data has been received */
    {
      if(this->hard_get_num_data()==0)
      {
        if(!this->event_server->event_is_set(this->connection_closed_event))
          this->event_server->set_event(this->connection_closed_event);
        return -1;
      }
      else
        return 1;
    }
    if(FD_ISSET(this->socket_fd,&error_set))
      return 2;
  }
  
  return -1;
}

void CSocket::hard_close(void)
{
  if(this->socket_fd!=-1)
  {
    if(::close(this->socket_fd)<0)
      throw CSocketException(_HERE_,"Error while closing the socket",this->comm_id);
    this->socket_fd=-1;
  }
  this->cloned=false;
}

CSocket::~CSocket()
{
  this->close();
  if(this->connection_closed_event.size()!=0)
  {
    this->event_server->delete_event(this->connection_closed_event);
    this->connection_closed_event.clear();
  }
}
