#include "socketexceptions.h"
#include <string.h>
#include <stdio.h>

const string socket_exception_msg="[CSocket class] - ";

CSocketException::CSocketException(const string& where,const string& error_msg,const string& comm_id):CCommException(where,socket_exception_msg,error_msg)
{
  this->error_msg+=" - ";
  this->error_msg+=comm_id;
}

CSocketNoConnectionException::CSocketNoConnectionException(const string& where,const string& error_msg,const string& comm_id):CSocketException(where,error_msg,comm_id)
{
}
