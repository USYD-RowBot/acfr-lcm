#include "socketclient.h"
#include "socketexceptions.h"
#include <string.h>

CSocketClient::CSocketClient(const std::string &sock_id) : CSocket(sock_id)
{
  this->connected=false;
  this->remote.address.clear();
  this->remote.port=-1;
}

void CSocketClient::hard_close(void)
{
  CSocket::hard_close();
  this->connected=false;
  this->remote.address.clear();
  this->remote.port=-1;
}

void CSocketClient::hard_open(void *comm_dev)
{
  TSocket_info *remote=(TSocket_info *)comm_dev;
  sockaddr_in sock;
   
  CSocket::hard_open(NULL);
  memset(&sock,0,sizeof(sock));
  sock.sin_family=AF_INET;
  if(inet_aton(remote->address.c_str(),&sock.sin_addr)==0)
  {
    /* handle exceptions */
    throw CSocketException(_HERE_,"Impossible to convert IP address",this->comm_id);
  }
  else
  {
    sock.sin_port=htons(remote->port);
    if((::connect(this->socket_fd,(struct sockaddr *)&sock,sizeof(sock)))<0)
    {
      /* handle exceptions */
      if(errno==ECONNREFUSED)
        throw CSocketNoConnectionException(_HERE_,"Nobody listening",this->comm_id);
      else
        throw CSocketException(_HERE_, "Error with connect function", this->comm_id);
    }
    else
    {
      this->connected=true;
      this->remote.port=remote->port;
      this->remote.address=remote->address;
    }
  }
}

int CSocketClient::get_remote_port(void)
{
  return this->remote.port;
}

std::string CSocketClient::get_remote_IP_address(void)
{
  return this->remote.address;
}

bool CSocketClient::is_connected(void)
{
  return this->connected;
}

CSocketClient::~CSocketClient()
{
}
