#include "ftdiexceptions.h"
#include <string.h>
#include <stdio.h>

const std::string ftdi_exception_msg="[CFTDI class] - ";
const std::string ftdiserver_exception_msg="[CFTDIServer class] - ";

const std::string error_messages[]={"ok.\n",
                                    "Invalid handle.\n",
                                    "Device not found.\n", 
                                    "Device not opened.\n",
                                    "Input/output error.\n",
                                    "Insufficient resources.\n",
                                    "Invalid parameter.\n",
                                    "Invalid baudrate.\n",
                                    "Device not opened for erase.\n",
                                    "Device not opened for write.\n",
                                    "Failed to write device.\n",
                                    "EEPROM read failed.\n",
                                    "EEPROM write failed.\n",
                                    "EEPROM erase failed.\n",
                                    "EEPROM not present.\n",
                                    "EEPROM not programmes.\n"
                                    "Invalid arguments.\n",
                                    "Not supported.\n",
                                    "Unknown error.\n"};

CFTDIException::CFTDIException(const std::string& where,const std::string& error_msg,const std::string& comm_id) : CCommException(where,ftdi_exception_msg,error_msg)
{
  this->error_msg+=" - ";
  this->error_msg+=comm_id;
}

CFTDIServerException::CFTDIServerException(const std::string& where,const std::string& error_msg) : CException(where,ftdi_exception_msg)
{
  this->error_msg+=error_msg;
}
