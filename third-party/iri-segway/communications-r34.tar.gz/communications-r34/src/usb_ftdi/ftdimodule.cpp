
#include "ftdimodule.h"
#include "ftdiexceptions.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <pthread.h>
#include <string>
#include <iostream>

CFTDI::CFTDI(const std::string& comm_id) : CComm(comm_id)
{
  this->ft_handle = NULL;		
}
	
void CFTDI::hard_open(void* comm_dev)
{
  FT_STATUS ft_status;
  std::string *serial_desc=(std::string *)comm_dev;

  ft_status=FT_OpenEx((void *)serial_desc->c_str(),FT_OPEN_BY_SERIAL_NUMBER,&(this->ft_handle));
  ft_status=FT_OpenEx((void *)serial_desc->c_str(),FT_OPEN_BY_DESCRIPTION,&(this->ft_handle));
  if(this->ft_handle==NULL)
  { 
    /* handle exceptions */
    throw CFTDIException(_HERE_,"Impossible to open the device.\n",this->comm_id); 
  }
  if((ft_status=FT_ResetDevice(this->ft_handle))!=FT_OK)
  {
    /* handle exceptions */
    throw CFTDIException(_HERE_,error_messages[ft_status],this->comm_id); 
  }
  if((ft_status=FT_Purge(this->ft_handle,FT_PURGE_RX|FT_PURGE_TX))!=FT_OK)
  {
    /* handle exceptions */
    throw CFTDIException(_HERE_,error_messages[ft_status],this->comm_id); 
  }
  if((ft_status=FT_ResetDevice(this->ft_handle))!=FT_OK)
  {
    /* handle exceptions */
    throw CFTDIException(_HERE_,error_messages[ft_status],this->comm_id); 
  }
  pthread_cond_init(&this->event_handle.eCondVar, NULL); 
  pthread_mutex_init(&this->event_handle.eMutex, NULL); 		
  pthread_mutex_lock(&this->event_handle.eMutex);

  //Set condition event here, before thread is started
  if((ft_status = FT_SetEventNotification(this->ft_handle,FT_EVENT_RXCHAR,(PVOID)&this->event_handle))!=FT_OK)
  {
    /* handle exceptions */
    throw CFTDIException(_HERE_,error_messages[ft_status],this->comm_id);
  }
}

void CFTDI::hard_config(void *config)
{
  FT_STATUS ft_status;
  TFTDIconfig *ftdi_config = (TFTDIconfig*) config;		 

  if(config==NULL)
  {
    /* handle exceptions */
    throw CFTDIException(_HERE_,"Invalid configuration structure",this->comm_id);
  }
  //1. Set Baud Rate
  if(ftdi_config->baud_rate!=-1)
  {
    if((ft_status=FT_SetBaudRate(this->ft_handle,ftdi_config->baud_rate))!=FT_OK)
    {
      /* handle exceptions */
      throw CFTDIException(_HERE_,error_messages[ft_status],this->comm_id);
    }
  }
  //2. Set the data characteristics
  if(ftdi_config->word_length!=-1 && ftdi_config->stop_bits!=-1 && ftdi_config->parity!=-1)
  {
    if((ft_status=FT_SetDataCharacteristics(this->ft_handle,ftdi_config->word_length,ftdi_config->stop_bits,ftdi_config->parity))!=FT_OK)
    {
      /* handle exceptions */
      throw CFTDIException(_HERE_,error_messages[ft_status],this->comm_id);
    }
  }
  //3. set read and write timeouts
  if((ft_status=FT_SetTimeouts(this->ft_handle,ftdi_config->read_timeout,ftdi_config->write_timeout))!=FT_OK)
  {
    /* handle exceptions */
    throw CFTDIException(_HERE_,error_messages[ft_status],this->comm_id);
  } 
  //4. Set latency timer
  if((ft_status=FT_SetLatencyTimer(this->ft_handle,ftdi_config->latency_timer))!=FT_OK)
  {
    /* handle exceptions */
    throw CFTDIException(_HERE_,error_messages[ft_status],this->comm_id);
  }
  if((ft_status=FT_SetFlowControl(this->ft_handle,FT_FLOW_NONE,0x00,0x00))!=FT_OK)
  {
    /* handle exceptions */
    throw CFTDIException(_HERE_,error_messages[ft_status],this->comm_id);
  }
}

void CFTDI::hard_close(void)
{
  FT_STATUS ft_status;

  if(this->ft_handle!=NULL)
  {
    if(pthread_mutex_trylock(&this->event_handle.eMutex)==EBUSY)
      pthread_mutex_unlock(&this->event_handle.eMutex);
    if((ft_status = FT_Close(this->ft_handle))!=FT_OK)
    {
      /* handle exceptions */
      throw CFTDIException(_HERE_,error_messages[ft_status],this->comm_id);
    }
    this->ft_handle = NULL; // assing no opened value
  }
}

int CFTDI::hard_read(unsigned char *data, int len)
{
  FT_STATUS ft_status;
  unsigned long int bytes_received;

  if((ft_status = FT_Read(this->ft_handle,data,len,&bytes_received))!=FT_OK)
  {
    /* handle exceptions */
    throw CFTDIException(_HERE_,error_messages[ft_status],this->comm_id);
  }

  return bytes_received;
}

int CFTDI::hard_write(unsigned char *data, int len)
{
  FT_STATUS ft_status;
  unsigned long int bytes_written;

  if((ft_status = FT_Write(this->ft_handle, data,len, &bytes_written))!=FT_OK)
  {
    /* handle exceptions */
    throw CFTDIException(_HERE_,error_messages[ft_status],this->comm_id);
  }	
  
  return bytes_written;
}

int CFTDI::hard_get_num_data(void)
{
  FT_STATUS ft_status;
  unsigned long int bytes_rx;	

  if((ft_status=FT_GetQueueStatus(this->ft_handle,&bytes_rx))!=FT_OK)
  {
    /* handle exceptions */
    throw CFTDIException(_HERE_,error_messages[ft_status],this->comm_id);	
  }
 
  return bytes_rx;
}

int CFTDI::hard_wait_comm_event(void)
{
  FT_STATUS ft_status;
  unsigned long int rx_bytes=0,tx_bytes=0,event_id=0;

  while(rx_bytes < 1)
  {
    pthread_cond_wait(&event_handle.eCondVar, &event_handle.eMutex);		
    if((ft_status = FT_GetStatus(this->ft_handle,&rx_bytes,&tx_bytes,&event_id))!=FT_OK)
    {
      /* handle exceptions */
      throw CFTDIException(_HERE_,error_messages[ft_status],this->comm_id);
    }
  }
  if(rx_bytes < 1) 			
    return 2; // error	
  else 		
  {
    return 1; // ready to read data	
  }
}

std::ostream& operator<< (std::ostream& out,CFTDI& ftdi)
{
  FT_STATUS ft_status;
  unsigned long int type;
  unsigned long int id;
  char serial_number[16];
  char description[64];

  out << "****************** FTDI Devices Info ***********************" << std::endl;
  if((ft_status=FT_GetDeviceInfo(ftdi.ft_handle,&type,&id,serial_number,description,NULL))!=FT_OK)
  {
    /* handle exceptions */
    throw CFTDIException(_HERE_,error_messages[ft_status],ftdi.comm_id);
  } 
  out << "Device name: " << ftdi.comm_id << std::endl;
  out << "Type: " << type << std::endl;
  out << "Device id: " << id << std::endl;
  out << "Serial Number: " << serial_number << std::endl;
  out << "Description: " << description << std::endl;

  return out;
}

CFTDI::~CFTDI(){
  this->close();
}


