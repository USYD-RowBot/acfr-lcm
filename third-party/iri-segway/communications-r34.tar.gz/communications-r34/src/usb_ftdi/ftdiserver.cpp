#include "ftdiexceptions.h"
#include "ftdiserver.h"
#include "ftd2xx.h"

CFTDIServer *CFTDIServer::pinstance=NULL;

CFTDIServer::CFTDIServer()
{
  int i=0;
  FT_STATUS status;
  unsigned long int num_devs=0;
  FT_DEVICE_LIST_INFO_NODE *dev;
  TDevice_info dev_info;

  if((status=FT_CreateDeviceInfoList(&num_devs))!=FT_OK)
  {
    /* handle exceptions */
    throw CFTDIServerException(_HERE_,error_messages[status]);
  }
  else
  {
    if(num_devs>0)
    {
      dev=new FT_DEVICE_LIST_INFO_NODE[num_devs];
      if((status=FT_GetDeviceInfoList(dev,&num_devs))!=FT_OK)
      {
        /* handle exceptions */
        throw CFTDIServerException(_HERE_,error_messages[status]);
      }
      for(i=0;i<num_devs;i++)
      {
        if(dev[i].Flags&0x00000001)
          dev_info.opened=true;
        else
          dev_info.opened=false;
        if(dev[i].Flags&0x00000002)
          dev_info.high_speed=true;
        else
          dev_info.high_speed=false;
        dev_info.type=dev[i].Type;
        dev_info.id=dev[i].ID;
        dev_info.location=dev[i].LocId;
        dev_info.serial_number=dev[i].SerialNumber;
        dev_info.description=dev[i].Description;
        this->devices.push_back(dev_info);
      }
    }
  }
}

CFTDIServer::CFTDIServer(const CFTDIServer& object)
{
}

CFTDIServer& CFTDIServer::operator = (const CFTDIServer& object)
{
  return *this->pinstance;
}

CFTDIServer *CFTDIServer::instance(void)
{
  if (CFTDIServer::pinstance == NULL)
  {
    CFTDIServer::pinstance = new CFTDIServer(); // Creamos la instancia
  }
  return CFTDIServer::pinstance; // Retornamos la dirección de la instancia
}

void CFTDIServer::add_custom_PID(int PID)
{
  int i=0;
  FT_STATUS status;
  unsigned long int num_devs=0;
  FT_DEVICE_LIST_INFO_NODE *dev;
  TDevice_info dev_info;

  for(i=0;i<this->custom_PID.size();i++)
  {
    if(this->custom_PID[i]==PID)
      return;
  }
  this->custom_PID.push_back(PID);
  if((status=FT_SetVIDPID(FTDI_VID,PID))!=FT_OK)
  {
    /* handle exceptions */
    throw CFTDIServerException(_HERE_,error_messages[status]);
  }
  else
  {
    if((status=FT_CreateDeviceInfoList(&num_devs))!=FT_OK)
    {
      /* handle exceptions */
      throw CFTDIServerException(_HERE_,error_messages[status]);
    }
    else
    {
      this->devices.clear();
      if(num_devs>0)
      {
        dev=new FT_DEVICE_LIST_INFO_NODE[num_devs];
        if((status=FT_GetDeviceInfoList(dev,&num_devs))!=FT_OK)
        {
          /* handle exceptions */
          throw CFTDIServerException(_HERE_,error_messages[status]);
        }
        for(i=0;i<num_devs;i++)
        {
          if(dev[i].Flags&0x00000001)
            dev_info.opened=true;
          else
            dev_info.opened=false;
          if(dev[i].Flags&0x00000002)
            dev_info.high_speed=true;
          else
            dev_info.high_speed=false;
          dev_info.type=dev[i].Type;
          dev_info.id=dev[i].ID;
          dev_info.location=dev[i].LocId;
          dev_info.serial_number=dev[i].SerialNumber;
          dev_info.description=dev[i].Description;
          this->devices.push_back(dev_info);
        }
      }
    }
  }
}

int CFTDIServer::get_num_devices(void)
{
  return this->devices.size();
}

bool CFTDIServer::is_opened(int index)
{
  if(index<0 || index>this->devices.size())
  {
    /* handle exceptions */
    throw CFTDIServerException(_HERE_,"There exist no USB device with the given index.\n");
  }
  else
    return this->devices[index].opened;
}

bool CFTDIServer::is_high_speed(int index)
{
  if(index<0 || index>this->devices.size())
  {
    /* handle exceptions */
    throw CFTDIServerException(_HERE_,"There exist no USB device with the given index.\n");
  }
  else
    return this->devices[index].high_speed;
}

unsigned long int CFTDIServer::get_type(int index)
{
  if(index<0 || index>this->devices.size())
  {
    /* handle exceptions */
    throw CFTDIServerException(_HERE_,"There exist no USB device with the given index.\n");
  }
  else
    return this->devices[index].type;
}

unsigned long int CFTDIServer::get_id(int index)
{
  if(index<0 || index>this->devices.size())
  {
    /* handle exceptions */
    throw CFTDIServerException(_HERE_,"There exist no USB device with the given index.\n");
  }
  else
    return this->devices[index].id;
}

unsigned long int CFTDIServer::get_location(int index)
{
  if(index<0 || index>this->devices.size())
  {
    /* handle exceptions */
    throw CFTDIServerException(_HERE_,"There exist no USB device with the given index.\n");
  }
  else
    return this->devices[index].location;
}

std::string& CFTDIServer::get_serial_number(int index)
{
  if(index<0 || index>this->devices.size())
  {
    /* handle exceptions */
    throw CFTDIServerException(_HERE_,"There exist no USB device with the given index.\n");
  }
  else
    return this->devices[index].serial_number;
}

std::string& CFTDIServer::get_description(int index)
{
  if(index<0 || index>this->devices.size())
  {
    /* handle exceptions */
    throw CFTDIServerException(_HERE_,"There exist no USB device with the given index.\n");
  }
  else
    return this->devices[index].description;
}

CFTDI *CFTDIServer::get_device(std::string& serial_desc)
{
  std::string dev_name;
  CFTDI *ftdi_device;
  int i=0;

  if(serial_desc.size()==0)
  {
    /* handle exceptions */
    throw CFTDIServerException(_HERE_,"Invalid serial number or description - empty string.\n");
  }
  else
  {
    for(i=0;i<this->devices.size();i++)
    {
      if(this->devices[i].serial_number==serial_desc || this->devices[i].description==serial_desc)
      {
        dev_name="FTDI_";
        dev_name+=serial_desc;
        ftdi_device=new CFTDI(dev_name);
        ftdi_device->open((void *)&serial_desc);
        return ftdi_device;
      }
    }
  }
}

std::ostream& operator<< (std::ostream &out,CFTDIServer &server)
{
  int i=0;

  out << "Number of FTDI devices detected: " << server.devices.size() << std::endl;
  for(i=0;i<server.devices.size();i++)
  { 
    out << "Device " << i << std::endl;
    if(server.devices[i].opened)
      out << "The device is opened" << std::endl;
    else
      out << "The device is closed" << std::endl;
    if(server.devices[i].high_speed)
      out << "The device is high speed" << std::endl;
    else
      out << "The device is full speed" << std::endl;
    out << "Type: " << server.devices[i].type << std::endl;
    out << "Device id: " << server.devices[i].id << std::endl;
    out << "Location: " << server.devices[i].location << std::endl;
    out << "Serial number: " << server.devices[i].serial_number << std::endl;
    out << "Description: " << server.devices[i].description << std::endl;
  }

  return out;
}
