#include "rs232exceptions.h"
#include <string.h>
#include <stdio.h>

const std::string rs232_exception_msg="[CRS232 class] - ";

CRS232Exception::CRS232Exception(const std::string& where,const std::string& error_msg,const std::string& comm_id):CCommException(where,rs232_exception_msg,error_msg)
{
  this->error_msg+=" - ";
  this->error_msg+=comm_id;
}
