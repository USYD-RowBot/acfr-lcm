#include "rs232.h"
#include "rs232exceptions.h"
#include "ctime.h"

CRS232::CRS232(const std::string& comm_id) : CComm(comm_id)
{
  this->serial_fd=-1;
}

void CRS232::set_baudrate(int baud)
{
  struct termios config;
  int baudrate;

  if(tcgetattr(this->serial_fd,&config)==-1)
  {
    /* handle exceptions */
    throw CRS232Exception(_HERE_,"Impossible to get the attribute structure.\n",this->comm_id);
  }
  else
  {
    switch(baud)
    {
      case 50: baudrate=B50;
               break; 
      case 75: baudrate=B75;
               break;
      case 110: baudrate=B110;
                break;
      case 134: baudrate=B134;
                break;
      case 150: baudrate=B150;
                break;
      case 200: baudrate=B200;
                break;
      case 300: baudrate=B300;
                break;
      case 600: baudrate=B600; 
                break;
      case 1200: baudrate=B1200;
                 break;
      case 1800: baudrate=B1800;
                 break;
      case 2400: baudrate=B2400;
                 break;
      case 4800: baudrate=B4800;
                 break;
      case 9600: baudrate=B9600;
                 break;
      case 19200: baudrate=B19200;
                  break;
      case 38400: baudrate=B38400;
                  break;
      case 57600: baudrate=B57600;
                  break;
      case 115200: baudrate=B115200;
                   break;
      default: /* handle exception */
               throw CRS232Exception(_HERE_,"Invalid baudrate. See the documentation for the possible values.\n",this->comm_id);
               break;
    }
    cfsetispeed(&config,baudrate);
    cfsetospeed(&config,baudrate);
    if(tcsetattr(this->serial_fd,TCSANOW,&config)==-1)
    {
      /* handle exceptions */
      throw CRS232Exception(_HERE_,"Impossible to set up the new attribute structure.\n",this->comm_id);
    }
  }
}

void CRS232::set_num_bits(char num_bits)
{
  struct termios config;
  int bits;

  if(tcgetattr(this->serial_fd,&config)==-1)
  {
    /* handle exceptions */
    throw CRS232Exception(_HERE_,"Impossible to get the attribute structure.\n",this->comm_id);
  }
  else
  {
    switch(num_bits)
    {
      case 5: bits=CS5;
              break;
      case 6: bits=CS6;
              break;
      case 7: bits=CS7;
              break;
      case 8: bits=CS8;
              break;
      default: /* handle exceptions */
               throw CRS232Exception(_HERE_,"Invalid number of bits per packet. See the documentation for the possible values.\n",this->comm_id);
               break;
    }
    config.c_cflag&=~CSIZE;
    config.c_cflag|=bits;
    if(tcsetattr(this->serial_fd,TCSANOW,&config)==-1)
    {
      /* handle exceptions */
      throw CRS232Exception(_HERE_,"Impossible to set up the new attribute structure.\n",this->comm_id);
    }
  }
}

void CRS232::set_parity(parity_type parity)
{
  struct termios config;

  if(tcgetattr(this->serial_fd,&config)==-1)
  {
    /* handle exception */
    throw CRS232Exception(_HERE_,"Impossible to get the attribute structure.\n",this->comm_id);
  }
  else
  {
    if(parity!=none)
    {
      config.c_cflag|=PARENB;
      if(parity==odd) config.c_cflag|=PARODD;
      else if(parity==even) config.c_cflag&=~PARODD;
      else
      {
        /* handle exceptions */
        throw CRS232Exception(_HERE_,"Invalid parity type. See the documentation for the possible values.\n",this->comm_id);
      }
    }
    else config.c_cflag&=~PARENB;
    if(tcsetattr(this->serial_fd,TCSANOW,&config)==-1)
    {
      /* handle exceptions */
      throw CRS232Exception(_HERE_,"Impossible to set up the new attribute structure.\n",this->comm_id);
    }
  }
}

void CRS232::set_stop_bits(char stop_bits)
{
  struct termios config;

  if(tcgetattr(this->serial_fd,&config)==-1)
  {
    /* handle exceptions */
    throw CRS232Exception(_HERE_,"Impossible to get the attribute structure.\n",this->comm_id);
  } 
  else
  {
    if(stop_bits==2) config.c_cflag|=CSTOPB;
    else if(stop_bits==1)config.c_cflag&=~CSTOPB;
    else
    {
      /* handle execptions */
      throw CRS232Exception(_HERE_,"Invalid number of stop bits. See the documentation for the possible values.\n",this->comm_id);
    }
    if(tcsetattr(this->serial_fd,TCSANOW,&config)==-1)
    {
      /* handle exception */
      throw CRS232Exception(_HERE_,"Impossible to set up the new attribute structure.\n",this->comm_id);
    }
  }
}

void CRS232::hard_open(void *comm_dev)
{
  std::string *serial_dev=(std::string *)comm_dev;
  struct termios config;

  if(serial_dev->size()==0)
  {
    /* handle exceptions */
    throw CRS232Exception(_HERE_,"Invalid serial port device name (empty string).\n",this->comm_id);
  }
  else
  {
    this->serial_fd=::open(serial_dev->c_str(),O_RDWR | O_NOCTTY | O_NONBLOCK | O_ASYNC);
    if(this->serial_fd==-1)
    {
      /* handle exceptions */
      throw CRS232Exception(_HERE_,"Impossible to open the serial port.\n",this->comm_id);
    }
    else
    {
      if(tcgetattr(this->serial_fd,&config)==-1)
      {
        /* handle exceptions */
        throw CRS232Exception(_HERE_,"Impossible to get the attribute structure.\n",this->comm_id);
      }
      else
      {
        config.c_cflag|=(CLOCAL | CREAD);
        config.c_cflag&=~CRTSCTS;
        config.c_lflag&=~(ICANON | ECHO | ECHOE | ISIG);
        config.c_iflag&=~(IXON | IXOFF | IXANY);
        config.c_iflag&=~(INLCR | IGNCR | ICRNL);
        config.c_oflag&=~OPOST;
        config.c_cc[VMIN]=0;
        config.c_cc[VTIME]=100;
        if(tcsetattr(this->serial_fd,TCSANOW,&config)==-1)
        {
          /* handle exceptions */
          throw CRS232Exception(_HERE_,"Impossible to set up the new attribute structure.\n",this->comm_id);
        }
      }
    }
  }
}

void CRS232::hard_config(void *config)
{
  TRS232_config *serial_conf=(TRS232_config *)config;

  this->set_baudrate(serial_conf->baud);
  this->set_num_bits(serial_conf->num_bits);
  this->set_parity(serial_conf->parity);
  this->set_stop_bits(serial_conf->stop_bits);
}

int CRS232::hard_read(unsigned char *data, int len)
{
  int num_read=0;

  if((num_read=::read(this->serial_fd,data,len))==-1)
  {
    return -1;
  }

  return num_read;
}

int CRS232::hard_write(unsigned char *data, int len)
{
  int num_written=0;

  if((num_written=::write(this->serial_fd,data,len))==-1)
  {
    return -1;
  } 

  return num_written; 
}

int CRS232::hard_get_num_data(void)
{
  int num;

  if(ioctl(this->serial_fd,FIONREAD,&num)==-1)
  {
    return -1;
  }

  return num;
}

int CRS232::hard_wait_comm_event(void)
{
  fd_set receive_set,error_set;
  int max_fd,wait_result=0;

  max_fd=this->serial_fd+1;
  FD_ZERO(&receive_set);
  FD_SET(this->serial_fd,&receive_set);
  FD_ZERO(&error_set);
  FD_SET(this->serial_fd,&error_set);
  wait_result=select(max_fd,&receive_set,NULL,&error_set,NULL);
  if(wait_result==-1)
    return -1; 
  else
  {
    if(FD_ISSET(this->serial_fd,&receive_set))/* data has been received */
    {
      return 1;
    }
    if(FD_ISSET(this->serial_fd,&error_set))
    {
      return 2;
    }
  }

  return -1;
}

void CRS232::hard_close(void)
{
  if(this->serial_fd!=-1)
  {
    ::close(this->serial_fd);
    this->serial_fd=-1;
  }
}

CRS232::~CRS232()
{
  this->close();
}
