#include "ftdimodule.h"
#include "ftdiserver.h"
#include "ftdiexceptions.h"
#include <stdio.h>

/** \example test_ftdi.cpp
 * 
 * This example shows how to use the D2XX FTDI driver.
 *
 * This examples first creates an FTDI server which scans for all FTDI devices
 * connected to the computer with the default PID and VID combinations provided
 * by the manufacturer. If devices with different PID and VID combinations are
 * used, it is necessary to use the add_custom_PID() function.
 *
 * When done, the information of all devices detected is displayed on screen.
 * Then the first FTDI device, if any, is opened and configured. If this 
 * operations are successfull, the specific information of the device is also
 * displyed on screen.
 *
 * The output of this example when a single FTDI device is connected is as 
 * follows:
 *
 * \verbatim
 * Number of FTDI devices detected: 1
 * Device 0
 * The device is closed
 * The device is full speed
 * Type: 5
 * Device id: 67330049
 * Location: 0
 * Serial number: A2001mHr
 * Description: FT232R USB UART
 * 
 * ****************** FTDI Devices Info ***********************
 * Device name: FTDI_A2001mHr
 * Type: 5
 * Device id: 67330049
 * Serial Number: A2001mHr
 * Description: FT232R USB UART
 * \endverbatim
 *
 * This example program does not try to read and write from and to the device
 * because it highly depends on the particular device connected. This example
 * only scans for available devices and displays its information. For a full
 * example of this driver, see the segwayRMP200 driver.
 */
int main(int argc, char *argv[])
{
  CFTDIServer *ftdi_server=CFTDIServer::instance();
  CFTDI *ftdi_device=NULL;
  TFTDIconfig ftdi_config;

  ftdi_config.baud_rate = 115200;
  ftdi_config.word_length = 8;
  ftdi_config.stop_bits = 2;
  ftdi_config.parity = 0;
  ftdi_config.read_timeout = 1000;
  ftdi_config.write_timeout = 1000;
  ftdi_config.latency_timer = 16;

  std::cout << (*ftdi_server) << std::endl;
  if(ftdi_server->get_num_devices()>0)
  {
    ftdi_device=ftdi_server->get_device(ftdi_server->get_serial_number(0));
    ftdi_device->config(&ftdi_config);
    std::cout << (*ftdi_device) << std::endl;
    ftdi_device->close();
  }
  if(ftdi_device!=NULL)
    delete ftdi_device;
}


