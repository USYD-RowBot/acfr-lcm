#include "eventexceptions.h"
#include "socketserver.h"
#include "eventserver.h"

std::string server_IP_address="127.0.0.1";
int server_port=2012;
int num_listen=1;

int main(int argc,char *argv[])
{
  CEventServer *event_server=CEventServer::instance();
  CSocketServer server("server");
  std::list<std::string> con_events,client_events;
  TSocket_info sock_info;
  unsigned char *data;
  TClient_info *info;
  int event_id,num;

  try{
    sock_info.port=server_port;
    sock_info.address=server_IP_address;
    server.open(&sock_info);
    server.config(&num_listen);
    server.set_max_clients(5);
    con_events.push_back(server.get_new_connection_event_id());
    server.start_server();
    while(1)
    {
      try{
        event_server->wait_first(con_events,1000);
        std::cout << "new connection ..." << std::endl;
        info=server.get_new_client();
        std::cout << "  client id: " << info->client_id << std::endl;
        std::cout << "  IP address: " << info->IP << " at port " << info->port << std::endl;
        client_events.clear();
        client_events.push_back(info->rx_event_id);
        client_events.push_back(info->disconnect_event_id);
        do{
          event_id=event_server->wait_first(client_events);
          if(event_id==0)
          {
            std::cout << "  data received ... ";
            num=server.get_num_data_from(info->client_id);
            data=new unsigned char[num];
            server.read_from(info->client_id,data,num);
            std::cout << data << std::endl;
            delete[] data;
          }
          if(event_id==1)
          {
            server.free_client(info);
            std::cout << "client disconnected ... " << std::endl;
          }
        }while(event_id!=1);
      }catch(CEventTimeoutException &e){
        std::cout << "waiting ..." << std::endl;
      }catch(CException &e){
        std::cout << e.what() << std::endl;
      }
    }
    server.stop_server();
  }catch(CException &e){
    std::cout << e.what() << std::endl;
  }    
}
