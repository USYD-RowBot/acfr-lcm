#include "socketclient.h"
#include "socketexceptions.h"
#include "eventexceptions.h"

std::string server_ip="147.83.76.185";
int server_port=2012;

int main(int argc,char *argv[])
{
  CEventServer *event_server=CEventServer::instance();
  CSocketClient client("client");
  std::list<std::string> events;
  unsigned char msg[5]="hola";
  int i=0,event_id=0;
  TSocket_info info;

  try{
    info.address=server_ip;
    info.port=server_port;
    std::cout << "connecting ... " << std::endl;
    while(!client.is_connected())
    {
      try{
        client.open(&info);
      }catch(CSocketNoConnectionException &e){
        std::cout << "  nobody is listening" << std::endl;
        sleep(1);
      }
    }
    client.config();
    std::cout << "connected." << std::endl;
    events.push_back(client.get_rx_event_id());
    events.push_back(client.get_connection_closed_event());
    for(i=0;i<10;i++)
    {
      try{
        event_id=event_server->wait_first(events,1000);
        if(event_id==1)
          break;
      }catch(CEventTimeoutException &e){
        std::cout << "sending data ..." << std::endl;
        client.write(msg,5);
      }
    }
    sleep(1);
    std::cout << "closing connection ..." << std::endl;
    client.close();
  }catch(CException &e){
    std::cout << e.what() << std::endl;
  }
}
