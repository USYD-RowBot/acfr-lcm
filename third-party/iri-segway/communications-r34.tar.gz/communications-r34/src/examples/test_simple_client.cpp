#include "socketclient.h"
#include "socketexceptions.h"

std::string server_ip="127.0.0.1";
int server_port=2012;

int main(int argc,char *argv[])
{
  TSocket_info info;
  CSocketClient client("client");
  unsigned char msg[5]="hola";

  try{
    while(1)
    {
      info.address=server_ip;
      info.port=server_port;
      std::cout << "connecting ... " << std::endl;
      while(!client.is_connected())
      {
        try{
          client.open(&info);
        }catch(CSocketNoConnectionException &e){
          std::cout << "  nobody is listening" << std::endl;
          sleep(1);
        }
      }
      client.config(NULL);
      std::cout << "connected." << std::endl;
      sleep(1);
      std::cout << "sending data ..." << std::endl;
      client.write(msg,5);
      sleep(1);
      std::cout << "closing connection ..." << std::endl;
      client.close();
      sleep(1);
    }
  }catch(CException &e){
    std::cout << e.what() << std::endl;
  }
}
