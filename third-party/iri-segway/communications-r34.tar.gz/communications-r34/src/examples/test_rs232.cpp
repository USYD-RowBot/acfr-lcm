#include "eventserver.h"
#include "threadserver.h"
#include "commexceptions.h"
#include "rs232.h"
#include <stdio.h>
#include <unistd.h>
#include <string>
#include <iostream>

const std::string serial_dev="/dev/ttyS0";
const std::string empty_string="";

/**
 * \example test_rs232.cpp
 *
 * This example shows how to use the serial port driver
 *
 * This example tries to use the first serial port available to send and 
 * receive data. This example is intended to be used with the RX and TX signals
 * of the serial cable connected, so that all the data sent by the driver is 
 * recevived by itself.
 *
 * \verbatim
 * RX --\
 *      |
 * TX --/
 * \endverbatim
 *
 * The CComm base class provide events to signal the data reception and also
 * some unexpected error on the port. These events are used in this example to
 * wait for all the required data, instead of peridically polling it for new 
 * data (the event server is used).
 *
 * By default the serial port used is the /dev/ttyS0. If more serial ports are 
 * available or USB to serial adapters are present, the device name can be
 * changed to the desired one: /dev/ttySn or /dev/ttyUSBn.
 *
 * The output of this example should be something like this:
 *
 * \verbatim
 *
 * \endverbatim
 *
 * Several error may be thrown either by the CComm class or the CRS232 class:
 *
 * * Invalid device name to open.
 *
 * * Trying to configure the serial port before being opened.
 *
 * * Trying to open the port once it is already opened.
 *
 * * Trying to send or receive data before configuring the serial port.
 *
 * * Trying to write invalid data-
 *
 * * Providing an invalid buffer to save all the received data. 
 */
int main(int argc,char *argv[])
{
  CEventServer *event_server=CEventServer::instance();
  unsigned char msg[5]="hola";
  std::string rx_event;
  CRS232 serial_port("serial_port");
  std::list<std::string> events;
  int num=0,total_length=0,i=0;
  TRS232_config serial_config;

  serial_config.baud=9600;
  serial_config.num_bits=8;
  serial_config.parity=none;
  serial_config.stop_bits=1;
  try{
    serial_port.open((void *)&empty_string);
  }catch(CCommException &e){
    std::cout << e.what() << std::endl;
  }
  try{
    serial_port.config(&serial_config);
  }catch(CCommException &e){
    std::cout << e.what() << std::endl;
  }
  serial_port.open((void *)&serial_dev);
  rx_event=serial_port.get_rx_event_id();
  std::cout << "Data reception event id: " << rx_event << std::endl;
  events.push_back(rx_event);
  try{
    serial_port.open((void *)"/dev/ttyS0");
  }catch(CCommException &e){
    std::cout << e.what() << std::endl;
  }
  try{
    serial_port.write(msg,5);
  }catch(CCommException &e){
    std::cout << e.what() << std::endl;
  }
  serial_port.config(&serial_config);
  try{
    serial_port.write(NULL,5);
  }catch(CCommException &e){
    std::cout << e.what() << std::endl;
  }
  try{
    for(i=0;i<10;i++)
    {
      serial_port.write(msg,5);
      do{
        event_server->wait_all(events,1000);
        num=serial_port.get_num_data();
        serial_port.read(&msg[total_length],num);
        total_length+=num;
      }while(total_length<5);
      total_length=0;
      printf("Message received: %s\n",msg);
    }
  }catch(CException &e){
    std::cout << e.what() << std::endl;
  }
  serial_port.close();
}
