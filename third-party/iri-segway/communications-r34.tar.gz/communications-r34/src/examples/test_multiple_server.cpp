#include "eventexceptions.h"
#include "socketserver.h"
#include "eventserver.h"

std::string server_IP_address="147.83.76.185";
int server_port=2012;
int num_listen=1;

int main(int argc,char *argv[])
{
  CEventServer *event_server=CEventServer::instance();
  std::list<TClient_info *>::iterator it;
  int event_id=0,num=0,client_index=0;
  std::list<TClient_info *> info;
  CSocketServer server("server");
  std::list<std::string> events;
  TClient_info *client_info;
  TSocket_info sock_info;
  unsigned char *data;

  try{
    sock_info.port=server_port;
    sock_info.address=server_IP_address;
    server.open(&sock_info);
    server.config(&num_listen);
    server.set_max_clients(5);
    server.start_server();
    while(1)
    {
      try{
        events.clear();
        events.push_back(server.get_new_connection_event_id());
        for(it=info.begin();it!=info.end();it++)
        {
          events.push_back((*it)->rx_event_id);
          events.push_back((*it)->disconnect_event_id);
        }
        event_id=event_server->wait_first(events,1000);
        if(event_id==0)
        {
          std::cout << "new connection ..." << std::endl;
          client_info=server.get_new_client();
          info.push_back(client_info);
          std::cout << "  client id: " << client_info->client_id << std::endl;
          std::cout << "  IP address: " << client_info->IP << " at port " << client_info->port << std::endl;
        }
        else
        {
          event_id--;
          for(it=info.begin();it!=info.end();it++)
          {
            if(event_id>=2)
              event_id-=2;
            else
            {
              if((event_id%2)==1)// disconnect event
              {
                std::cout << "client " << (*it)->client_id << " disconnected." << std::endl;
                server.free_client((*it));
                it=info.erase(it);
              }
              else// rx event
              {
                std::cout << "  data received from " << (*it)->client_id << " ";
                num=server.get_num_data_from((*it)->client_id);
                data=new unsigned char[num];
                server.read_from((*it)->client_id,data,num);
                std::cout << data << std::endl;
                delete[] data;
              }
              break;
            }
          }
        }
      }catch(CEventTimeoutException &e){
        std::cout << "waiting ..." << std::endl;
      }catch(CException &e){
        std::cout << e.what() << std::endl;
      }
    }
  }catch(CException &e){
    std::cout << e.what() << std::endl;
  }    
}
