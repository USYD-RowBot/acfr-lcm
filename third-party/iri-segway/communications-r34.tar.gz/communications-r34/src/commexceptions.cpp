#include "commexceptions.h"
#include <string.h>
#include <stdio.h>

const std::string comm_exception_msg="[CComm class] - ";

CCommException::CCommException(const std::string& where,const std::string& error_msg,const std::string& comm_id):CException(where,comm_exception_msg)
{
  this->error_msg+=error_msg;
  this->error_msg+=" - ";
  this->error_msg+=comm_id;
}
