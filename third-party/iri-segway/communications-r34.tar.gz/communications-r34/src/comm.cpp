#include <string.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include "comm.h"
#include "commexceptions.h"
#include "ctime.h"

CComm::CComm(const std::string& comm_id) 
{
  this->rx_event_id="";
  this->error_event_id="";
  this->comm_thread_id="";
  this->error_msg="";
  this->state=created;
  try{
    this->set_id(comm_id);
    /* get a reference to the event handler */
    this->event_server=CEventServer::instance();
    /* create the events */
    this->rx_event_id+=comm_id;
    this->rx_event_id+="_rx_event_id";
    this->event_server->create_event(this->rx_event_id);
    this->error_event_id+=comm_id;
    this->error_event_id+="_error_event";
    this->event_server->create_event(this->error_event_id);
    /* get the reference to the thread handler */
    this->thread_server=CThreadServer::instance();
    /* create the thread */
    this->comm_thread_id+=comm_id;
    this->comm_thread_id+="_comm_thread";
    this->thread_server->create_thread(this->comm_thread_id);
    /* attach the thread function */
    this->thread_server->attach_thread(this->comm_thread_id,comm_thread,this);
  }catch(CException &e){
    this->close();
    /* delete the events */
    throw;
  }
}

void CComm::set_id(const std::string& comm_id)
{
  if(comm_id.size()==0)
  {
    /* handle exceptions */
    throw CCommException(_HERE_,"Invalid communication id.\n","empty name");
  }
  else
    this->comm_id=comm_id;
}

std::string& CComm::get_id(void)
{
  return this->comm_id;
}

void CComm::open(void *comm_dev)
{
  if(this->state==created)
  {
    try{
      this->access_comm.enter();
      this->hard_open(comm_dev);
      this->thread_server->start_thread(this->comm_thread_id);
      this->state=opened;
      this->access_comm.exit();
    }catch(CException &e){
      this->access_comm.exit();
      /* handle exception */
      throw;
    }
  }
  else
  {
    /* handle exceptions */
    throw CCommException(_HERE_,"The communication device is already opened\n.",this->comm_id);
  }
}

void CComm::config(void *config)
{
  this->access_comm.enter();
  if(this->state==created)
  { 
    this->access_comm.exit();
    /* handle exceptions */
    throw CCommException(_HERE_,"The communication device has not been opened yet.\n",this->comm_id);
  }
  else
  {
    try{
      if(this->state==opened)
        this->state=configured;
      /* otherwise, keep the current state */
      this->hard_config(config);
    }catch(CException &e){
      this->access_comm.exit();
      /* handle exception */
      throw;
    }
  }
  this->access_comm.exit();
}

int CComm::read(unsigned char *data,int len)
{
  int num_available=0;
  int i=0;

  if(data==NULL)
  {
    /* handle exceptions */
    throw CCommException(_HERE_,"Invalid data buffer to save the data received (NULL pointer).\n",this->comm_id);
  }
  else
  {
    if(this->state==configured || this->state==sending)
    {
      this->access_comm.enter();
      num_available=this->receive_queue.size();
      if(len>num_available)
      {
        len=num_available;
        this->event_server->reset_event(this->rx_event_id);
      }
      for(i=0;i<len;i++)
      {
        data[i]=*this->receive_queue.begin();
        this->receive_queue.pop_front();
      }
      this->access_comm.exit();
      return len;
    }
    else
    {
      throw CCommException(_HERE_,"The communication device is not configured yet.\n",this->comm_id);
    }
  }
  return len;
}

int CComm::write(unsigned char *data,int len)
{
  int written_len=0;

  if(data==NULL)
  {
    /* handle exceptions */
    throw CCommException(_HERE_,"Invalid data buffer to be sent (NULL pointer).\n",this->comm_id);
  }  
  else
  {
    this->access_comm.enter();
    if(this->state==configured)
    {
      try{
        written_len=this->hard_write(data,len);
      }catch(CException &e){
        this->access_comm.exit();
        /* handle exceptions */
        throw;
      }
      if(written_len!=len)
      {
        /* handle exceptions */
        this->access_comm.exit();
        throw CCommException(_HERE_,"Unexpected error while writing to the communication device.\n",this->comm_id);
      }
    }
    else
    {
      this->access_comm.exit();
      throw CCommException(_HERE_,"The communication device is not configured yet.\n",this->comm_id);
    }
    this->access_comm.exit();
    return len;
  }
  return len;
}

unsigned int CComm::get_num_data(void)
{
  unsigned int num=0;

  if(this->state==configured || this->state==sending)
  {
    this->access_comm.enter();
    num=this->receive_queue.size();
    this->access_comm.exit();
  }

  return num;
}

std::string& CComm::get_rx_event_id(void)
{
  return this->rx_event_id;
}

std::string& CComm::get_error_event_id(void)
{
  return this->error_event_id;
}

std::string& CComm::get_error(void)
{
  return this->error_msg;
}

int CComm::get_state(void)
{
  return this->state;
}

void CComm::close(void)
{
  if(this->state==configured || this->state==sending || this->state==opened)
  {
    /* finish the thread */
    if(this->state==configured)
      this->thread_server->kill_thread(this->comm_thread_id);
    /* close the communication device */
    this->access_comm.enter();
    try{
      this->hard_close();
    }catch(CException &e){
      this->access_comm.exit();
      /* handle exceptions */
      throw;
    }
    /* flush the data queues */
    this->receive_queue.erase(this->receive_queue.begin(),this->receive_queue.end());
    /* change the current state */
    this->state=created;
    this->access_comm.exit();
  }
}

void *CComm::comm_thread(void *param)
{
  CComm *comm_dev=(CComm *)param;
  int wait_result;
  bool end=false;

  while(!end)
  {
    wait_result=comm_dev->hard_wait_comm_event();
    comm_dev->access_comm.enter();
    if(wait_result==-1)
      end=true;
    else
    {
      if(wait_result==1)/* data has been received */
      {
        comm_dev->on_receive(); 
      }
      if(wait_result==2)
      {
        comm_dev->on_error();
      }
    }
    comm_dev->access_comm.exit();
  }
  /* handle exceptions */
//  throw CCommException(_HERE_,"Unexpected error while waiting for new data.\n",comm_dev->comm_id);

  return NULL;
}

void CComm::on_receive(void)
{
  unsigned char *data=NULL;
  int num=0,num_read=0,i=0;

  if((num=this->hard_get_num_data())==-1)
  {
    /* handle exceptions */
    throw CCommException(_HERE_,"Impossible to get the number of new data available on the communication device.\n",this->comm_id);
  }
  data=new unsigned char[num];
  if((num_read=this->hard_read(data,num))==-1)
  {
    delete[] data;
    /* handle exceptions */
    throw CCommException(_HERE_,"Impossible to read from the communication device.\n",this->comm_id);
  }
  else
  {
    if(num_read!=num)
    {
      delete[] data;
      /* handle exceptions */
      throw CCommException(_HERE_,"Not all desired data has been read from the communicationd device.\n",this->comm_id);
    }
    else
    {
      for(i=0;i<num;i++)
        this->receive_queue.push_back(data[i]);
      if(!this->event_server->event_is_set(this->rx_event_id))
      {
        this->event_server->set_event(this->rx_event_id);
      }
      delete[] data;
    }
  }
}

void CComm::on_error(void)
{
  /* handle exceptions */
}

CComm::~CComm()
{
  /* delete the events */
  if(this->rx_event_id.size()!=0)
    this->event_server->delete_event(this->rx_event_id);
  if(this->error_event_id.size()!=0)
  {
    this->event_server->delete_event(this->error_event_id);
  }
  /* delete the thread */
  if(this->comm_thread_id.size()!=0)
  {
    this->thread_server->delete_thread(this->comm_thread_id);
  }
}
