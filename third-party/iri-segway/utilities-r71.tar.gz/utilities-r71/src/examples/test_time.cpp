// Copyright (C) 2009-2010 Institut de Robòtica i Informàtica Industrial, CSIC-UPC.
// Author Martí Morta  (mmorta@iri.upc.edu)
// All rights reserved.
//
// This file is part of iriutils
// iriutils is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

/*! \example test_time.cpp
    \brief This test checks all functions in CTime class.
    
    This example tests time creation and set, time operations (-,+,==,/), get
    time in different formats and throws an exception.

    This example output will be something similar to this:
    \verbatim

  TIME MANAGER EXAMPLE
  Example: create times (t0,t1,t2)

    t0: 1266942571 040254747
    
  Example: sleep 300 ms 

  Example: set t1 [0.300r]

    t1: 1266942571 340338484
    t1o: 0 300083737

  Example: set t3 delayed 300 ms [0.300a]

    t3: 0 300000000

  Example: sleep 1705 ms 

  Example: set t2 [2.005r]

    t2: 1266942573 045406666
    t2o: 2 005151919

  Example: t2 - t1 [1.705]

    td: 1 705068182
    tdo: 1 705068182

  Example: + addition (t1+t2)

    ts: 2533885144 385745150
    tso: 2 305235656

  Example: + Exception (overvalue)

[Exception caught] - CTime CTime::operator+(CTime&) at time/CTime.cpp:129
Error: [CTime class] - Result higher than ulong max

  Example: average (t1,t2)

    ta: 1266942572 192872524
    tao: 1 152617827

  Example: comparative (t1==t2, t3==t2)

    ?: false true

  Example: getting time (t1)

    double Seconds:
     1.26694e+09
     0.3
    double milliseconds:
     4.22219e+09
     300
    Format 0: 
     1266942571 340338484
     0 300083737
    Format ctf_datetime: 
     2010-02-23,17:29:31
     1970-01-01,01:00:00
    Format ctf_ms: 
     1266942571.340
     0.300
    Timespec
     1266942571 340338484
    Time_t
     1266942571
     some formats using time_t
       2010-02-23,17:29:31
       05:29PM
       Tue Feb 23 17:29:31 2010

  Example: END

    \endverbatim
    
    In this example namespace std is used because cout and endl are used 
    a lot.
  
    The example code is the following:
    
*/


#include "ctime.h"
#include <iostream>
#include <unistd.h>

using namespace std;

int main(void)
{
  cout << "\nTIME MANAGER EXAMPLE" << endl;
  
  cout << "  Example: create times (t0,t1,t2)\n\n";
    CTime t0,t1,t2,t3,t20,td,ta,td0,ta0,ts,ts0,ta2,ta20;
    cout << "    t0: " << t0 << endl;

  cout << "\n  Example: sleep 300 ms " << endl;
    usleep(300000);
  
  cout << "\n  Example: set t1 [0.300r]\n\n";
    t1.set();
    CTime t10 = t1 - t0;
    cout << "    t1: " << t1 << "\n    t1o: " << t10 << endl;
  
  cout << "\n  Example: set t3 delayed 300 ms [0.300a]\n\n";
    t3.set(300);
    cout << "    t3: " << t3 << endl;

  cout << "\n  Example: sleep 1705 ms " << endl;
    usleep(1705000);
  
  cout << "\n  Example: set t2 [2.005r]\n\n";
    t2.set();
    t20 = t2 - t0; 
    cout << "    t2: " << t2 << "\n    t2o: " << t20 << endl;

  cout << "\n  Example: t2 - t1 [1.705]\n\n";
    td = t2 - t1;
    td0 = t20 - t10;
    cout << "    td: " << td << "\n    tdo: " << td0 << endl;

  cout << "\n  Example: + addition (t1+t2)\n\n";
    ts = t1 + t2;
    ts0 = t10 + t20;
    cout << "    ts: " << ts << "\n    tso: " << ts0 << endl;
  
  cout << "\n  Example: + Exception (overvalue)\n\n";
    try{
      ts = ts + ts;
    }catch(CException &e)
    {
      cout << e.what() << endl;
    }

  cout << "\n  Example: average (t1,t2)\n\n";
    ta = ( t1 + t2 ) / 2;
    ta0 = (t10 + t20)/2 ;
    cout << "    ta: " << ta << "\n    tao: " << ta0 << endl;

  cout << "\n  Example: comparative (t1==t2, t3==t2)\n\n";
    t3 = t2;
    cout << "    ?: " <<  boolalpha << (bool)(t1==t2) << " " 
                                    << (bool)(t3==t2)  << endl;

  
  cout << "\n  Example: getting time (t1)\n\n";
    cout << "    double Seconds:"                 << endl
        << "     " << t1.getTimeInSeconds()       << endl
        << "     " << t10.getTimeInSeconds()      << endl
        << "    double milliseconds:"             << endl
        << "     " << t1.getTimeInMilliseconds()  << endl
        << "     " << t10.getTimeInMilliseconds() << endl;
    
    t1.setFormat(ctf_secnano);
    t10.setFormat(ctf_secnano);
    cout << "    Format ctf_secnano: "  << endl 
        << "     "          << t1       << endl
        << "     "          << t10      << endl;
    
    t1.setFormat(ctf_datetime);
    t10.setFormat(ctf_datetime);
    cout << "    Format ctf_datetime: " << endl 
        << "     "          << t1       << endl
        << "     "          << t10      << endl;
    
    t1.setFormat(ctf_ms);
    t10.setFormat(ctf_ms);
    cout << "    Format ctf_ms: "       << endl 
        << "     "          << t1       << endl
        << "     "          << t10      << endl;
    
    timespec t1t;
    t1t = t1.getTimeInTimespec();
    cout << "    Timespec" << endl;
    cout << "     " << t1t.tv_sec << " " << t1t.tv_nsec << endl;
    
    time_t t1tt;
    struct tm * timeinfo;
    char buffer [80];
    t1tt = t1.getTimeInTime_t();
    cout << "    Time_t" << endl;
    cout << "     " << t1tt << endl;
    timeinfo = localtime ( &t1tt );
    cout << "     some formats using time_t" << endl;
    strftime (buffer,80,"%F,%T\n       %I:%M%p\n       %c",timeinfo);
    cout << "       " << buffer << endl;

  cout << "\n  Example: END\n\n";

	return(1);
}

