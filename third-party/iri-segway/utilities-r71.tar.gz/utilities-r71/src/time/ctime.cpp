// Copyright (C) 2009-2010 Institut de Robòtica i Informàtica Industrial, CSIC-UPC.
// Author Sergi Hernandez  (shernand@iri.upc.edu)
// All rights reserved.
//
// This file is part of iriutils
// iriutils is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include "ctime.h"

// ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┅┅
// ┃ CONSTRUCTOR / DESTRUCTOR
// ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┅┅
// │  ▸ CONSTRUCTOR
// │     set own_time to current time
// └─────────────────────────────────────────────────────────────────────────┈┈
CTime::CTime()
{
  this->set();
  this->setFormat(ctf_secnano);
}

CTime::CTime(double relative)
{
  this->set(relative);
}

// │  ▸ DESTRUCTOR
// └─────────────────────────────────────────────────────────────────────────┈┈
CTime::~CTime()
{
}

// ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┅┅
// ┃ GET TIME
// ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┅┅
// │  ▸ IN SECONDS
// │     1.234
// └─────────────────────────────────────────────────────────────────────────┈┈
double CTime::getTimeInSeconds(void)
{
  return (double)(this->sec) + this->nsec/1000000000;
}

// │  ▸ IN MILLISECONDS
// │     1234
// └─────────────────────────────────────────────────────────────────────────┈┈
double CTime::getTimeInMilliseconds(void)
{
  return ( (double) ( this->sec * 1000 + this->nsec / 1000000 ));
}

long CTime::getTimeInMicroseconds(void)
{
  return ( (double) ( this->sec * 1000000 + this->nsec / 1000 ));
}

// │  ▸ IN TIMESPEC
// │     timespec { 1, 234000000 }
// └─────────────────────────────────────────────────────────────────────────┈┈
timespec CTime::getTimeInTimespec(void)
{
  timespec t;

  t.tv_sec = (long) this->sec;
  t.tv_nsec = (long) this->nsec;

  return t;
}

timeval CTime::getTimeInTimeval(void)
{
  timeval t;

  t.tv_sec = (long) this->sec;
  t.tv_usec = (long) (this->nsec/1000);

  return t;
}

time_t CTime::getTimeInTime_t(void)
{
  return (time_t)this->sec;
}

// ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┅┅
// ┃ SET TIME
// ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┅┅
// │  ▸ SET (Current time)
// └─────────────────────────────────────────────────────────────────────────┈┈
void CTime::set(double milliseconds)
{
  timespec time_temp;

  if(milliseconds<0.0)
  {
    clock_gettime(CLOCK_REALTIME, &time_temp );
  }
  else
  {
    time_temp = this->msToTimespec(milliseconds);
  }
  this->sec = time_temp.tv_sec;
  this->nsec = time_temp.tv_nsec;
}

// ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┅┅
// ┃ OPERATIONS
// ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┅┅
// │  ▸ -
// └─────────────────────────────────────────────────────────────────────────┈┈
CTime CTime::operator - (CTime &t)
{
  CTime tmp;

  if ( (long)this->nsec - (long)t.nsec < 0 ) 
  {
    tmp.sec  = this->sec - t.sec - 1;
    tmp.nsec = 1000000000 + this->nsec - t.nsec;
  } else {
    tmp.sec  = this->sec  - t.sec;
    tmp.nsec = this->nsec - t.nsec;
  }

  return tmp;
}

// │  ▸ +
// └─────────────────────────────────────────────────────────────────────────┈┈
CTime CTime::operator + (CTime &t)
{
  CTime tmp;
  unsigned long tn;

  if ( (double)this->sec + (double)t.sec < ULONG_MAX )
  {
    tn    = this->nsec + t.nsec;
    tmp.sec = this->sec  + t.sec;

    if( tn / 1000000000 > 0) 
      tmp.sec++;

    tmp.nsec = (this->nsec + t.nsec) % 1000000000;
  }else{
    throw CTimeException(_HERE_,"Result higher than ulong max");
  }
  
  return tmp;
}

// │  ▸ /
// └─────────────────────────────────────────────────────────────────────────┈┈
CTime CTime::operator / (int div)
{
  CTime tmp;
  double s,ns,t;

  t = (double) this->sec + (((double) this->nsec) / 1000000000) ;
  t /= div;
  ns = modf( t , &s);
  
  tmp.sec  = (unsigned long) s;
  tmp.nsec = (unsigned long)(  ns * 1000000000 );
  
  return tmp;
}

// │  ▸ ==
// └─────────────────────────────────────────────────────────────────────────┈┈
bool CTime::operator == (CTime &t)
{
  return( (this->sec == t.sec) && (this->nsec == t.nsec) );
}

// │  ▸ << 
// │      with format 
// └─────────────────────────────────────────────────────────────────────────┈┈
std::ostream& operator << (std::ostream &o,CTime &t)
{
  o << t.getString();

  return o;
}

// │  ▸ GET STRING
// └─────────────────────────────────────────────────────────────────────────┈┈
std::string CTime::getString()
{
  int ms=0;
  char outstr [80];
  struct tm * timeinfo;
  std::string extra_zero;  
  std::stringstream output;

  switch(this->print_format)
  {
    default:
    case ctf_secnano:
      //o << t.own_time.tv_sec << " " << t.own_time.tv_nsec;
      if(this->nsec<10)             extra_zero = "00000000";
      else if(this->nsec<100)       extra_zero = "0000000";
      else if(this->nsec<1000)      extra_zero = "000000";
      else if(this->nsec<10000)     extra_zero = "00000";
      else if(this->nsec<100000)    extra_zero = "0000";
      else if(this->nsec<1000000)   extra_zero = "000";
      else if(this->nsec<10000000)  extra_zero = "00";
      else if(this->nsec<100000000) extra_zero = "0";
      output << this->sec << " " << extra_zero << this->nsec;
    break;
    case ctf_datetime:
      timeinfo = localtime ( (time_t *)&this->sec );
      strftime (outstr,23,"%F,%T",timeinfo);
      output << outstr;
    break;
    case ctf_ms:
      ms = round( this->nsec/1000000 );
      if(ms<100 && ms>0) extra_zero = "0";
      if(ms<10  && ms>0)  extra_zero = "00";
      output << this->sec << "." << extra_zero << ms ;
    break;
  }

  return output.str();
}

// │  ▸ SET FORMAT
// └─────────────────────────────────────────────────────────────────────────┈┈
void CTime::setFormat(ctimeformat format)
{
  this->print_format = format;
}

// │  ▸ GET FORMAT
// └─────────────────────────────────────────────────────────────────────────┈┈
ctimeformat CTime::getFormat()
{
  return this->print_format;
}


// ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┅┅
// ┃ CONVERSION
// ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┅┅
// │  ▸ timespec to milliseconds
// └─────────────────────────────────────────────────────────────────────────┈┈
double CTime::timespecToMs( timespec time )
{
  return( time.tv_sec*1000.0 + (time.tv_nsec/1000000.0) );
}

// │  ▸ milliseconds to timespec
// └─────────────────────────────────────────────────────────────────────────┈┈
timespec CTime::msToTimespec( double time_ms )
{
  timespec temp;

  double seconds = (double)time_ms/1000.0;
  temp.tv_sec  = (long)floor(seconds);
  temp.tv_nsec = (long)floor((seconds-temp.tv_sec)*1000000000);

  return temp;
}


