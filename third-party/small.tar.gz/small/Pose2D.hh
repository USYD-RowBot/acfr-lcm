/** 
 * \file Pose2D.hh
 * \brief Poses in 2D.
 * A pose in two dimensions for a rigid object. A pose includes two spatial dimensions 
 * (position) and one orientational dimension (rotation) for a total of 3 DOF.
 *
 * \author Mike Bosse and Robert Zlot
 * \date Aug 2007
 * \version $Revision $ 
 * 
 * Copyright (c) 2007-2011 CSIRO Autonomous Systems Laboratory
 * 
 */


/***********************************************************
 *
 * This file is part of SMALL.
 *
 *  SMALL is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SMALL is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with SMALL.  If not, see <http://www.gnu.org/licenses/>.
 *
 ************************************************************/

#ifndef _SMALL__POSE_2D_HH_
#define _SMALL__POSE_2D_HH_


/* Standard includes */
#include <iostream>
#include <cmath>
#include <cassert>

/* ASL includes */
#include "linalg.hh"
#include "Rotation2D.hh"

/** \namespace SMALL 
 * \brief Spatial Math And LinAlg Library
 **/
namespace SMALL
{

  /**
   * \class Pose2D
   *
   * \brief Implements a 2D pose (two positional and one orientation value)
   *
   * A pose in two dimensions for a rigid object.  A pose includes two spatial dimensions (position)
   * and a rotation angle (orientation) for a total of 3 DOF.
   *
   **/
  class Pose2D : public Rotation2D {

  private:
    Vector2D t;

  public:

    /** \name Constructors */
    /// @{
    /** \brief Initialize with identity pose: position 0,0 with identity rotation */
    Pose2D () { setIdentity(); }

    /** \brief Initialize given a position/translation and a rotation */
    Pose2D ( const Vector2D &t_, const Rotation2D &R) : Rotation2D(R), t(t_) {}  

    /** \brief Initialize given a position/translation and a rotation */
    Pose2D ( const Rotation2D &R, const Vector2D &t_) : Rotation2D(R), t(t_) {}  

    /** \brief Initialize given only a rotation (positional part is set to zero). */
    Pose2D ( const Rotation2D &R) : Rotation2D(R) { t.zero(); }  

    /** \brief Initialize given only a translation (rotation is set to identity). */
    Pose2D ( const Vector2D &t_ ) : t(t_) { Rotation2D::setIdentity(); }

    /** \brief Initialize given (x,y,theta) values (theta in radians) */
    Pose2D ( double X, double Y, double Th ) { set(X,Y,Th); }

    /** \brief Initialize given a 3-vector (x,y,theta) */
    Pose2D ( const Vector3D &p ) { set(p); }

    /** \brief Initialize given a 3x3 homogeneous transformation matrix */
    Pose2D ( const Matrix33 &Rt ){
      Matrix22 R = Rt.sub<0,1,0,1>();
      setRotation(R);
      t = Rt.sub<0,1,2,2>();
    }

    /** \brief Initialize given a 2x3 transformation matrix */
    Pose2D ( const Matrix23 &Rt ){
      Matrix22 R = Rt.sub<0,1,0,1>();
      setRotation(R);
      t = Rt.sub<0,1,2,2>();
    }

    /** \brief Warning: Do not use this function as it has been marked for removal in 
     *  the near future.
     *  Initialize given a position/translation and a rotation angle (in radians) 
     * \deprecated Warning: this function slated to be removed by Feb 2008 */
    //Pose2D ( const Vector2D &t_, double th ) __attribute__ ((deprecated)) : Rotation2D(th), t(t_) {};  
    
    /** \brief Warning: Do not use this function as it has been marked for removal in 
     *  the near future.
     *  Initialize given a position/translation and a rotation angle (in radians)
     * \deprecated Warning: this function slated to be removed by Feb 2008 */
    //Pose2D ( double th, const Vector2D &t_ ) __attribute__ ((deprecated)) : Rotation2D(th), t(t_) {};

    /// @}
  

    /* ACCESSORS (GETTING) */

    /** \name Pose2D Access and conversion
     * Pose access and conversion to various representations. 
     */

    /// @{
    /** \brief Get positional values
     *  \return A vector containing (X,Y) values */
    Vector2D getPosition() const { return t; }
    /** \brief Get X component of position
     *  \return X */
    double getX( void ) const { return t[0]; }
    /** \brief Get Y component of position
     *  \return Y */
    double getY( void ) const { return t[1]; }

    /** \brief Get the rotation */
    const Rotation2D &getRotation() const { return *((Rotation2D *)this); }

    /** \brief Get the pose represented as a 2x3 transformation matrix [R t] 
     * \return A 2x3 transformation matrix with the first 2x2 submatrix the rotation matrix, and the 3th column the 2x1 position (translation) */
    Matrix23 get2x3TransformationMatrix() const {
      Matrix22 R = getRotationMatrix();
      Vector2D t = getPosition();
      return concat(R,t);
    }

    /** \brief Get the pose represented as a 3x3 homogeneous coord transformation matrix 
     *  \return A 3x3 transformation matrix in homogeneous coordinates with the rotation matrix the upper left 2x2 submatrix, and the position (translation) the 3th column. The third row is 0,0,1. */
    Matrix33 get3x3TransformationMatrix() const {
      Matrix<1,3,double> bottom; bottom = 0.0,0.0,1.0;
      return stack(get2x3TransformationMatrix(),bottom);
    }
    /// @}

    /** \name Pose2D Assignment and conversion 
     * Set pose using a variety of representations. 
     */
    /// @{

    /** \brief Set the pose given a position vector and a rotation. */
    Pose2D &set( const Vector2D &t, const Rotation2D &R) {this->t = t; setRotation(R); return *this; }
    /** \brief Set the pose given a position vector and a rotation. */
    Pose2D &set( const Rotation2D &R, const Vector2D &t) {this->t = t; setRotation(R); return *this; }
    /** \brief Set the pose given a position vector and a rotation angle (in radians). */
    Pose2D &set( const Vector2D &t, double angle ) {this->t = t; setThetaRad(angle); return *this; }
    /** \brief Set the pose given a position vector and a rotation angle (in radians). */
    Pose2D &set( double angle, const Vector2D &t ) {this->t = t; setThetaRad(angle); return *this; }
    /** \brief Set the pose given (x,y,theta) values (theta in radians) */
    Pose2D &set( double X, double Y, double angle ){ this->t = X,Y; setThetaRad(angle); return *this; }
    /** \brief Set the pose given a 3-vector (x,y,theta) */
    Pose2D &set( const Vector3D &p ){ t = p[0],p[1]; setRotation(p[2]); return *this; }
    
    /** \brief Set the X position. */
    Pose2D &setX( double X ){ t[0]=X; return *this; };
    /** \brief Set the Y position. */
    Pose2D &setY( double Y ){ t[1]=Y; return *this; };
    /** \brief Set the X,Y position */
    Pose2D &setPosition( double X, double Y ){
      t = X,Y;
      return *this;
    }
    /** \brief Set the position given a vector (x,y) */
    Pose2D &setPosition( const Vector2D &t_ ) { t = t_; return *this; }

    /** \brief Set the position and rotation from a 3x3 homogeneous transform matrix */
    Pose2D &set( const Matrix33 &Rt ) {
      Matrix22 R = Rt.sub<0,1,0,1>();
      setRotation(R);
      t = Rt.sub<0,1,2,2>();
      return *this;
    }

    /** \brief Set the position and rotation from a 2x3 transform matrix (3x3 with last row implicitly 0,0,1) */
    Pose2D &set( const Matrix23 &Rt ) {
      Matrix22 R = Rt.sub<0,1,0,1>();
      setRotation(R);
      t = Rt.sub<0,1,2,2>();
      return *this;
    }

    /** \brief Sets the Pose2D to the identity transformation 
     *
     * Equivalent to \link zero() \endlink
     **/
    Pose2D &setIdentity() {
      Rotation2D::setIdentity();
      t.zero();
      return *this;
    }

    /** \brief Sets the Pose2D to zero
     *
     * Equivalent to \link setIdentity() \endlink
     **/
    Pose2D &zero() {
      return setIdentity();
    }

    /** \brief Wrap the angle so that it is in the range \f$[ -\pi, \pi ] \f$
     *
     * \note Overloads the Rotation2D::wrapAngle() so that it returns a Pose2D 
     **/    
    Pose2D &wrapAngle() {
      Rotation2D::wrapAngle();
      return *this;
    }

    /// @}


    /** \name Pose2D Transformations and compositions
     *  
     *  Transform vectors between pose coordinate frames; compose and invert transformations.
     *
     *  These transformations provide the ability to transform a vector represented in
     *  the coordinate frame represented by the pose into a base frame (at the origin)
     *  or vice versa.
     *
     *  For example if the Pose2D represents a robot frame with respect to
     *  a ground frame, then the vector can be transformed from the robot
     *  frame representation to a ground frame representation.  
     *
     */
    //@{
    /**  
     * \brief Transform a vector from the Pose2D frame to the base coordinate frame.
     *
     * \note Equivalent to operator*(x)
     *
     * \param x A vector represented in the Pose3D frame
     * \return The vector represented in the base frame
     */
    Vector2D transformFrom(const Vector2D &x) const {
      return t + rotate(x);
    }

    /** \brief Transform a vector from the Pose2D frame to the base coordinate frame.
     *
     * \note Equivalent to transformFrom(x)
     *
     * \param x A vector represented in the Pose3D frame
     * \return The vector represented in the base frame
     */
    Vector2D operator*(const Vector2D &x) const { return transformFrom(x); }

    /**    
     * \brief Transform a vector from the Pose2D frame to the base coordinate frame.
     *
     * \details The coordinates are given in the Pose2D frame and overwritten to be
     * in the base frame.
     *
     * \param x X-coordinate 
     * \param y Y-coordinate
     */
    void transformFrom(double &x, double &y) const {
      Vector2D v; v = x,y;
      Vector2D vt = transformFrom(v);
      x = vt[0]; y = vt[1];
    }

    /** \brief Transform a vector from the base coordinate frame to the Pose2D frame. 
     *  \note Same as inverse().transformFrom()
     *
     *  \param x A vector represented in the base frame
     *  \return The vector represented in the Pose2D frame
     */
    Vector2D transformTo(const Vector2D &x) const { return inverse().transformFrom(x); }

    /** \brief Transform a vector from the base coordinate frame to the Pose2D frame. 
     *  \note Same as inverse().transformFrom()
     *
     * \details The coordinates are given in the base frame and overwritten to be
     * in the Pose2D frame.
     *
     * \param x X-coordinate
     * \param y Y-coordinate 
     */
    void transformTo(double &x, double &y){
      inverse().transformFrom(x,y);
    }

    /** \brief Composes two poses (transformations).  
     * 
     * For example, if the Pose2D A represents a body frame with respect to
     * a ground frame, and the Pose2D B represents a sensor frame with
     * respect to the body frame, then A.compose(B) represents the
     * the sensor frame with respect to the ground frame. 
     *
     * \note Equivalent to operator*(B)
     *
     * \param B The Pose2D to compose with in the body frame
     * \return The composite pose 
     */
    Pose2D compose(const Pose2D &B) const { 
      return Pose2D(transformFrom(B.t), Rotation2D::compose(B.getRotation()));
    }
    /** \brief Composes two poses (transformations).  
     * 
     * For example, if the Pose2D A represents a body frame with respect to
     * a ground frame, and the Pose2D B represents a sensor frame with
     * respect to the body frame, then A.compose(B) represents the
     * the sensor frame with respect to the ground frame. 
     *
     * \note Equivalent to compose(B)
     *
     * \param B The Pose2D to compose with in the body frame
     * \return The composite pose 
     */
    Pose2D operator*(const Pose2D &B) const { return this->compose(B); }
  
    /** \brief Invert a pose (transformation).
     * 
     * For example, if the Pose2D A represents a body frame with respect to
     * a ground frame, and the A.inverse() Pose2D represents the ground frame with
     * respect to the body frame.
     *
     * \note Equivalent to A.i()
     *
     * \return The inverse pose */
    Pose2D inverse() const {
      Rotation2D Ri = getRotation().inverse();
      return Pose2D( Ri.rotate(-t), Ri);
    }
  
    /** \brief Invert a pose (transformation).
     * 
     * For example, if the Pose2D A represents a body frame with respect to
     * a ground frame, and the A.inverse() Pose2D  represents the ground frame with
     * respect to the body frame.  
     *
     * \note Equivalent to A.inverse()
     *
     * \return The inverse pose */
    Pose2D i() const { return inverse(); }


    /** \brief element by element addition */
    Pose2D operator+(const Pose2D &B) const { 
      return Pose2D(getX()+B.getX(), getY()+B.getY(), getThetaRad()+B.getThetaRad()); 
    }

    /** \brief element by element subtraction */
    Pose2D operator-(const Pose2D &B) const { 
      return Pose2D(getX()-B.getX(), getY()-B.getY(), getThetaRad()-B.getThetaRad()); 
    }


    //@}


    /** \name Pose2D Queries */
    /// @{
    /** \brief Find the transformation required to take this pose to another pose.  
     * 
     * For example if the Pose2D A represents a body frame with respect
     * to a ground frame, and the Pose2D B represents a sensor frame
     * with respect to the ground frame, then A.delta(B) represents the
     * sensor frame with respect to the body frame.
     *
     **/
    Pose2D delta(const Pose2D &B) const {
      const Pose2D &A = *this;
      return A.i()*B;
    }

    /** \brief Test equality: position and angles must all be equal. 
     * 
     * \param B A pose to compare to
     */
    bool operator== (const Pose2D &B) const {
      const double maxError = 1e-8;
      Vector2D dt = t - B.t;
      double normt = dt.normSq();
      return (normt < maxError && (getRotation() == B.getRotation()));
    }

    /** \brief Test inequality: any of the position or angles are not equal 
     *
     * \param B A pose to compare to
     */
    bool operator!= (const Pose2D &B) const {
      return !(*this==B);
    }


    /** \brief Compute the positional distance between this pose and another pose B. 
     * \return The distance between the position represented by this pose and pose B.
     */
    double positionDistance(const Pose2D &B) const {
      return Vector2D(this->t-B.t).norm();
    }

    /** \brief Compute the positional distance between this pose and a point. 
     * \return The distance between the position represented by this pose and v.
     */
    double positionDistance(const Vector2D &v) const {
      return Vector2D(this->t-v).norm();
    }

    /** \brief Compute the square of the positional distance between this pose and another pose B.
     * \return The squared distance between the position represented by this pose and pose B.
     */
    double positionDistanceSq(const Pose2D &B) const {
      return Vector2D(this->t-B.t).normSq();
    }

    /** \brief Compute the square of the positional distance between this pose and a point.
     * \return The squared distance between the position represented by this pose and v.
     */
    double positionDistanceSq(const Vector2D &v) const {
      return Vector2D(this->t-v).normSq();
    }

    /** \brief Linear interpolation of a Pose2D. 
     *
     * Computes the interpolation between this pose and another with
     * the linear factor alpha.  When alpha is zero it returns this
     * pose, when alpha is 1.0 it returns the other pose.
     *
     * \param B The other pose 
     * \param alpha The linear interpolant factor
     * \returns The interpolated pose  */
    Pose2D interp(const Pose2D &B, double alpha) const {
      const Pose2D &A = *this;
      return Pose2D(A.getPosition()*(1.0-alpha)+B.getPosition()*alpha,
                    A.getRotation().interp(B.getRotation(),alpha));
    }

    /// @}


    /** \brief Represent the pose as a string.
     *
     * \return A string containing the Cartesian position followed by the rotation angle in radians.
     * E.g., ([ 1.2; 3.14; ], [ 1.4; ])
     **/
    std::string toString( void ) const{
      char buf[64];
      sprintf(buf,"(%g %g %g)",getPosition()[0],getPosition()[1],getRotation().getThetaRad());
      //return "(" + getPosition().toString() + ", " + getRotation().toString() + ")";
      return std::string(buf);
    }

    /* PRINTING */
    /** \brief Print a pose to an output stream.
     * The Cartesian position is printed followed by the rotation angle in radians.
     * E.g., ([ 1.2; 3.14; ], [ 1.4; ])
     *
     * \param os An output stream
     * \param p A pose
     */
    friend std::ostream &operator<<(std::ostream &os, const Pose2D &p) {
      return os << "(" << p.getPosition() << ", " << p.getRotation() << ")";
    }


    /** \name Transformation Jacobians */
    /// @{

    /// \brief Jacobian of M1.compose(M2) w.r.t. M1
    Matrix33 J1(const Pose2D &M2) const
    {
      const Pose2D &M1 = *this;
      double c = M1.getCosTheta();
      double s = M1.getSinTheta();
      Matrix33 J;
      J(1,1) = 1; J(1,2) = 0; J(1,3) = -s*M2.getX()-c*M2.getY();
      J(2,1) = 0; J(2,2) = 1; J(2,3) = +c*M2.getX()-s*M2.getY();
      J(3,1) = 0; J(3,2) = 0; J(3,3) = 1;
        
      return J;
    }

    /// \brief Jacobian of M1.compose(M2) w.r.t. M2
    Matrix33 J2(const Pose2D &M2) const { return JMd(); }

    /// \brief Jacobian of M1.inverse() w.r.t. M1
    Matrix33 Ji() const
    {
      const Pose2D &M1 = *this;
      double c = M1.getCosTheta();
      double s = M1.getSinTheta();
      Matrix33 J;
      J(1,1) = -c; J(1,2) = -s; J(1,3) = s*M1.getX()-c*M1.getY();
      J(2,1) =  s; J(2,2) = -c; J(2,3) = c*M1.getX()+s*M1.getY();
      J(3,1) =  0; J(3,2) =  0; J(3,3) = -1;
        
      return J;
    }

    /// \brief Jacobian of delta.compose(M) w.r.t. delta,  |delta| << 1
    Matrix33 JdM() const
    {
      const Pose2D &M = *this;
      // note: M is this object, delta is implied
      Matrix33 J;
      J(1,1) = 1; J(1,2) = 0; J(1,3) = -M.getY();
      J(2,1) = 0; J(2,2) = 1; J(2,3) = +M.getX();
      J(3,1) = 0; J(3,2) = 0; J(3,3) = 1;
        
      return J;
    }

    /// \brief Jacobian of M.compose(delta) w.r.t. delta,  |delta| << 1
    Matrix33 JMd() const
    {
      const Pose2D &M = *this;

      double c = M.getCosTheta();
      double s = M.getSinTheta();
      Matrix33 J;
      J(1,1) = c; J(1,2) = -s; J(1,3) = 0;
      J(2,1) = s; J(2,2) =  c; J(2,3) = 0;
      J(3,1) = 0; J(3,2) =  0; J(3,3) = 1;
        
      return J;
    }

    /// \brief Jacobian of M1.compose( delta.compose(M2)) from chain rule
    Matrix33 JMdM(const Pose2D &M2) const
    {
      const Pose2D &M1 = *this;
      return M1.JMd() * M2.JdM();
    }

    /// \brief Jacobian of M.compose( delta.compose(M.inverse()))
    ///
    /// an optimization for M1.JMdM(M2) when M2 = M1.inverse() 
    Matrix33 JMdMi() const
    {
      const Pose2D &M = *this;

      double c = M.getCosTheta();
      double s = M.getSinTheta();
      Matrix33 J;
      J(1,1) = c; J(1,2) = -s; J(1,3) =  getY();
      J(2,1) = s; J(2,2) =  c; J(2,3) = -getX();
      J(3,1) = 0; J(3,2) =  0; J(3,3) =  1;
        
      return J;
    }

    /// @}

  private:
    /* These are defined to overwrite the inherited functions from Rotation2D */
    
    /** \brief Find the rotation required to take this orientation to 
     *  another orientation.  
     * 
     * For example if the Rotation2D A represents a body orientation with 
     * respect to a ground orientation, and the Rotation2D B represents a 
     * sensor orientation with respect to the ground orientation, then A.delta(B) 
     * represents the sensor orientation with respect to the body orientation.
     *
     * Should fail on assertion (don't compare a pose to a rotation!)
     **/
    Rotation2D delta(const Rotation2D &B) const {
      bool thisFunctionIsAvailable = false;
      assert( thisFunctionIsAvailable );
      return B; // using B to avoid compiler warning
    }

    /** \brief Equality test: reimplemented from Rotation2D class. 
     *
     * Just returns false (don't compare a pose to a rotation!)
     **/
    bool operator== (const Rotation2D &B) const {
      bool thisFunctionIsAvailable = false;
      assert( thisFunctionIsAvailable );
      return false && B.check(); // using B to avoid compiler warning
    }
    /** \brief Inequality test: reimplemented from Rotation2D class.
     *
     * Just returns true (don't compare a pose to a rotation!)
     **/
    bool operator!= (const Rotation2D &B) const {
      bool thisFunctionIsAvailable = false;
      assert( thisFunctionIsAvailable );
      return true || B.check(); // using B to avoid compiler warning
    }

    /** \brief Linear Interpolation: reimplemented from Rotation2D class
     *
     * Should fail on assertion (don't interpolate a pose with a rotation)
     **/
    Rotation2D interp(const Rotation2D &B, double alpha) const{
      bool thisFunctionIsAvailable = false;
      assert( thisFunctionIsAvailable );
      return Rotation2D(alpha)*B; // using B,alpha to avoid compiler warning
    }

  };  /* -- End of class Pose2D -- */

} // end of namespace SMALL

#endif /* _SMALL__POSE_2D_HH_ */
