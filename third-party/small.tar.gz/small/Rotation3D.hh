/** 
 * \file Rotation3D.hh
 * \brief Rotations in 3D.
 * 
 *
 * \author Mike Bosse and Robert Zlot
 * \date July 2007
 * \version $Revision $ 
 * 
 * Copyright (c) 2007-2011 CSIRO Autonomous Systems Laboratory
 * 
 */

/***********************************************************
 *
 *
 * This file is part of SMALL.
 *
 *  SMALL is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SMALL is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with SMALL.  If not, see <http://www.gnu.org/licenses/>.
 *
 ************************************************************/

#ifndef _SMALL__ROTATION3D_HH_
#define _SMALL__ROTATION3D_HH_

/* Standard includes */
#include <iostream>
#include <cmath>
#include <vector>

/* ASL includes */
#include "linalg.hh"
#include "Rotation2D.hh"

/** \namespace SMALL 
 * \brief Spatial Math And LinAlg Library
 **/
namespace SMALL
{

  /** \name Misc 3D Rotation Convertions */
  /// @{
  /** \brief Create a 3x3 rotation Matrix from an axis,angle representation
   *
   * Axis,angle representation of a rotation contains a ColVector representing
   * the rotation axis, and a scalar representing the magnitude of a rotation.
   * This uses Rodrigues' formula to construct the rotation Matrix.
   *
   * \relates Rotation3D
   **/
  template<class T>
  inline Matrix<3,3,T> rotationMatrix(const ColVector<3,T> &Axis, T angle)
  {
    T cosx = (T) cos(angle);
    T sinx = (T) sin(angle);
    //  cout << "cos = " << cosx << ", sin = " << sinx << endl;
    ColVector<3,T> axis = Axis.normalized();
    //  cout << "normalized axis = " << axis << endl;
    Matrix<3,3,T> R;
    R = diagonalMatrix<3,T>(cosx);
    //  cout << "diag matrix = " << R << endl;
    R = R + sinx*skewSymmetric(Axis);
    //  cout << "plus skew = " << R << endl;
    R = R + (T(1.0)-cosx)*quadSymmetric(Axis);
    //  cout << "plus quad = " << R << endl;
    return R;
  }

  /** \brief Create a rotation Matrix from look and up vectors
   *
   * The rotation matrix represents the rotation from a coordinate
   * frame where the x axis is aligned with the look direction, and
   * z is the closest vector to up which is  orthogonal to x.
   * 
   * \note look and up can not be parallel.
   * \relates Rotation3D
   */
  template<class T>
  inline Matrix<3,3,T> rotationMatrix(const ColVector<3,T> &look, const ColVector<3,T> &up)
  {
    Matrix<3,3,T> R;
        
    ColVector<3,T> x = look.normalized();
    ColVector<3,T> y = cross<T>(up,x).normalized();
    ColVector<3,T> z = cross<T>(x,y).normalized();
    R = x, y, z;
    return R;
  }

  /** \brief Create a 3x3 rotation Matrix from an axis,angle representation
   *
   * Axis,angle representation of a rotation contains a RowVector representing
   * the rotation axis, and a scalar representing the magnitude of a rotation.
   * This uses Rodrigues' formula to construct the rotation Matrix.
   *
   * \relates Rotation3D
   **/
  template<class T>
  inline Matrix<3,3,T> rotationMatrix(const RowVector<3,T> &Axis, T angle)
  {
    T cosx = (T) cos(angle);
    T sinx = (T) sin(angle);
    RowVector<3,T> axis = Axis.normalized();
    Matrix<3,3,T> R;
    R = diagonalMatrix<3,T>(cosx);
    R = R + sinx*skewSymmetric(Axis);
    R = R + (T(1.0)-cosx)*quadSymmetric(Axis);
    return R;
  }

  /** \brief Create a 3x3 rotation Matrix from a quaternion representation 
   *
   * \relates Rotation3D
   **/
  template<class T>
  inline Matrix<3,3,T> rotationMatrix(const ColVector<4,T> &q)
  {
    Matrix<3,3,T> m;
    m[0][0] = q[0]*q[0] + q[1]*q[1] - q[2]*q[2] - q[3]*q[3];
    m[0][1] = 2.0*(q[1]*q[2] - q[0]*q[3]);
    m[0][2] = 2.0*(q[1]*q[3] + q[0]*q[2]);
    
    m[1][0] = 2.0*(q[2]*q[1] + q[0]*q[3]);
    m[1][1] = q[0]*q[0] - q[1]*q[1] + q[2]*q[2] - q[3]*q[3];
    m[1][2] = 2.0*(q[2]*q[3] - q[0]*q[1]);
    
    m[2][0] = 2.0*(q[3]*q[1] - q[0]*q[2]);
    m[2][1] = 2.0*(q[3]*q[2] + q[0]*q[1]);
    m[2][2] = (q[0]*q[0] - q[1]*q[1] - q[2]*q[2] + q[3]*q[3]);

    return m;
  }

  
  /** \brief Convert a 3x3 rotation Matrix to a quaternion representation 
   *
   * \note: Uses algorithm from Horn's 1987 Optical Society paper
   *
   * \relates Rotation3D
   **/
  template<class T>
  ColVector<4,T> quaternionVector( const Matrix<3,3,T> &m) 
  {
    ColVector<4,T> e,q;
    e[0] = 1 + m[0][0] + m[1][1] + m[2][2];
    e[1] = 1 + m[0][0] - m[1][1] - m[2][2];
    e[2] = 1 - m[0][0] + m[1][1] - m[2][2];
    e[3] = 1 - m[0][0] - m[1][1] + m[2][2];
    
    T max = e[0];
    int index = 0;
    for(int i = 1; i < 4; i++) 
      {
        if (e[i] > max) 
          {
            max = e[i];
            index = i;
          }
      }
    
    T div;
    q[index] = (T) sqrt(e[index])/2.0;
    div = T(4)*q[index];
    
    switch (index) {
    case 0:
      q[1] = (m[2][1] - m[1][2])/div;
      q[2] = (m[0][2] - m[2][0])/div;
      q[3] = (m[1][0] - m[0][1])/div;
      break;
    case 1:
      q[0] = (m[2][1] - m[1][2])/div;
      q[2] = (m[1][0] + m[0][1])/div;
      q[3] = (m[0][2] + m[2][0])/div;
      break;
    case 2:
      q[0] = (m[0][2] - m[2][0])/div;
      q[1] = (m[1][0] + m[0][1])/div;
      q[3] = (m[2][1] + m[1][2])/div;
      break;
    case 3:
      q[0] = (m[1][0] - m[0][1])/div;
      q[1] = (m[0][2] + m[2][0])/div;
      q[2] = (m[2][1] + m[1][2])/div;
      break;
    }
    return q;
  }

  /// @}
  
  /**
   * \class Rotation3D
   *
   * \brief Rotations in three dimensions. 
   * Rotations can be represented as quaternions, 3x3 matrices, roll/pitch/yaw angles,
   * scaled axis-angle (a unit rotation axis scaled by the angle of rotation), unit
   * axis,angle (a unit rotation axis plus a rotation angle).  Any of these formats
   * can be use to set and retrieve the rotation, while generic operations can be
   * used regardless of the preferred representation.
   */
  class Rotation3D 
  {
  private:
    
    // Rotations are stored internally as quaternions
    typedef ColVector<4,double> Quaternion;
    Quaternion q;
    
    /** \brief Conjugate of a quaternion (w,-v).
     *  The conjugate is the multiplicative inverse
     **/
    Quaternion quatConjugate() const {
      Quaternion qi; qi = q[0], -q[1], -q[2], -q[3];
      return qi;
    }

  public:
    
    /** \name Rotation3D Constructors  */
    /// @{
    /** \brief Initialize rotation as identity  */
    Rotation3D() { setIdentity(); }

    /** \brief Initialize from a quaternion (specified as a 4-vector)
     *
     * If the quaternion is non-unit, it will be normalized internally
     **/
    Rotation3D( const Vector4D &vec) { setQuaternion(vec); }

    /** \brief Initialize from a rotation matrix */
    Rotation3D( const Matrix33 &R) { setRotationMatrix(R); }

    /** \brief Initialize from a scaled axis angle */
    Rotation3D( const Vector3D &axisangle) { setAxisAngle(axisangle); }
    /** \brief Initialize from a unit axis and angle */
    Rotation3D( const Vector3D &axis, double angle) { setAxisAngle(axis,angle); }
    /** \brief Initialize from roll pitch and yaw angles in radians */
    Rotation3D( double rollRad, double pitchRad, double yawRad) { setRollPitchYawRad(rollRad,pitchRad,yawRad); }

    /** \brief Initialize from a Rotation2D. 
     *
     * Equivalent to setting the yaw to be the Rotation2D angle, and the roll and pitch to be zero. 
     **/
    Rotation3D( const Rotation2D &r2 ){ setRotation2D(r2); }

    /// @}


    /** \name Rotation3D Operations */
    /// @{
  

    /** \brief Compose two rotations (rotate by this followed by B).
     * \return this*B
     **/
    Rotation3D compose(const Rotation3D &B) const {
      const Quaternion &qa = this->q;
      const Quaternion &qb = B.q;
      Quaternion q;
      /* "scalar" part = w1*w2 - v1 dot v2 */
      q[0] = qa[0]*qb[0] - (qa[1]*qb[1] + qa[2]*qb[2] + qa[3]*qb[3]);
    
      /* vector = w1*v2 + w2*v1 + v1 cross v2 */
      q[1] = qa[0]*qb[1] + qb[0]*qa[1] + qa[2]*qb[3] - qa[3]*qb[2];
      q[2] = qa[0]*qb[2] + qb[0]*qa[2] + qa[3]*qb[1] - qa[1]*qb[3];
      q[3] = qa[0]*qb[3] + qb[0]*qa[3] + qa[1]*qb[2] - qa[2]*qb[1];
    
      return Rotation3D(q);
    }  

    /** \brief Compose two rotations (postmultiply by B).  
     * Rotation multiplication is not commutative.
     * \return this*B
     */
    Rotation3D operator*(const Rotation3D &B) const { return compose(B); }
    // MIKE: should this be a '+'? Both?

    /** \brief Rotates a vector by the Rotation */
    Vector3D rotate(const Vector3D &t) const
    {
      Matrix33 R = getRotationMatrix();
      return R*t;
    }
    /** \brief Rotates a vector by the Rotation */
    Vector3D operator*(const Vector3D &b) const { return rotate(b); }


    /** \brief Compute the inverse rotation */
    Rotation3D inverse() const {
      return Rotation3D(quatConjugate());
    }
    /** \brief Compute the inverse rotation (short name for formulas) */
    Rotation3D i() const {
      return Rotation3D(quatConjugate());
    }

    /** \brief Find the rotation required to take this orientation to 
     *  another orientation.  
     * 
     * For example if the Rotation3D A represents a body orientation with 
     * respect to a ground orientation, and the Rotation3D B represents a 
     * sensor orientation with respect to the ground orientation, then A.delta(B)
     * represents the sensor orientation with respect to the body orientation.
     **/
    Rotation3D delta(const Rotation3D &B) const {
      const Rotation3D &A = *this;
      return A.i()*B;
    }
    /// @}

    /** \name Rotation3D Access and Conversion 
     * Rotation access and conversion to various representations. */
    /// @{


    /** \brief Get the rotation as a unit quaternion */
    Vector4D getQuaternion() const {
      return q;
    }

    /** \brief Get the rotation as a 3x3 rotation matrix */
    Matrix33 getRotationMatrix() const {
      return rotationMatrix(this->q);
    }
  
    /** \brief Get the rotation as roll pitch yaw angles (in radians). */
    void getRollPitchYawRad(double &roll, double &pitch, double &yaw) const
    {
      roll  = getRollRad();
      pitch = getPitchRad();
      yaw   = getYawRad();
    }
    /** \brief Get the roll angle of the rotation (in radians). */
    double getRollRad() const {
      return ( atan2(2*(q[0]*q[1]+q[2]*q[3]), 1-2*(q[1]*q[1]+q[2]*q[2])) );
    }
    /** \brief Get the pitch angle of the rotation (in radians). */
    double getPitchRad() const {
      return ( asin(2*(q[0]*q[2] - q[3]*q[1])) );
    }
    /** \brief Get the yaw angle of the rotation (in radians). */
    double getYawRad() const {
      return ( atan2(2*(q[0]*q[3]+q[1]*q[2]), 1-2*(q[2]*q[2]+q[3]*q[3])) );
    }

    /** \brief Get the unit axis,angle representation of the rotation. */
    void getAxisAngle(Vector3D &axis, double &angle) const
    {
      Quaternion q = this->q.normalized();
      double sign = q[0]<0 ? -1.0 : 1.0;
      angle = 2 * acos(sign * q[0]);
      axis = q.sub<1,3>();
      if (axis.norm()) axis *= (sign / axis.norm());
    }
    /** \brief Get the scaled axis-angle representation of the rotation.*/
    Vector3D getAxisAngle() const
    {
      Vector3D axis;
      double angle;
      this->getAxisAngle(axis,angle);
      return axis*angle;
    }

    /** \brief linear interpolation of a rotation. 
     *
     * Computes the interpolation between this rotation and another with
     * the linear factor alpha using spherical quaternion interpolation.
     * When alpha is zero it returns this rotation, when alpha is 1.0
     * it returns the other rotation.
     *
     * \param B The other rotation 
     * \param alpha The linear interpolant factor
     * \param checkWrap (optional) flag to skip quaternion wrapping check
     * \returns The interpolated rotation  */
    Rotation3D interp(const Rotation3D &B, double alpha, const bool checkWrap=true) const 
    {
      const Quaternion &qa = this->q;
      const Quaternion &qb = B.q;
      double beta = 1.0-alpha;
      Quaternion qc;

      bool flipped = false;
      if (checkWrap) {
        flipped = qa.dot(qb) < 0;
      }
      if (flipped) {
        for (int i=0;i<4;i++) { qc[i] = qa[i]*beta - qb[i]*alpha; }
      } else {
        for (int i=0;i<4;i++) { qc[i] = qa[i]*beta + qb[i]*alpha; }
      }
      return Rotation3D(qc);
    }

    /// @}


    /** \name Rotation3D Assignment and Conversion 
     * Set the rotation using a variety of representations. */
    /// @{

    /** \brief Set to be identity rotation */
    Rotation3D &setIdentity() {
      this->q = 1.0,0.0,0.0,0.0;
      return *this;
    }
  
    /** \brief Set from another rotation object */
    Rotation3D &setRotation(const Rotation3D &B) {
      *this = B;
      return *this;
    }

    /** \brief Set from quaternion elements. 
     *
     * If the quaternion is non-unit, it will be normalized internally
     **/
    Rotation3D &setQuaternion(double w, double x, double y, double z){
      q[0] = w;
      q[1] = x;
      q[2] = y;
      q[3] = z;
      q.normalize();
      return *this;
    }

    /** \brief Set from a quaternion as a vector
     * If the quaternion is non-unit, it will be normalized internally
     **/
    Rotation3D &setQuaternion( const Vector4D &vec ){
      this->q = vec.normalized();
      return *this;
    }
  
    /** \brief Set from a 3x3 rotation matrix */
    Rotation3D &setRotationMatrix( const Matrix33 &R )
    {
      this->q = quaternionVector( R );
      return *this;
    }

  
    /** \brief Set from roll pitch yaw angles (in radians).*/
    Rotation3D &setRollPitchYawRad(double roll, double pitch, double yaw)
    {
      const double cRh = cos(roll/2);
      const double sRh = sin(roll/2);
      const double cPh = cos(pitch/2);
      const double sPh = sin(pitch/2);
      const double cYh = cos(yaw/2);
      const double sYh = sin(yaw/2);
    
      this->q = 
	cRh*cPh*cYh + sRh*sPh*sYh,
	sRh*cPh*cYh - cRh*sPh*sYh,
	cRh*sPh*cYh + sRh*cPh*sYh,
	cRh*cPh*sYh - sRh*sPh*cYh;
      return *this;
    }

  

    /** \brief Set from scaled axis-angle representation (a rotation axis scaled by its 
	angle in radians.) */
    Rotation3D &setAxisAngle(const Vector3D &axisangle) 
    {
      double angle = axisangle.norm();
      if (angle == 0.0) { setIdentity(); return *this; }
      double scale = sin(angle/2)/angle;
      q[0] = cos(angle/2);
      q[1] = axisangle[0]*scale;
      q[2] = axisangle[1]*scale;
      q[3] = axisangle[2]*scale;
      return *this;
    }

    /** \brief Sets from unit axis,angle representation (a rotation axis plus angle in radians). */
    Rotation3D &setAxisAngle(const Vector3D &axis, double angle) 
    {
      if (angle == 0.0) { setIdentity(); return *this; }
      double scale = sin(angle/2)/axis.norm();
      q[0] = cos(angle/2);
      q[1] = axis[0]*scale;
      q[2] = axis[1]*scale;
      q[3] = axis[2]*scale;
      return *this;
    }

    /** \brief Sets from a Rotation2D
     *
     * Eqivalent to setRollPitchYawRad(0,0, r2.getThetaRad())
     **/
    Rotation3D &setRotation2D(const Rotation2D &r2){
      return setRollPitchYawRad(0.0, 0.0, r2.getThetaRad() );
    }

    /// @}

    /** \name Rotation3D Queries */
    /// @{
    /** \brief Equality test. 
     * \param B A rotation to compare to
     * \return true if rotations are equal, false otherwise
     *
     */
    bool operator== (const Rotation3D &B) const {
      const Quaternion &qa = this->q;
      const Quaternion &qb = B.q;
      const double maxError = 1e-8;
      double sign = qa[0]*qb[0]>0 ? 1.0 : -1.0;
      ColVector<4,double> dq = qa - (sign * qb);
      double normq = dq.normSq();
      return (normq < maxError);
    }

    /** \brief Inequality test. 
     * \param B A rotation to compare to
     * \return true if the rotations are not equal, false otherwise */
    bool operator!= (const Rotation3D &B) const {
      return !(*this==B);
    }
    /// @}

  

    /** \brief Represent the rotation as a string. The quaternion representation
     * is used here. 
     *
     **/
    std::string toString( void ) const{
      return q.toString();
    }

    /** \brief Output the rotation to a output stream. The quaternion 
     * representation is used here. 
     **/
    friend std::ostream &operator<<(std::ostream &os, const Rotation3D &r) {
      return os << r.getQuaternion();
    }

  }; /* End of class Rotation3D */



} // end namespace SMALL

#endif /* _SMALL__ROTATION3D_HH_ */
