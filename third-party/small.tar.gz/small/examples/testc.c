#include <stdio.h>
#include <stdlib.h>
#include "use_with_c.h"

int verbose = 1;

int main(int argc, char **argv)
{
	
	double	q1[4];			/* C-style quaternion */
	double	v1[3]= {1,0,0};	/* C-style vector */
	double	v2[3];
	
	double roll1	= 0.0;  /* [rad] */
	double pitch1 	= 0.0;  /* [rad] */
	double yaw1 	=90*3.14159265359/180.0;  /* [rad] */

	double roll2, pitch2, yaw2;
	
	SetQRPY(roll1, pitch1, yaw1, q1);
	if (verbose) printf("q1 = {%f %f %f %f}\n", q1[0],q1[1],q1[2],q1[3]);
	
	GetQRPY(q1, &roll2, &pitch2, &yaw2);
	if (verbose) printf("RPY before \t= %f %f %f\n", roll1, pitch1, yaw1);
	if (verbose) printf("RPY after  \t= %f %f %f\n", roll2, pitch2, yaw2);
	
	RotVecQ(q1, v1, v2);
	if (verbose) printf("vec before \t= %f %f %f\n", v1[0], v1[1], v1[2]);
	if (verbose) printf("vec after  \t= %f %f %f\n", v2[0], v2[1], v2[2]);
	
  	return 0;
}
