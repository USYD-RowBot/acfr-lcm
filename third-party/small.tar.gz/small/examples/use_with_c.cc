#include "Rotation3D.hh"
#include "Pose3D.hh"
#include "use_with_c.h"

using namespace SMALL;

void CQuat2SMALLVec(double *cvector, Vector4D &out);
void SMALLVec2CQuat(Vector4D &in, double *cvector);
void CVec2SMALLVec3D(double *cvector, Vector3D &out);
void SMALLVec3D2CVec(Vector3D &in, double *cvector);
		
void SetQRPY(double r, double p, double y, double *quat)
{
	
	Vector4D q;
	Rotation3D q0;
	
	q0.setRollPitchYawRad(r, p, y);	
    q = q0.getQuaternion();
	
	quat[0] = q[0]; 
	quat[1] = q[1]; 
	quat[2] = q[2]; 
	quat[3] = q[3]; 
	
}


void GetQRPY(double *quat, double *r, double *p, double *y)
{
	Vector4D q;
	
	CQuat2SMALLVec(quat, q);
	Rotation3D q0(q);
	q0.getRollPitchYawRad(*r,*p,*y);

}


void RotVecQ(double *quatC, double *vectorin, double *vectorout)
{
	Vector4D q;
	CQuat2SMALLVec(quatC, q);
	Rotation3D q0(q);
	Pose3D T(q0);
	
	Vector3D vec3Din, vec3Dout;
	CVec2SMALLVec3D(vectorin, vec3Din);
	vec3Dout = T.transformFrom(vec3Din);
	SMALLVec3D2CVec(vec3Dout, vectorout);
}




void CQuat2SMALLVec(double *cvector, Vector4D &out)
{
	// should use the Vector4D constructor */
	out[0] = cvector[0]; out[1] = cvector[1]; out[2] = cvector[2]; out[3] = cvector[3]; 
}

void SMALLVec2CQuat(Vector4D &in, double *cvector)
{
	// should use some Vector4D method */
	cvector[0] = in[0]; cvector[1] = in[1]; cvector[2] = in[2]; cvector[3] = in[3]; 
}

void CVec2SMALLVec3D(double *cvector, Vector3D &out)
{
	// should use some Vector4D method */
	out[0] = cvector[0]; out[1] = cvector[1]; out[2] = cvector[2]; 
}

void SMALLVec3D2CVec(Vector3D &in, double *cvector)
{
	// should use some Vector3D method */
	cvector[0] = in[0]; cvector[1] = in[1];  cvector[2] = in[2]; 
}
