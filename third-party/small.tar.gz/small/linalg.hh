/** \file linalg.hh
 * \brief Linear algebra library: matrices, vectors, and associated operations. 
 *
 * This includes definitions for four classes: Matrix, ColVector, RowVector, and MatIndexer (which is
 * just a utility class for Matrix).
 *
 * \author Mike Bosse and Robert Zlot
 * \date Aug 2007
 * \version $Revision $ 
 * 
 * Copyright (c) 2007-2011 CSIRO Autonomous Systems Laboratory
 *
 **/


/***********************************************************
 *
 *
 * This file is part of SMALL.
 *
 *  SMALL is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SMALL is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with SMALL.  If not, see <http://www.gnu.org/licenses/>.
 *
 ************************************************************/


/** \mainpage SMALL Package
 *
 * \section SMALL Spatial Math and LinAlg Library
 *
 * SMALL is a C++ library defining and implementing common geometric and mathematical functionality
 * required for robotics applications. <br>
 * SMALL consists of two major parts: a linear algebra library (matrices and vectors) and a spatial
 * math library (poses and transformations).
 *
 * \subsection linalg Linear Algebra
 * The LinAlg library provides matrices and vectors with common operations such as inverses, 
 * compositions, determinants, and norms.  The implementation uses C++ templates, thus
 * allowing matrices and vectors of arbitrary size.  However, the operations are optimized towards
 * small matrix sizes commonly encountered in robotics (up to about 10x10).  Matrix sizes are fixed
 * and must be known at compile time.
 *
 * LinAlg is defined in linalg.hh, and includes the \link SMALL::Matrix Matrix\endlink, 
 * \link SMALL::ColVector ColVector\endlink, and \link SMALL::RowVector RowVector \endlink classes.  
 * linalg.hh also contains type definitions for commonly used
 * \link SMALL::Matrix Matrix \endlink and \link SMALL::ColVector Vector \endlink sizes and additional
 * useful angle conversion functions.
 *
 * \subsection poses Spatial Math
 * The spatial math library implements poses in two and three dimensions
 * (\link SMALL::Pose2D Pose2D \endlink and \link SMALL::Pose3D Pose3D\endlink).  
 * Poses can also be interpreted as transformations between frames.  Operations include compositions, inverses, 
 * and transformations.
 * The interface additionally allows for rotations to be specified in the prefered representation of the 
 * developer through the \link SMALL::Rotation2D Rotation2D \endlink and 
 * \link SMALL::Rotation3D Rotation3D \endlink classes.  A covariance class is available for 2D poses 
 * (\link SMALL::Pose2DCov Pose2DCov\endlink).
 *
 *
 * <br><br><hr size="1"><br><br>
 *
 *
 * \section using How to use SMALL
 *
 * <br> SMALL consists of a set of C++ header (.hh and .h) files, which can be included directly.
 * There is absolutely nothing to compile or link with.
 *
 * \subsection including Including SMALL
 * \code
 * #include <small/someheader.hh>
 * \endcode
 *
 * \subsection getting How to get SMALL
 * If you would like a local copy of SMALL, it can be checked out from the launchpad project as follows:
 * \code
 * % bzr branch lp:small
 * \endcode
 * The included README file explains how to configure and install SMALL.
 *
 * <br> SMALL requires g++ 4.1 or greater (will not compile under gcc 3.3)
 *
 *
 * <br><br><hr size="1"><br><br>
 *
 *
 * \section ddxpose DDX Pose Interface
 *
 * A DDX interface for pose classes is defined in the file \link ddxpose.h\endlink.
 *
 *
 * <br><br><hr size="1"><br><br>
 *
 *
 * \section limitations Limitations
 *
 * - SMALL is limited to static fixed-sized matrices and vectors with sizes known at compile time.
 * - Determinants are not currently implemented for Matrix sizes larger than 3x3.
 * - SMALL is intended for small-sized matrices.  Dimensions greater than about 50 are not 
 * recommended due to potential stack overflow.
 *
 * <br><br>
 *
 * If you are interested in further developing SMALL or desire additional features, please talk to
 * Rob Zlot or Mike Bosse first.
 *
 **/

#ifndef _SMALL__LINALG_HH_
#define _SMALL__LINALG_HH_

#ifdef WIN32
#define _CRT_SECURE_NO_WARNINGS 
#define _USE_MATH_DEFINES
#define random rand
#define remainder fmod
#define ilogb(val) (int)frexp((val), NULL)
#define snprintf _snprintf
#endif

#include <iostream>
#include <math.h>
#include <float.h>
#include <stdlib.h>
#include <string.h>
#include <cstdio>
#include <cassert>

//#include "linalg.hh"

#ifdef UNIX
#define ios_base ios
#endif

// static matrix of M rows, N columns
// no facility for resizing
// try different memory allocation strategy, i.e. heap based
// iterative (loops not unrolled) version

/** \namespace SMALL 
 * \brief Spatial Math And LinAlg Library
 **/
namespace SMALL
{

  template<int Mval, int Nval, class T>
  class Matrix;

  template<int Mval, class T>
  class RowVector;

  template<int Mval, class T>
  class ColVector;

  template<int Mval, class T> Matrix<Mval,Mval,T> identityMatrix();
  template<int Mval, int Nval, class T> Matrix<Mval,Nval,T> onesMatrix();
  template<int Mval, int Nval, class T> Matrix<Mval,Nval,T> zerosMatrix();

  template<int Mval, class T> Matrix<Mval,Mval,T> diagonalMatrix(const T &el);
  template<int Mval, class T> Matrix<Mval,Mval,T> diagonalMatrix(const ColVector<Mval,T> &vec);
  template<int Mval, class T> Matrix<Mval,Mval,T> diagonalMatrix(const RowVector<Mval,T> &vec);

  template<int Mval, class T> T determinant(const Matrix<Mval,Mval,T> &M);
#if 0
  /** \brief Compute the determinant of a Matrix.
   *
   * \todo This needs to be implemented
   **/
  template<int Mval, class T> T determinant(const Matrix<Mval,Mval,T> &M)
  {
    return T(0);
  }
#endif

  template<int Mval, class T> Matrix<Mval,Mval,T> inverse(const Matrix<Mval,Mval,T> &A);

  template <class T> ColVector<3,T> cross(const Matrix<3,1,T> &v1, const Matrix<3,1,T> &v2);
  template <class T> RowVector<3,T> cross(const Matrix<1,3,T> &v1, const Matrix<1,3,T> &v2);

  /** \brief compute a Gaussian distributed random value */
  static double randomGaussian()
  {
    static bool is_set=false;
    static double value;
    if (is_set) {
      is_set = false;
      return value;
    }
    
    double fac, u1, u2, v1, v2, s;
    do {
      u1 =  double(random()) / RAND_MAX;
      u2 =  double(random()) / RAND_MAX;
      v1 = 2 * u1 - 1;
      v2 = 2 * u2 - 1;
      s = v1 * v1 + v2 * v2;
    } while (s > 1);
    
    fac = sqrt ((-2 * log (s)) / s);
    value = v2*fac;
    is_set = true;
    return v1*fac;
  }
    

  /* Utility class used by Matrix to enable comma-separated lists.  Implemented later in this file. */
  template<int Mval, int Nval, class T, int Pval>
  class MatIndexer;

  /* Operator types for MatIndexer operations */
  enum MatIndexerOpEnum {
    MATINDEXER_EQ,
    MATINDEXER_PE,
    MATINDEXER_ME
  };

  /** \class Matrix 
   * \brief Matrices and matrix operations.
   * Matrix sizes are constant and must be known at compile time.
   *
   * Several commonly used Matrix sizes are also defined as types:
   * \link SMALL::Matrix22 Matrix22\endlink, \link SMALL::Matrix23 Matrix23\endlink, 
   * \link SMALL::Matrix33 Matrix33\endlink, \link SMALL::Matrix34 Matrix34\endlink,
   * \link SMALL::Matrix44 Matrix44\endlink, and \link SMALL::Matrix66 Matrix66\endlink.
   *
   * \todo Initialization/conversion between STL vectors?
   **/
  template<int Mval, int Nval, class T>
  class Matrix
  {
    
  protected:
    
    T mat[Mval][Nval];
  public:

    /** \name Matrix Constructors **/
    /// @{

    /** \brief Create a Matrix with uninitialized elements */
    Matrix() { }
        
    /** \brief Create a Matrix and initialize it from an array specified in
     * row-major order.
     *
     * \param els An array of elements that must be at least the size of the Matrix
     * (if it is larger, then only the first Mval*Nval elements are used).
     **/
    Matrix(const T *els)
    {
      int elCount = 0;
      for(int m = 0; m < Mval; m++)
        for(int n =0; n < Nval; n++)
          mat[m][n] = els[elCount++];
    }

    /** \brief Create a Matrix and initialize from another Matrix */
    Matrix(const Matrix<Mval,Nval,T> &mat2)
    {
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          mat[m][n] = mat2.mat[m][n];
    }

    /** \brief Create a Matrix and initialize all elements to el */
    Matrix(const T &el)
    {
      for(int m = 0; m < Mval; m++)
        for(int n =0; n < Nval; n++)
          mat[m][n] = el;
    }


    //~Matrix() { /*mat[0][0] = -1975;*/ }

    /// @}

    /** \name Matrix Assignment */
    /// @{
    /** \brief Cast the type held by a Matrix to a new type specified by `NT' */
    template<class NT>
    Matrix<Mval,Nval,NT> cast()
    {
      Matrix<Mval,Nval,NT> result;
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          result[m][n] = static_cast<NT>(mat[m][n]);
      return result;
    }

    /** \brief Assignment operator: set a Matrix to a comma-separated list of elements. 
     *  
     *  <i>e.g.</i>, Matrix<3,3,double> A; A = 4.0,3.1,3.3,5.1,2.7,1.5,3.1,8.0,5.2;
     *
     * \note This cannot be used upon construction; 
     * i.e., Matrix<3,2,double> A = 1.3,2.2,3.2,4.7,5.9,6.0; will not compile
     **/
    MatIndexer<Mval,Nval,T,1> operator=(const T &el)
    {
      mat[0][0] = el;
      MatIndexer<Mval,Nval,T,1> i(*this, MATINDEXER_EQ);
      return i;
    }

    /** \brief operator+=: add a comma-separated list of elements to a Matrix 
     *  
     *  <i>e.g.</i>, Matrix<3,3,double> A(B); 
     *               ...
     *               A += 4.0,3.1,3.3,5.1,2.7,1.5,3.1,8.0,5.2;
     *
     **/
    MatIndexer<Mval,Nval,T,1> operator+=(const T &el)
    {
      mat[0][0] += el;
      MatIndexer<Mval,Nval,T,1> i(*this, MATINDEXER_PE);
      return i;
    }

    /** \brief operator-=: subtract a comma-separated list of elements from a Matrix 
     *  
     *  <i>e.g.</i>, Matrix<3,3,double> A; 
     *               ...
     *               A -= 4.0,3.1,3.3,5.1,2.7,1.5,3.1,8.0,5.2;
     *
     **/
    MatIndexer<Mval,Nval,T,1> operator-=(const T &el)
    {
      mat[0][0] -= el;
      MatIndexer<Mval,Nval,T,1> i(*this, MATINDEXER_ME);
      return i;
    }

    /** \brief Assignment operator: set a Matrix to a comma-separated list of column vectors. 
     * 
     * <i>e.g.</i>, ColVector<3,double> v1, v2, v3;
     *              ...
     *              Matrix<3,3,double> A; A = v1,v2,v3;
     **/
    MatIndexer<Mval,Nval,T,1> operator=(const ColVector<Mval,T> &col)
    {
      for(int m = 0; m < Mval; m++)
        mat[m][0] = col[m];
      MatIndexer<Mval,Nval,T,1> i(*this, MATINDEXER_EQ);
      return i;
    }
    
    /** \brief operator+=: add a comma-separated list of ColVectors to a Matrix 
     *  
     *  <i>e.g.</i>, ColVector<3,double> v1, v2, v3;
     *               Matrix<3,3,double> A; 
     *               ...
     *               A += v1,v2,v3;
     *
     **/
    MatIndexer<Mval,Nval,T,1> operator+=(const ColVector<Mval,T> &col)
    {
      for(int m = 0; m < Mval; m++)
        mat[m][0] += col[m];
      MatIndexer<Mval,Nval,T,1> i(*this, MATINDEXER_PE);
      return i;
    }

    /** \brief operator-=: subtract a comma-separated list of ColVectors from a Matrix 
     *  
     *  <i>e.g.</i>, ColVector<3,double> v1, v2, v3;
     *               Matrix<3,3,double> A; 
     *               ...
     *               A -= v1,v2,v3;
     *
     **/
    MatIndexer<Mval,Nval,T,1> operator-=(const ColVector<Mval,T> &col)
    {
      for(int m = 0; m < Mval; m++)
        mat[m][0] -= col[m];
      MatIndexer<Mval,Nval,T,1> i(*this, MATINDEXER_ME);
      return i;
    }

    /** \brief Assignment operator: set a Matrix to a comma-separated list of row vectors. 
     * 
     * <i>e.g.</i>, RowVector<3,double> v1, v2, v3;
     *       ...
     *       Matrix<3,3,double> A;
     *       A = v1,v2,v3;
     **/
    MatIndexer<Mval,Nval,T,1> operator=(const RowVector<Nval,T> &row)
    {
      for(int n = 0; n < Nval; n++)
        mat[0][n] = row[n];
      MatIndexer<Mval,Nval,T,1> i(*this, MATINDEXER_EQ);
      return i;
    }

    /** \brief operator+=: add a comma-separated list of RowVectors to a Matrix 
     *  
     *  <i>e.g.</i>, RowVector<3,double> v1, v2, v3;
     *               Matrix<3,3,double> A; 
     *               ...
     *               A += v1,v2,v3;
     *
     **/
    MatIndexer<Mval,Nval,T,1> operator+=(const RowVector<Nval,T> &row)
    {
      for(int n = 0; n < Nval; n++)
        mat[0][n] += row[n];
      MatIndexer<Mval,Nval,T,1> i(*this, MATINDEXER_PE);
      return i;
    }

    /** \brief operator-=: subtract a comma-separated list of RowVectors from a Matrix 
     *  
     *  <i>e.g.</i>, RowVector<3,double> v1, v2, v3;
     *               Matrix<3,3,double> A; 
     *               ...
     *               A -= v1,v2,v3;
     *
     **/
    MatIndexer<Mval,Nval,T,1> operator-=(const RowVector<Nval,T> &row)
    {
      for(int n = 0; n < Nval; n++)
        mat[0][n] -= row[n];
      MatIndexer<Mval,Nval,T,1> i(*this, MATINDEXER_ME);
      return i;
    }

    /** \brief Assignment operator: set a Matrix from an array of values.
     *
     * \param els An array of elements that must be at least the size of the Matrix
     * (if it is larger, then only the first Mval*Nval elements are used). 
     **/
    Matrix<Mval,Nval,T> &operator=(const T *els)
    {
      int elCount = 0;
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          mat[m][n] = els[elCount++];
      return *this;
    }

    /** \brief Assignment operator: set a Matrix from another Matrix. 
     **/
    Matrix<Mval,Nval,T> &operator=(const Matrix<Mval,Nval,T> &mat2)
    {
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          mat[m][n] = mat2.mat[m][n];
      return *this;
    }

    /** \brief Set all elements in a Matrix to el.
     *
     * \note This cannot be another operator=(const T&) because of overloading with the MatIndexer version 
     **/
    Matrix<Mval,Nval,T> &set(const T& el)
    {  
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          mat[m][n] = el;
      return *this;
    }

    /** \brief Assign Matrix values from an object of class S for which individual elements can
     *  be accessed by a 2D () with 1-based indexing.
     *
     * \param s An object of type S, which must have operator(int,int) defined with 1-based 
     * indexing: <i>e.g</i>, s(3,2) is a valid call. s must have the correct dimensions 
     * (<i>i.e.</i>, MvalxNval).
     **/
    template <class S>
    Matrix<Mval,Nval,T> &copyFromRecMatrix(const S &s)
    {
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          mat[m][n] = s(m+1,n+1);
      return *this;
    }
  
    /** \brief Assign Matrix values from an object of a (matrix-like) class S for which individual 
     *  elements can be accessed by [][] with 0-based indexing
     *
     * \param s An object of type S, which must allow access using [][] with 0-based indexing;  
     * <i>e.g.</i>, s[3][2]. s must have the correct dimensions (<i>i.e.</i>, MvalxNval).
     **/
    template<class S>
    inline Matrix<Mval,Nval,T> &copyFromMatrix(const S &s)
    {
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          mat[m][n] = s[m][n];
      return *this;
    }

    /** \brief Assign Matrix values from an object of a (vector-like) class S for which individual 
     *  elements can be accessed by [] with 0-based indexing.
     *
     * \param s An object of type S, which must allow access using [] with 0-based indexing;
     * <i>e.g.</i>, s[6].  s must have the correct dimensions (<i>i.e.</i> Mval*Nval).
     **/
    template<class S>
    inline Matrix<Mval,Nval,T> &copyFromVector(const S &s)
    {
      int k=0;
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++, k++)
          mat[m][n] = s[k];
      return *this;
    }

    /** \brief Set all elements in the Matrix to zero. */
    Matrix<Mval,Nval,T> zero() 
    {
#if 0
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          mat[m][n] = T(0);
      return *this;
#else
      int n=Mval*Nval;
      T* v = &mat[0][0];
      while (n--) *v++ = T(0);
      return *this;
#endif
    }

    /** \brief Set the Matrix to be a diagonal
     * 
     * \param el An object of class Diag which can be of type T, ColVector<Mval,T> 
     * or RowVector<Mval,T> 
     * \note The Matrix must be square 
     **/
    template <class Diag>
    Matrix<Mval,Nval,T> &setDiag(const Diag &el) 
    {
      return *this = diagonalMatrix<Mval>(el);
    }

    /** \brief Set the Matrix to be the identity
     * 
     * \note The Matrix must be square */
    Matrix<Mval,Nval,T> &setIdentity() 
    {
      return *this = identityMatrix<Mval,T>();
    }

    /** \brief Set all Matrix elements to be 1's
     **/
    Matrix<Mval,Nval,T> &setOnes() 
    {
      int n=Mval*Nval;
      T* v = &mat[0][0];
      while (n--) *v++ = T(1);
      return *this;
    }

    /** \brief Set all Matrix elements to be uniform random values between 0 and 1
     **/
    Matrix<Mval,Nval,T> &fillRandom() 
    {
      int n=Mval*Nval;
      T* v = &mat[0][0];
      while (n--) *v++ = T(random())/RAND_MAX;
      return *this;
    }


    /** \brief Set all Matrix elements to be Gaussian distributed random values with mean 0 and sigma 1
     **/
    Matrix<Mval,Nval,T> &fillRandomGaussian() 
    {
      int n=Mval*Nval;
      T* v = &mat[0][0];
      while (n--) *v++ = T(randomGaussian());
      return *this;
    }


    /** \brief Set all Matrix elements to their absolute values */
    Matrix<Mval,Nval,T> &setAbs(){
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          mat[m][n] = ( mat[m][n]<0 ? -mat[m][n] : mat[m][n] );
      return *this;
    }
    
    /// @}

    /** \brief Get the number of rows */
    unsigned int nrows() const { return Mval; }

    /** \brief Get the number of columns */
    unsigned int ncols() const { return Nval; }
    
    // cast to a scalar
    //operator T() const { return mat[0]; }    


    /** \name Matrix Access */
    /// @{

    /** \brief Access a row of the Matrix using 0-based indexing 
     *
     * \param row 0-based row index, must be in range [0,Mval-1]
     **/
    inline T *operator[](int row)
    {
      return (mat[row]);
    }

    /** \brief Access a row of the Matrix using 0-based indexing 
     *
     * \param row 0-based row index, must be in range [0,Mval-1]
     **/
    inline const T *operator[](int row) const
    {
      return (mat[row]);
    }
    
    /** \brief Access an element of the Matrix specified by (row,col) using 1-based indexing 
     *
     * \param row 1-based row index; must be in range [1,Mval]
     * \param col 1-based column index; must be in range [1,Nval]
     **/
    inline T &operator()(unsigned int row, unsigned int col)
    {
      return mat[row-1][col-1]; 
    }
    /** \brief Access an element of the Matrix specified by (row,col) using 1-based indexing 
     * 
     * \param row 1-based row index; must be in range [1,Mval]
     * \param col 1-based column index; must be in range [1,Nval]
     **/
    inline const T &operator()(unsigned int row, unsigned int col) const
    {
      return mat[row-1][col-1]; 
    }

    /** \brief Access a row of the Matrix (0-based indexing)
     *
     * \param m 0-based row index, must be in range [0,Mval-1]
     **/
    RowVector<Nval,T> row(int m) const
    {
      Matrix<1,Nval,T> result;

      for(int n = 0; n < Nval; n++)
        result[0][n] = mat[m][n];
      return result;
    }

    /** \brief Access a column of the Matrix (0-based indexing)
     *
     * \param n 0-based column index; must be in range [0,Nval-1]
     **/
    ColVector<Mval,T> column(int n) const
    {
      Matrix<Mval,1,T> result;

      for(int m = 0; m < Mval; m++)
        result[m][0] = mat[m][n];
      return result;
    }

    /** \brief Access a row of the matrix (0-based indexing)
     *
     * Usage: r = mat.row<3>();
     * \note Pval must be in range [0,Mval-1]
     **/
    template<int Pval>
    Matrix<1,Nval,T> row() const
    {
      Matrix<1,Nval,T> result;

      for(int n = 0; n < Nval; n++)
        result[0][n] = mat[Pval][n];
      return result;
    }

    /** \brief Access a column of the matrix (0-based indexing)
     *
     * Usage: c = mat.column<3>();
     * \note Pval must be in range [0,Nval-1]
     **/
    template<int Pval>
    Matrix<Mval,1,T> column() const
    {
      Matrix<Mval,1,T> result;

      for(int m = 0; m < Mval; m++)
        result[m][0] = mat[m][Pval];
      return result;
    }

    /** \brief Access a submatrix (0-based indexing)
     *
     * Usage: s = mat.sub<0,2,2,4>();
     **/
    template<int r0,int r1, int c0, int c1>
    Matrix<r1-r0+1,c1-c0+1,T>  
    sub( ) const
    {
      Matrix<r1-r0+1,c1-c0+1,T> result;
      int i,j;
      for (i=r0;i<=r1;i++) {
        for (j=c0;j<=c1;j++) {
          result[i-r0][j-c0] = mat[i][j];
        }
      }
      return result;
    }
    /// @}

    /** \name Matrix Operations
     *
     * Other Matrix operations are defined in linalg.hh
     **/
    /// @{
    /** \brief Bitwise right shift on all Matrix elements.
     *
     * Should only be used for integer or fixed point matrices.
     **/
    Matrix<Mval,Nval,T> operator>>(unsigned int shift) const
    {
      Matrix<Mval,Nval,T> result;

      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          result[m][n] = (mat[m][n]>>shift);
      return result;
    }

    /** \brief Bitwise left shift on all Matrix elements.
     *
     * Should only  be used for integer or fixed point matrices.
     **/
    Matrix<Mval,Nval,T> operator<<(unsigned int shift) const
    {
      Matrix<Mval,Nval,T> result;

      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          result[m][n] = (mat[m][n]<<shift);
      return result;
    }

    /** \brief Multiply a Matrix element-wise by a scalar, returning the result in a new Matrix object. 
     *
     * \note Multiplication with the scalar on the LHS is also possible, but defined outside of the class
     * \link operator*(const T&,const Matrix<Mval,Nval,T>&) \endlink
     **/
    Matrix<Mval,Nval,T> operator*(const T &scalar) const
    {
      Matrix<Mval,Nval,T> result;

      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          result[m][n] = scalar*mat[m][n];
      return result;
    }

    /** \brief Self-multiply Matrix element-wise by a scalar */
    Matrix<Mval,Nval,T> &operator*=(const T &scalar) 
    {
      *this = *this  * scalar;
      return *this;
    }

    /** \brief Matrix multiplication: multiply an MxN Matrix by an NxP Matrix, returning the result in
     *  a new Matrix object
     **/
    template<int Pval>
    Matrix<Mval,Pval,T> operator*(const Matrix<Nval,Pval,T> &mat2) const
    {
      Matrix<Mval,Pval,T> result;
                
      T sum;
      for(int m = 0; m < Mval; m++)
        {
          for(int p = 0; p < Pval; p++)
            {
              sum = 0.0;
              for(int n = 0; n < Nval; n++)
                {
                  sum += mat[m][n]*mat2[n][p];
                }
              result[m][p] = sum;
            }
        }
      return result;
    }
    
    inline void swaprows(const unsigned int i, const unsigned int j);
    /** \brief Perform Gauss-Jordan elimination on a square Matrix.
     *
     * Solves a set of linear systems A*X = this, or X = inv(A)*this 
     *
     * \return \f$ X = A^{-1} B \f$, where B is this
     * \note This code adapted from Leonard's GaussElimination() routine.
     * \todo This version is inefficient in storage requirements; probably want an inplace version.
     **/
    Matrix<Mval,Nval,T> gaussJordanElimination(const Matrix<Mval,Mval,T> &A) const;

    /** \brief Compute the determinant of a square Matrix 
     *
     * \note This is only defined for square matrices up to size 3x3
     * \todo Write a general NxN determinant function
     **/
    T determinant() const { return det(*this); }

    /** \brief Compute the inverse of a Matrix.
     *
     * Uses Gauss-Jordan elimination.
     **/
    Matrix<Mval,Mval,T> inverse() const
    {
      return inv(*this);
    }

    /** \brief Compute eigenvectors and eigenvalues for a Matrix (LGPL)
     *
     * The eigenvectors are returned in an MxM Matrix,
     * and the eigenvalues are returned in a Mx1 ColVector
     * Matrix must be real and symmetric.
     *
     *  \param eigVecs MxM matrix for storing resulting eigenvectors
     *  \param eigVals Mx1 vector for storing resulting eigenvalues
     *
     * \note Adapted from:
     *       Joachim Kopp,
     *       Efficient numerical diagonalization of hermitian 3x3 matrices,
     *       Int. J. Mod. Phys. C 19 (2008) 523-548,
     *       arXiv.org: physics/0610206
     **/
    void eigen(Matrix<Mval,Mval,T> &eigVecs, ColVector<Mval,T> &eigVals) const;


    /** \brief Equality test
     *
     * \note This checks that all elements of the difference of the two matrices
     * is less than \f$ 10^-8 \f$
     **/
    bool operator==(const Matrix<Mval,Nval,T> &A) const{
      const int epsExp = -27; // approx 10^-8

      for( int m=0; m<Mval; m++ ){
	for( int n=0; n<Nval; n++ ){
	  if( ilogb(this->mat[m][n]-A.mat[m][n]) >= epsExp ){
	    return false;
	  }
	}
      }
      return true;
    }

    /** \brief Inequality test 
     *
     * \note This checks if any of the elements of the difference is greater
     * than \f$ 10^-8 \f$
     **/
    bool operator!=(const Matrix<Mval,Nval,T> &A) const{
      return !(*this==A);
    }

    /** \brief Symmetry test (within tolerance)
     *  \return true if Matrix is symmetric, false otherwise
     *
     * \note eqv. to *this==*this.transpose()
     **/
    bool isSymmetric(void) const{

      const int epsExp = -27; // equality tolerance binary exponent (approx 10^-8)

      // only square matrices can be symmetric
      if(Mval != Nval) return false;
      for(unsigned int i=0; i < Mval; ++i) {
        for(unsigned int j=0; j < Mval; ++j) {
          if(ilogb(mat[i][j] - mat[j][i]) >= epsExp) {
            return false;
          }
        }
      }
      return true;  // matrix is symmetric
    }



    /** \brief Matrix division: solution to \f$ A*X = B \rightarrow X = A \backslash B \f$ (i.e., A.inverse()*B). 
     * 
     * A is M x M, B is M x N, X is M x N
     * \return \f$ X = A^{-1} B \f$, where B is this
     *
     **/
    Matrix<Mval,Nval,T> operator/(const Matrix<Mval,Mval,T> &A) const
    {
      return gaussJordanElimination(A);
    }
        
    /** \brief Element-wise division by a scalar
     *
     * \param scalar Should be non-zero
     **/
    Matrix<Mval,Nval,T> operator/(const T &scalar) const
    {
      Matrix<Mval,Nval,T> result;

      const T iscalar = T(1.0)/scalar;
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          result[m][n] = mat[m][n]*iscalar;
      return result;
    }

    /** \brief Self-divide Matrix element-wise by a scalar
     *
     * \param scalar Should be non-zero
     **/
    Matrix<Mval,Nval,T> operator/=(const T &scalar){
      *this = *this / scalar;
      return *this;
    }

    /** \brief Add another Matrix of the same dimensions, returning the result in a new Matrix object */
    Matrix<Mval,Nval,T> operator+(const Matrix<Mval,Nval,T> &mat2) const
    {
      Matrix<Mval,Nval,T> result;

      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          result.mat[m][n] = mat[m][n] + mat2.mat[m][n];
      return result;
    }
        
    /** \brief Add another Matrix to this Matrix */
    Matrix<Mval,Nval,T> operator+=(const Matrix<Mval,Nval,T> &mat2)
    {
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          mat[m][n] += mat2.mat[m][n];
      return *this;
    }

    
    /** \brief Subtract another Matrix of the same dimensions, returning the result in a new Matrix object */
    Matrix<Mval,Nval,T> operator-(const Matrix<Mval,Nval,T> &mat2) const
    {
      Matrix<Mval,Nval,T> result;

      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          result.mat[m][n] = mat[m][n] - mat2.mat[m][n];
      return result;
    }

    /** \brief Unary minus: multiply the Matrix by -1 */
    Matrix<Mval,Nval,T> operator-() const
    {
      Matrix<Mval,Nval,T> result;

      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          result.mat[m][n] = -mat[m][n];
      return result;
    }
    
    /** \brief Subtract another Matrix from this Matrix */
    Matrix<Mval,Nval,T> operator-=(const Matrix<Mval,Nval,T> &mat2)
    {
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          mat[m][n] -= mat2.mat[m][n];
      return *this;
    }
        
    /** \brief Compute the transpose */
    Matrix<Nval,Mval,T> transposed() const
    {
      Matrix<Nval,Mval,T> result;

      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          result[n][m] = mat[m][n];
      return result;
    }
    
    /** \brief Get the absolute value of a matrix */
    Matrix<Mval,Nval,T> abs() const {
      Matrix<Mval,Nval,T> result;
      
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          result[m][n] = ( mat[m][n]<0 ? -mat[m][n] : mat[m][n] );
      return result;
    }
    /// @}


    /** \name Matrix Joining and Splitting
     *
     **/
    /// @{
    /** \brief Concatenate two matrices horizontally.
     *
     * Matrices must have the same number of rows.
     **/
    template<int Nval2>
    Matrix<Mval, Nval+Nval2, T> 
    concat(const Matrix<Mval,Nval2,T> &M2) const
    {
      const Matrix<Mval,Nval,T> &M1 = *this; 
      Matrix<Mval, Nval+Nval2, T> M3;
      int i,j;
      for (i=0;i<Mval;i++)
        {
          for (j=0;j<Nval;j++)
            {
              M3[i][j] = M1[i][j];
            }
        }
      for (i=0;i<Mval;i++)
        {
          for (j=0;j<Nval2;j++)
            {
              M3[i][j+Nval] = M2[i][j];
            }
        }
      return M3;
    }

    /** \brief Stack two matrices vertically.  
     *
     * Matrices must have the same number of columns.
     **/
    template<int Mval2>
    Matrix<Mval+Mval2, Nval, T> 
    stack(const Matrix<Mval2,Nval,T> &M2) const
    {
      const Matrix<Mval,Nval,T> &M1 = *this;
      Matrix<Mval+Mval2, Nval, T> M3;
      int i,j;
      for (i=0;i<Mval;i++)
        {
          for (j=0;j<Nval;j++)
            {
              M3[i][j] = M1[i][j];
            }
        }
      for (i=0;i<Mval2;i++)
        {
          for (j=0;j<Nval;j++)
            {
              M3[i+Mval][j] = M2[i][j];
            }
        }
      return M3;
    }

    /** \brief Split a Matrix into two matrices (horizontally).  
     *
     * M, M1, and M2 must have the same number of rows, and the number of columns of M must 
     * be equal to the sum of the number of columns of M1 plus M2.
     **/
    template<int Nval1>
    void 
    split(Matrix<Mval,Nval1,T> &M1, 
          Matrix<Mval,Nval-Nval1,T> &M2) const
    {
      const int Nval2 = Nval-Nval1;
      const Matrix<Mval,Nval,T> &M = *this;
      int i,j;
      for (i=0;i<Mval;i++)
        {
          for (j=0;j<Nval1;j++)
            {
              M1[i][j] = M[i][j];
            }
        }
      for (i=0;i<Mval;i++)
        {
          for (j=0;j<Nval2;j++)
            {
              M2[i][j] = M[i][j+Nval1];
            }
        }
    }

    /** \brief Split a Matrix into two matrices (vertically).  
     *
     * M, M1, and M2 must have the same number of columns, and the number of rows of M must 
     * be equal to the sum of the number of rows of M1 plus M2.
     **/
    template<int Mval1>
    void
    split(Matrix<Mval1,Nval,T> &M1, 
          Matrix<Mval-Mval1,Nval,T> &M2) const
    {
      const Matrix<Mval, Nval, T> &M = *this;
      const int Mval2 = Mval-Mval1;
      int i,j;
      for (i=0;i<Mval1;i++)
        {
          for (j=0;j<Nval;j++)
            {
              M1[i][j] = M[i][j];
            }
        }
      for (i=0;i<Mval2;i++)
        {
          for (j=0;j<Nval;j++)
            {
              M2[i][j] = M[i+Mval1][j];
            }
        }
    }
    /// @}

    /** \brief Compute the trace of a Matrix M.
     *
     * The trace of a Matrix is the sum of the diagonal elements.
     **/
    T trace() const
    {
      const int D = (Mval>Nval?Nval:Mval);
      T sum = T(0);
      int i;
      for (i=0; i<D; i++)
        {
          sum += mat[i][i];
        }
      return sum;
    }


    /** \brief Returns the sum of the squares of all elements (\f$ L_2 \f$ norm squared) */
    T normSq() const 
    {
      T sum(0);
      for(int m = 0; m < Mval; m++)
        for(int n = 0; n < Nval; n++)
          sum += mat[m][n] * mat[m][n];
      return sum;
    }

    /** \brief Returns the sqrt of the sum of the squares of all elements (\f$ L_2 \f$ norm) */
    T norm() const { return sqrt(normSq()); }

    /**
     * \brief \f$ L_2 \f$ norm: return the square root of the sum of squares of element values
     *
     * \f$ L_2 = \sqrt{\sum_i \sum_j m_{ij}^2}\f$.
     */
    T normL2() const { return norm(); }

    /** \brief \f$ L_\infty \f$ norm: returns the max absolute element value 
     *
     * \f$ L_\infty = \max_{i,j} |m_{ij}| \f$ 
     **/
    T normLinf() const{
      T mx(0);
      for(int m = 0; m < Mval; m++){
        for(int n = 0; n < Nval; n++){
	  T x = (mat[m][n]<0)?(-mat[m][n]):(mat[m][n]);
	  mx = std::max(mx,x);
	}
      }
      return mx;
    }

    /** \brief \f$ L_p \f$ norm: returns the \f$ p^{th} \f$ root of the sum of the 
     * \f$ p^{th} \f$ power of the absolute value of each vector element
     *
     * \f$ L_p = ( \sum_i \sum_j m_{ij}^p )^ \frac{1}{p}\f$
     **/
    T normLP(double p) const{
      T LP(0);
      for(int m = 0; m < Mval; m++){
        for(int n = 0; n < Nval; n++){
	  T x = (mat[m][n]<0)?(-mat[m][n]):(mat[m][n]);
	  LP += pow(x,p);
	}
      }
      return pow(LP,1/p);
    }

    /** \brief \f$ L_1 \f$ norm: returns the sum of absolute values of elements
     *
     * \f$ L_1 = \sum_m \sum_n | A_{mn} | \f$
     **/
    T normL1() const{
      T L1(0);
      for(int m = 0; m < Mval; m++){
        for(int n = 0; n < Nval; n++){
	  L1 += (mat[m][n]<0)?(-mat[m][n]):(mat[m][n]);
	}
      }
      return L1;
    }

    /**
     * \brief Returns a normalized version of this Matrix
     *
     * n = this / norm( this )
     */
    Matrix<Mval,Nval,T> normalized() const {
      return (*this)*(T(1.0)/normL2());
    }

    /**
     * \brief Normalizes this Matrix
     */
    Matrix<Mval,Nval,T> normalize() {
      return *this = normalized();
    }

    /** \brief Copy the Matrix to a 1-D array specified in row-major order. 
     *
     * \param matArray Storage for the Matrix data.  Sufficient memory should already be 
     * allocated before calling.
     **/
    void copyToArray(T *matArray) const
    {
      memcpy(matArray, &mat[0][0], Mval*Nval*sizeof(T));
    }

    /** \brief Convert the Matrix to a string 
     *
     * Example:  [ 2, 3, 1; 4, 3, 3; ]
     **/
    std::string toString() const
    {
      const Matrix<Mval,Nval,T> &mat = *this;
      char buf[10*Mval*Nval+32];
      char *p = buf;
      *p++ = '[';
      for(int i = 0; i < Mval; i++)
        {
          for(int j = 0; j < Nval; j++)
            {
              p += snprintf(p, sizeof(buf)-(p-buf), " %g", mat[i][j]); 
              if(j != Nval-1) {
                *p++ = ',';
              } else {
                *p++ = ';';
                // *p++ = ' ';
              }
            }
        }
      *p++ = ' ';
      *p++ = ']';
      *p = 0;
      return std::string(buf);
    }

    /** \brief Output Matrix to an output stream. 
     *     
     * Example output:  [ 2,3,1; 4,3,3; ]
     **/
    friend std::ostream &operator<<(std::ostream &os, const Matrix<Mval,Nval,T> &m)
    {
      //              os << M << " x " << N << " matrix: " << endl;
      os << "[ ";
      for(int i = 0; i < Mval; i++)
        {
          for(int j = 0; j < Nval; j++)
            {
              os << m.mat[i][j];
              if(j != Nval-1)
                os << ",";
              else
                os << ";\n ";
            }
        }
      return os << "]";
    }
    
    /** \brief Input a Matrix from an input stream
     *     
     * Example input:  [ 2,3,1; 4,3,3; ]
     **/
    friend std::istream &operator>>(std::istream &is, Matrix<Mval,Nval,T> &mat)
    {
      char ch;
      T elem;

      // should have same format as above
      // read first [
      is >> std::ws;
      is.get(ch);
      if(ch != '[')
        {
          is.setstate(std::ios_base::failbit);
          //                      cerr << "improper matrix format, expecting '[', found '" << ch << "'" << endl;
          return is;
        }

      for(int m = 0; m < Mval; m++)
        {
          for(int n = 0; n < Nval; n++)
            {
              is >> elem;
              //                              cout << "read <" << elem << ">" << endl;
              mat[m][n] = elem;
              is >> std::ws;
              is.get(ch);
              if(n != Nval-1)
                {
                  if(ch != ',')
                    {
                      is.setstate(std::ios_base::failbit);
                      //                                              cerr << "improper matrix format, expecting ',', found '" 
                      //                                                      << ch << "'" << endl;
                      return is;
                    }
                }
              else
                {
                  if(ch != ';')
                    {
                      is.setstate(std::ios_base::failbit);
                      //                                              cerr << "improper matrix format, expecting ';', found '" 
                      //                                                      << ch << "'" << endl;
                      return is;
                    }
                }
            }
        }
      is >> std::ws;
      is.get(ch);
      if(ch != ']')
        {
          is.setstate(std::ios_base::failbit);
          //                      cerr << "improper matrix format, expecting ']', found '"
          //                              << ch << "'" << endl;
        }
      return is;
    }
  }; // End of class Matrix

  /** \brief Multiply a Matrix by a scalar, returning the result in a new Matrix object 
   *
   * Allows the scalar to come first in the multiplication; i.e., mat2 = 3*mat1;
   *
   * \relates Matrix
   **/
  template<int Mval, int Nval, class T>
  inline Matrix<Mval,Nval,T> operator*(const T &scalar, const Matrix<Mval,Nval,T> &mat1)
  {
    return mat1*scalar;
  }


  /** \brief Compute the inverse of a Matrix.
   *
   * Uses Gauss-Jordan elimination.
   *
   * \relates Matrix
   **/
  template <int Mval, class T>
  inline Matrix<Mval,Mval,T> inv(const Matrix<Mval,Mval,T> &A)
  {
    //std::cerr << "in general inverse" << std::endl;
    Matrix<Mval,Mval,T> B = identityMatrix<Mval,T>();
    return B.gaussJordanElimination(A);
  }


  /** \brief Concatenate two matrices horizontally.
   *
   * Matrices must have the same number of rows.
   *
   * \relates Matrix
   **/
  template<int Mval, int Nval, int Nval2, class T>
  inline Matrix<Mval, Nval+Nval2, T> 
  concat(const Matrix<Mval,Nval,T> &M1, const Matrix<Mval,Nval2,T> &M2) 
  {
    return M1.concat(M2);
  }

  /** \brief Stack two matrices vertically.  
   *
   * Matrices must have the same number of columns.
   *
   * \relates Matrix
   **/
  template<int Mval, int Mval2, int Nval, class T>
  inline Matrix<Mval+Mval2, Nval, T> 
  stack(const Matrix<Mval,Nval,T> &M1, const Matrix<Mval2,Nval,T> &M2) 
  {
    return M1.stack(M2);
  }

  /** \brief Calculate the distance between two matrices.
   *
   * Computes the L2-norm of the difference of the matrices.
   *
   * \relates Matrix
   **/
  template<int Mval, int Nval, class T>
  inline T dist(const Matrix<Mval,Nval,T> &M1, const Matrix<Mval,Nval,T> &M2)
  {
    return (Matrix<Mval,Nval,T>(M1-M2)).norm();
  }

  /** \name Special Matrix Creation */
  /// @{
  /** \brief Create a Matrix consisting of diagonal elements equal to `el' and the remainder all zeros.
   *
   * \relates Matrix
   **/
  template<int Mval, class T>
  inline Matrix<Mval,Mval,T> diagonalMatrix(const T &el)
  {
    Matrix<Mval,Mval,T> result = zerosMatrix<Mval,Mval,T>();
    for(int m = 0; m < Mval; m++)
      result[m][m] = el;
    return result;
  }

  /** \brief Create a Matrix with the elements along the diagonal equal to the elements of a ColVector vec, 
   * and the remainder all zeros. 
   *
   * \relates Matrix
   **/
  template<int Mval, class T>
  inline Matrix<Mval,Mval,T> diagonalMatrix(const ColVector<Mval,T> &vec)
  {
    Matrix<Mval,Mval,T> result = zerosMatrix<Mval,Mval,T>();
    for(int m = 0; m < Mval; m++)
      result[m][m] = vec[m];
    return result;
  }

  /** \brief Create a Matrix with the elements along the diagonal equal to the elements of a RowVector vec, 
   * and the remainder all zeros. 
   *
   * \relates Matrix
   **/
  template<int Mval, class T>
  inline Matrix<Mval,Mval,T> diagonalMatrix(const RowVector<Mval,T> &vec)
  {
    Matrix<Mval,Mval,T> result = zerosMatrix<Mval,Mval,T>();
    result.zero();
    for(int m = 0; m < Mval; m++)
      result[m][m] = vec[m];
    return result;
  }
  
  /** \brief Create an MxM identity Matrix. 
   *
   * \relates Matrix
   **/
  template<int Mval, class T>
  inline Matrix<Mval,Mval,T> identityMatrix()
  {
    return diagonalMatrix<Mval,T>(T(1.0));
  }

  
  /** \brief Create an MxN Matrix of all ones. 
   *
   * \relates Matrix
   **/
  template<int Mval, int Nval, class T>
  inline Matrix<Mval,Nval,T> onesMatrix()
  {
    Matrix<Mval,Nval,T> result;
    return result.setOnes();
  }
  
  /** \brief Create an MxN Matrix of all zeros. 
   *
   * \relates Matrix
   **/
  template<int Mval, int Nval, class T>
  inline Matrix<Mval,Nval,T> zerosMatrix()
  {
    Matrix<Mval,Nval,T> result;
    return result.zero();
  }
  /// @}

  template<int Mval,int Nval,class T>
  void Matrix<Mval,Nval,T>::swaprows(const unsigned int i, const unsigned int j) { // 1 based indexes
    RowVector<Nval, T> tempRow(this->row(i-1));
    for (int k = 1; k <= Nval; k ++) {
        mat[i-1][k-1] = mat[j-1][k-1];
    }
    for (int k = 1; k <= Nval; k ++) {
        mat[j-1][k-1] = tempRow[k-1];
    }
  }


  /** \brief Perform Gauss-Huard elimination on a Matrix.
   *
   * Gauss-Huard elmination is a variant of Gauss-Jordan Elimination,
   * and is numerically stable with pivoting. The inverse of A is obtained
   * when *this is the Identity matrix
   *
   * \param A the system matrix for which *this is the RHS to sove for
   * \return b = A'x, where x is *this
   *
   * \note This code adapted from:
   *  Walter Hoffman, "The Gauss-Huard algorithm and LU factorization", 
   *  Linear Algebra and its Applications 275-276 (1998) pp. 282
   *  Pivoting strategy adapted from:
   *  Ke Chen and David Evans, "An efficient variant of gauss-jordan type
   *  algorithms for direct and parallel solution of dense linear systems",
   *  International Journal of Computer Mathematics, Vol. 76., 2001, pp 386-410
   **/
  template<int Mval,int Nval,class T>
  Matrix<Mval,Nval,T> Matrix<Mval,Nval,T>::gaussJordanElimination(const Matrix<Mval,Mval,T> &A) const
  {

    // Gauss-Huard with separate a,b
    Matrix<Mval,Nval,T> b(*this);
    Matrix<Mval,Mval,T> a(A);

    unsigned int piv;
    T maxPiv, tmp, scale;

    // store pivot indices for lter unwrapping
    int pivots[Mval];
    for(unsigned int k=0;k<Mval;++k) {
      pivots[k] = k;
    }


    for(unsigned int k=0; k<Mval; ++k) {
      // find maximal pivot column
      piv = k;
      maxPiv = fabs(a[k][k]);
      for(unsigned int i=k+1; i<Mval; ++i) {
        const T curr = fabs(a[k][i]);
        if(maxPiv < curr) {
          maxPiv = curr;
          piv = i;
        }
      }

      if(!maxPiv) {          // check pivot element is non-zero
        return zerosMatrix<Mval,Nval,T>();
      }

      // swap columns
      if(piv-k) {
        for(unsigned int i=0;i<Mval;++i) {
          tmp = a[i][k];
          a[i][k] = a[i][piv];
          a[i][piv] = tmp;
        }
        tmp = pivots[k];
        pivots[k] = pivots[piv];
        pivots[piv] = tmp;
      }

      // Gauss-Huard inversion

      // scale row k
      for(unsigned int i=0; i<k; ++i) {
        scale = a[k][i];
        for(unsigned int j=k; j<Mval;++j)
          a[k][j] -= scale*a[i][j];
        for(unsigned int j=0; j<Nval;++j)
          b[k][j] -= scale*b[i][j];
      }

      // normalise row k
      scale = (T)1.0/a[k][k];
      for(unsigned int j=k+1;j<Mval;++j)
        a[k][j] *= scale;
      for(unsigned int j=0; j<Nval; ++j)
        b[k][j] *= scale;
      
      // eliminate upper right region
      for(unsigned int i=0;i<k;++i) {
        for(unsigned int j=k+1;j<Mval;++j)
          a[i][j] -= a[i][k]*a[k][j];
        for(unsigned int j=0;j<Nval;++j)
          b[i][j] -= a[i][k]*b[k][j];
      }
    }

    // permute rows of result
    // more consistent results with new matrix (rather than re-using a)
    Matrix<Mval,Nval,T> b_;
    for(unsigned int i=0;i<Mval;++i) {
      piv = pivots[i];
      for(unsigned int j=0; j<Nval; ++j) {
        b_[piv][j] = b[i][j];
      }
    }

    return b_;

  }

  /** \brief Perform LDL factorization on a symmetric positive definate matrix.
   *
   * \return L*D*L' = A, where A is *this, LDL packed into square matrix
   *
   * \note  this does not work when the first element of the matrix is zero
   **/
  template<int Nval, class T>
  Matrix<Nval,Nval,T> factorizeLDL(const Matrix<Nval,Nval,T> &A)
  {
    Matrix<Nval,Nval,T> L(A); // get a copy of A;

    unsigned int i,j,k;
    for (j=0;j<Nval;++j) {
      T sum(0);
      // Dj = Ajj - sum_k=1^j-1(Ljk^2 Dk)
      for (k=0;k<j;++k) {
	sum += L[j][k]*L[j][k]*L[k][k];
      }
      T Ajj(A[j][j]);
      T Dj = Ajj - sum;
      L[j][j] = Dj;  
      
      for (i=j+1;i<Nval;++i) {
	sum = 0;
	// Lij = 1/Dj (Aij - sum_k=1^j-1(Lik Ljk Dk)
	for (k=0;k<j;++k) {
	  sum += L[i][k]*L[j][k]*L[k][k];
	}
	T Dj(L[j][j]);
	T Aij(A[i][j]);
	L[i][j] = L[j][i] = (Aij-sum)/Dj;
      }
    }
    return L;
  }

  /** \brief solve a system using an LDU factorization matrix.
   *
   * \return X from  L*D*U * X = B, where LDU packed into square matrix
   *
   **/
  template <int Mval,int Nval,class T>
  Matrix<Mval,Nval,T> LDUsolver(const Matrix<Mval,Mval,T> &LDU, const Matrix<Mval,Nval,T> &B)
  {
    Matrix<Mval,Nval,T> X;
    ColVector<Mval,T> Y;
    unsigned int i,j,k;

    // solving L (D (U x) ) = B

    // for every column in the input x
    for (j=0;j<Nval;++j) {

      // forward substitue to solve for Y in L Y = B
      // yi = 1/Lii *( Bi - sum_k=0^i-1( Aik*Yk ) )  -> but Lii == 1
      Y[0] = B[0][j];
      for (i=1;i<Mval;++i) {
	T sum(0);
	for (k=0;k<i;++k) {
	  sum += LDU[i][k]*Y[k];
	}
	Y[i] = (B[i][j] - sum);
      }

      // solve for D y2 = y
      for (i=0;i<Mval;++i) {
	Y[i] /= LDU[i][i];
      }
      
      // back substitution to solve U' x = y
      // Xi = 1/Uii * (Yi - sum_k=i+1^N Uik * Xk)    but Uii == 1
      X[Mval-1][j] = Y[Mval-1];
      for (i=Mval-2;i<Mval;--i) {
	T sum(0);
	for (k=i+1;k<Mval;++k) {
	  sum += LDU[i][k]*X[k][j];
	}
	X[i][j] = Y[i] - sum;
      }
    }
    return X;
  }

  /* VECTOR CLASSES */

    
  /** \class ColVector 
   * \brief Column vectors.
   * ColVector sizes are constant and must be known at compile time.
   *
   * Several commonly used ColVector sizes are also defined as types:
   * \link SMALL::Vector2D Vector2D\endlink, \link SMALL::Vector3D Vector3D\endlink, 
   * \link SMALL::Vector4D Vector4D\endlink, and \link SMALL::Vector6D Vector6D\endlink.
   */
  template<int Mval, class T>
  class ColVector : public Matrix<Mval,1,T>
  {
    typedef Matrix<Mval,1,T> ParentMatrix;
  public:

    /// @cond IGNORE
    enum { M = Mval };
    /// @endcond

    /**
     * \name ColVector Constructors 
     */
    /// @{

    /** 
     * \brief Default constructor 
     */
    ColVector() : ParentMatrix() { }
    /**
     * \brief Initialize all elements to el
     */
    ColVector(const T &el) : ParentMatrix(el) { }
    /**
     * \brief Initialize from an array of element values
     *
     * \param els An array of elements that must be at least the size of the ColVector
     * (if it is larger, then only the first Mval elements are used).
     */
    ColVector(const T *els) : ParentMatrix(els) { }
    /**
     * \brief Initialize from a Matrix object
     */
    ColVector(const ParentMatrix &mat1) : ParentMatrix(mat1) { }
    /**
     * \brief Initialize from a ColVector object
     */
    ColVector(const ColVector<Mval,T> &vec1) : ParentMatrix(vec1) { }

    /// @}

    /**
     * \name ColVector Assignment
     */
    /// @{


    /**
     * \brief Assignment operator: set using a ColVector object
     */
    ColVector<Mval,T> &operator=(const ColVector<Mval,T> &vec1) {
      ParentMatrix::operator=(vec1);
      return *this;
    }

    /**
     * \brief operator+=: self-add a ColVector
    **/
    ColVector<Mval,T> &operator+=(const ColVector<Mval,T> &vec1) {
      ParentMatrix::operator+=(vec1);
      return *this;
    }

    /**
     * \brief operator-=: self-subtract a ColVector
     **/
    ColVector<Mval,T> &operator-=(const ColVector<Mval,T> &vec1) {
      ParentMatrix::operator-=(vec1);
      return *this;
    }

    /**
     * \brief Assignment operator: set from array of element values
     *
     * \param els An array of elements that must be at least the size of the ColVector
     * (if it is larger, then only the first Mval elements are used).
     * <i>e.g.</i>, double els[] = { 2.0, 3.1, 4.7 };
     */
    ColVector<Mval,T> &operator=(const T *els) {
      ParentMatrix::operator=(els);
      return *this;
    }
    /**
     * \brief Assignment operator: set from a list of
     * comma-separated values
     *
     * <i>e.g.</i>, ColVector<3,double> vec; vec = 1.1,2.0,3.2; 
     *
     * \note This cannot be used upon construction; 
     * i.e., ColVector<3,double> vec = 1.1,2.0,3.2; will not compile
     */
    MatIndexer<Mval,1,T,1> operator=(const T &el) {
      return ParentMatrix::operator=(el);
    }

    /**
     * \brief operator+=: add a list of
     * comma-separated values to a ColVector
     *
     * <i>e.g.</i>, ColVector<3,double> vec; 
     *              ...
     *              vec += 1.1,2.0,3.2; 
     **/
    MatIndexer<Mval,1,T,1> operator+=(const T &el) {
      return ParentMatrix::operator+=(el);
    }

    /**
     * \brief operator-=: subtract a list of
     * comma-separated values from a ColVector
     *
     * <i>e.g.</i>, ColVector<3,double> vec; 
     *              ...
     *              vec -= 1.1,2.0,3.2; 
     **/
    MatIndexer<Mval,1,T,1> operator-=(const T &el) {
      return ParentMatrix::operator-=(el);
    }

    /// @}

    /** 
     * \name ColVector Access
     */
    /// @{
	
    /**
     * \brief 0-based indexing
     *
     * \param index Must be within ColVector bounds [0,Mval-1]
     **/
    T &operator[](int index) {
      return this->mat[index][0]; 
    }
    /**
     * \brief 0-based indexing
     *
     * \param index Must be within ColVector bounds [0,Mval-1]
     **/
    const T &operator[](int index) const {
      return this->mat[index][0];
    }
    /**
     * \brief 1-based indexing
     *
     * \param index Must be within ColVector bounds [1,Mval]
     **/
    T &operator()(int index) {
      return this->mat[index-1][0];
    }
    /**
     * \brief 1-based indexing
     *
     * \param index Must be within ColVector bounds [1,Mval]
     */
    const T &operator()(int index) const {
      return this->mat[index-1][0];
    }
    /**
     * \brief Access sub elements of the vector
     *
     * usage: s = vec.sub<start_row,end_row>()
     */
    template<int r0,int r1>
    ColVector<r1-r0+1,T>  
    sub() const {
      return ParentMatrix::template sub<r0,r1,0,0>();
    }

    /** \brief Get the size of the vector */
    unsigned int size(){
      return (unsigned int)Mval;
    }
    /// @}

    /** 
     * \name ColVector Operations
     * 
     * Other ColVector operations are defined in linalg.hh
     */
    /// @{

    /**
     * \brief Cross-product with another ColVector object
     * \note This only works with vectors of dimension 3.
     */
    ColVector<Mval,T> cross(const ColVector<Mval,T> &v) const
    {
      return SMALL::cross(*this,v);
    }

    /**
     * \brief Dot-product with another ColVector object
     */
    T dot(const ColVector<Mval,T> &vec1) const {
      T result = 0.0;
      for(int m = 0; m < Mval; m++)
	result += vec1[m]*this->mat[m][0];
      return result;          
    }
    /**
     * \brief Dot-product with a RowVector object
     */
    T dot(const RowVector<Mval,T> &vec1) const {
      T result = 0.0;
      for(int m = 0; m < Mval; m++)
	result += vec1[m]*this->mat[m][0];
      return result;          
    }
   

    /**
     * \brief Return a homogenized version of this ColVector
     *
     * The vector size is not changed.
     * <i>e.g.</i>, \f$ [ 4.4; 8.2; 6.0; 2.0; ] \rightarrow [ 2.2; 4.1; 3.0; 1.0; ] \f$
     */
    ColVector<Mval,T> homogenized() const {
      return (*this)*(T(1.0)/this->mat[Mval-1][0]);
    }
    /**
     * \brief Homogenizes this ColVector
     *
     * The vector size is not changed.
     * <i>e.g.</i>, \f$ [ 4.4; 8.2; 6.0; 2.0; ] \rightarrow [ 2.2; 4.1; 3.0; 1.0; ] \f$
     */
    ColVector<Mval,T> homogenize() { 
      return *this = homogenized(); 
    }

    /// @}
  }; // End of class ColVector

  /**
   * \class RowVector
   * \brief Row vectors.
   * RowVector sizes are constant and must be known at compile time.
   */
  template<int Mval, class T>
  class RowVector : public Matrix<1,Mval,T>
  {
    typedef Matrix<1,Mval,T> ParentMatrix;
  public:

    /**
     * \name RowVector Constructors 
     */
    /// @{

    /** 
     * \brief Default constructor 
     */
    RowVector() : ParentMatrix() { }
    /**
     * \brief Initialize all elements to el
     */
    RowVector(const T &el) : ParentMatrix(el) { }
    /**
     * \brief Initialize from an array of element values
     *
     * \param els An array of elements that must be at least the size of the ColVector
     * (if it is larger, then only the first Mval elements are used).
     **/
    RowVector(const T *els) : ParentMatrix(els) { }
    /**
     * \brief Initialize from a Matrix object
     */
    RowVector(const ParentMatrix &mat1) : ParentMatrix(mat1) { }
    /**
     * \brief Initialize from a ColVector object
     */
    RowVector(const RowVector<Mval,T> &vec1) : ParentMatrix(vec1) { }

    /// @}

    /**
     * \name RowVector Assignment
     */
    /// @{


    /**
     * \brief Assignment operator: set using a RowVector object
     */
    RowVector<Mval,T> &operator=(const RowVector<Mval,T> &vec1) {
      ParentMatrix::operator=(vec1);
      return *this;
    }
    /**
     * \brief operator+=: self-add a RowVector
    **/
    RowVector<Mval,T> &operator+=(const RowVector<Mval,T> &vec1) {
      ParentMatrix::operator+=(vec1);
      return *this;
    }

    /**
     * \brief operator-=: self-subtract a RowVector
     **/
    RowVector<Mval,T> &operator-=(const RowVector<Mval,T> &vec1) {
      ParentMatrix::operator-=(vec1);
      return *this;
    }

    /**
     * \brief Assignment operator: set from array of elements values
     *
     * \param els An array of elements that must be at least the size of the ColVector
     * (if it is larger, then only the first Mval elements are used).
     * <i>e.g.</i>, double els[] = { 2.0, 3.1, 4.7 };
     */
    RowVector<Mval,T> &operator=(const T *els) {
      ParentMatrix::operator=(els);
      return *this;
    }
    /**
     * \brief Assignment operator: set from a list of
     * comma-separated values
     *
     * <i>e.g.</i>, RowVector<3,double> vec; vec = 1.1,2.0,3.2; 
     *
     * \note This cannot be used upon construction; 
     * i.e., RowVector<3,double> vec = 1.1,2.0,3.2; will not compile
     */
    MatIndexer<1,Mval,T,1> operator=(const T &el) {
      return ParentMatrix::operator=(el);
    }
    /**
     * \brief operator+=: add a list of
     * comma-separated values to a RowVector
     *
     * <i>e.g.</i>, RowVector<3,double> vec; 
     *              ...
     *              vec += 1.1,2.0,3.2; 
     **/
    MatIndexer<1,Mval,T,1> operator+=(const T &el) {
      return ParentMatrix::operator+=(el);
    }
    /**
     * \brief operator-=: subtract a list of
     * comma-separated values from a RowVector
     *
     * <i>e.g.</i>, RowVector<3,double> vec; 
     *              ...
     *              vec -= 1.1,2.0,3.2; 
     **/
    MatIndexer<1,Mval,T,1> operator-=(const T &el) {
      return ParentMatrix::operator-=(el);
    }

    /// @}

	
	
    /** 
     * \name RowVector Access
     */
    /// @{
	
    /**
     * \brief 0-based indexing
     *
     * \param index Must be within RowVector bounds [0,Nval-1]
     **/
    T &operator[](int index) {
      return this->mat[0][index];
    }
    /**
     * \brief 0-based indexing
     *
     * \param index Must be within RowVector bounds [0,Nval-1]
     **/
    const T &operator[](int index) const {
      return this->mat[0][index];
    }
    /**
     * \brief 1-based indexing
     *
     * \param index Must be within RowVector bounds [1,Nval]
     **/
    T &operator()(unsigned int index) {
      return this->mat[index-1][0];
    }
    /**
     * \brief 1-based indexing
     *
     * \param index Must be within RowVector bounds [1,Nval]
     **/
    const T &operator()(unsigned int index) const {
      return this->mat[index-1][0];
    }
    /**
     * \brief Access sub elements of the vector
     *
     * usage: s = vec.sub<start_column,end_column>()
     */
    template<int c0,int c1>
    RowVector<c1-c0+1,T>  
    sub() const {
      return ParentMatrix::template sub<0,0,c0,c1>();
    }

    /** \brief Get the size of the vector */
    unsigned int size(){
      return (unsigned int)Mval;
    }

    /// @}


    /** 
     * \name RowVector Operations
     *
     * Other RowVector operations are defined in linalg.hh
     */
    /// @{

    /**
     * \brief Cross-product with another RowVector object
     * \note This only works with vectors of dimension 3.
     */
    RowVector<Mval,T> cross(const RowVector<Mval,T> &v) const
    {
      return SMALL::cross(*this,v);
    }

    /**
     * \brief Vector dot product with a RowVector object
     */
    T dot(const RowVector<Mval,T> &vec1) const {
      T result = 0.0;
      for(int m = 0; m < Mval; m++)
	result += vec1[m]*this->mat[0][m];
      return result;          
    }
    /**
     * \brief Vector dot product with a ColVector object
     */
    T dot(const ColVector<Mval,T> &vec1) const {
      T result = 0.0;
      for(int m = 0; m < Mval; m++)
	result += vec1[m]*this->mat[0][m];
      return result;          
    }
   
    /**
     * \brief Return a homogenized version of this RowVector
     *
     * The vector size is not changed.
     * <i>e.g.</i>, \f$ [ 4.4, 8.2, 6.0, 2.0 ] \rightarrow [ 2.2, 4.1, 3.0, 1.0 ] \f$
     */
    RowVector<Mval,T> homogenized() const {
      return (*this)*(T(1.0)/this->mat[0][Mval-1]);
    }
    /**
     * \brief Homogenizes this RowVector
     *
     * The vector size is not changed.
     * <i>e.g.</i>, \f$ [ 4.4, 8.2, 6.0, 2.0 ] \rightarrow [ 2.2, 4.1, 3.0, 1.0 ] \f$
     */
    RowVector<Mval,T> homogenize() const {
      return *this = homogenized();
    }    

    /// @}
  }; // End of class RowVector


  /** \class MatIndexer 
   * 
   * \brief Utility class for the Matrix class.
   * Provides indexing to the Matrix class to allow assignment using comma-separated
   * list of elements, column vectors, and row vectors.
   *
   **/
  template<int Mval, int Nval, class T, int Pval>
  class MatIndexer
  {
  private:
    Matrix<Mval,Nval,T> &matRef;
    MatIndexerOpEnum op;

  public:

    /** \brief Constructor: set which matrix this class should refer to. */
    MatIndexer(Matrix<Mval,Nval,T> &mat, MatIndexerOpEnum _op) : matRef(mat), op(_op)
    { 
      // A compile-time check to ensure that Pval is within the matrix bounds (user
      // is not trying to overflow the matrix). This will come out as an error like:
      // "linalg.hh:2129: error: creating array with negative size (‘-0x00000000000000001’)"
      // Unfortunately, this message isn't all that clear in telling the user what
      // the problem is, but at least they will know to look here (which is better than
      // the potential run-time errors that can occur).
      double boundsCheck[Nval*Mval-Pval]; 
      void *bcAdd = &boundsCheck;  // ugly, but avoids compiler
      bcAdd = NULL;                //   'unused variable' warnings
    }
    
    /** \brief Get the matrix reffered to by this indexer. */
    Matrix<Mval,Nval,T> &getRef() { return matRef; }

    /** \brief Return the element indexed by this MatIndexer */
    inline T &element() { return matRef[Pval/Nval][Pval%Nval]; }

    /** \brief Used for setting a matrix to a comma-separated list of elements. */
    inline MatIndexer< Mval,Nval,T,Pval+1 > operator,(const T &el)
    {
      switch (op) {
      case MATINDEXER_EQ: element() = el; break;
      case MATINDEXER_PE: element() += el; break;
      case MATINDEXER_ME: element() -= el; break;
      }
      MatIndexer< Mval,Nval,T, Pval+1 > i(getRef(),op);
      return i;
    }

    /** \brief Used for setting a matrix to a comma-separated list of ColVectors. */
    inline MatIndexer< Mval,Nval,T, Pval+1 > operator,(const ColVector<Mval,T> &col)
    {
      for(int m = 0; m < Mval; m++)
        switch (op) {
        case MATINDEXER_EQ: matRef[m][Pval] =  col[m]; break;
        case MATINDEXER_PE: matRef[m][Pval] += col[m]; break;
        case MATINDEXER_ME: matRef[m][Pval] -= col[m]; break;
        }
      MatIndexer< Mval,Nval,T, Pval+1 > i(getRef(),op);
      return i;
    }

    /** \brief Used for setting a matrix to a comma-separated list of RowVectors. */
    inline MatIndexer< Mval,Nval,T, Pval+1 > operator,(const RowVector<Nval,T> &row)
    {
      for(int n = 0; n < Nval; n++)
        switch (op) {
        case MATINDEXER_EQ: matRef[Pval][n] =  row[n]; break;
        case MATINDEXER_PE: matRef[Pval][n] += row[n]; break;
        case MATINDEXER_ME: matRef[Pval][n] -= row[n]; break;
        }
      MatIndexer< Mval,Nval,T, Pval+1 > i(getRef(),op);
      return i;
    }
  }; // End of class MatIndexer




  /** \name Common Vector and Matrix sizes/types 
   **/
  /// @{
  // It would be nice to 'relate' these to ColVector and Matrix within
  // Doxygen, but the \relates tag only applies to functions.
  typedef ColVector<2,double> Vector2D; /**< \brief 2D ColVector of doubles */
  typedef ColVector<3,double> Vector3D; /**< \brief 3D ColVector of doubles */
  typedef ColVector<4,double> Vector4D; /**< \brief 4D ColVector of doubles */
  typedef ColVector<6,double> Vector6D; /**< \brief 6D ColVector of doubles */
  typedef Matrix<2,2,double> Matrix22;  /**< \brief 2x2 Matrix of doubles */
  typedef Matrix<2,3,double> Matrix23;  /**< \brief 2x3 Matrix of doubles */
  typedef Matrix<3,3,double> Matrix33;  /**< \brief 3x3 Matrix of doubles */
  typedef Matrix<3,4,double> Matrix34;  /**< \brief 3x4 Matrix of doubles */
  typedef Matrix<4,4,double> Matrix44;  /**< \brief 4x4 Matrix of doubles */
  typedef Matrix<6,6,double> Matrix66;  /**< \brief 6x6 Matrix of doubles */
  /// @}

 
  /** \name Specialized Matrix and ColVector Functions
   *
   * \brief For small common Matrix and ColVector sizes.
   **/
  /// @{

  /** \brief Create a column vector with elements v1,v2. 
   * \relates ColVector **/
  inline Vector2D makeVector(double v1, double v2)
  {
    Vector2D v;
    v = v1,v2;
    return v;
  }

  /** \brief Create a column vector with elements v1,v2,v3. 
   * \relates ColVector **/
  inline Vector3D makeVector(double v1, double v2, double v3)
  {
    Vector3D v;
    v = v1,v2,v3;
    return v;
  }

  /** \brief Create a column vector with elements v1,v2,v3,v4. 
  * \relates ColVector **/
  inline Vector4D makeVector(double v1, double v2, double v3, double v4)
  {
    Vector4D v;
    v = v1,v2,v3,v4;
    return v;
  }

  /** \brief Create a column vector with elements v1,v2,v3,v4,v5,v6. 
   * \relates ColVector **/
  inline Vector6D makeVector(double v1, double v2, double v3, double v4, double v5, double v6)
  {
    Vector6D v;
    v = v1,v2,v3,v4,v5,v6;
    return v;
  }


  /** \brief Convert a 1x1 Matrix to a scalar 
   *
   * \relates Matrix
   **/
  template <class T> inline T Scalar(const Matrix<1,1,T> &m11){
    return m11[0][0];
  }

  /** \brief Specialization of determinant for a 1x1 T Matrix. 
   *
   * \relates Matrix
   **/
  template <class T> inline T det(const Matrix<1,1,T> &M) 
  {
    return M[0][0];
  }
  
  /** \brief Specialization of inverse for a 1x1 T Matrix. 
   *
   * \relates Matrix
   **/
  template <class T> inline Matrix<1,1,T> inv(const Matrix<1,1,T> &M)
  {
    return Matrix<1,1,T>(T(1.0)/M[0][0]);
  }
  
  /** \brief Specialization of determinant for a 2x2 T Matrix. 
   *
   * \relates Matrix
   **/
  template <class T> inline T det(const Matrix<2,2,T> &M)
  {
    return M[0][0]*M[1][1] - M[0][1]*M[1][0];
  }

  /** \brief Specialization of inverse for a 2x2 T Matrix. 
   *
   * \relates Matrix
   **/
  template <class T> inline Matrix<2,2,T> inv(const Matrix<2,2,T> &A) 
  {
    Matrix<2,2,T> result;
    T det = A.determinant();
    T idet = (det != T(0) ? 1.0/det : T(0));
    result[0][0] = idet * A[1][1];
    result[0][1] = idet * -A[0][1];
    result[1][0] = idet * -A[1][0];
    result[1][1] = idet * A[0][0];
    return result;
  }

  /** \brief Create 3x3 skew-symmetric Matrix from a 3x1 column vector 
   *
   * \f$ [ x; y; z; ] \rightarrow [ 0, -z, y; z, 0, -x; -y, x, 0; ] \f$
   *
   * \relates Matrix
   **/
  template<class T>
  inline Matrix<3,3,T> skewSymmetric(const Matrix<3,1,T> &v)
  {
    enum {X=0, Y, Z};
    Matrix<3,3,T> result;
    result[0][0] = T(0.0);
    result[0][1] = -v[Z][0];
    result[0][2] = v[Y][0];
    result[1][0] = v[Z][0];
    result[1][1] = T(0.0);
    result[1][2] = -v[X][0];
    result[2][0] = -v[Y][0];
    result[2][1] = v[X][0];
    result[2][2] = T(0.0);
    return result;
  }

  /** \brief Create 3x3 skew-symmetric Matrix from a 1x3 row vector 
   *
   * \f$ [ x, y, z; ] \rightarrow [ 0, -z, y; z, 0, -x; -y, x, 0; ] \f$
   *
   * \relates Matrix
   **/
  template<class T>
  inline Matrix<3,3,T> skewSymmetric(const Matrix<1,3,T> &v)
  {
    enum {X=0, Y, Z};
    Matrix<3,3,T> result;
    result[0][0] = T(0.0);
    result[0][1] = -v[0][Z];
    result[0][2] = v[0][Y];
    result[1][0] = v[0][Z];
    result[1][1] = T(0.0);
    result[1][2] = -v[0][X];
    result[2][0] = -v[0][Y];
    result[2][1] = v[0][X];
    result[2][2] = T(0.0);
    return result;
  }

  /** \brief Create a 3x3 quad-symmetric Matrix from a 3x1 column vector
   *
   * \f$ [ x; y; z; ] \rightarrow [ x^2, xy, xz; xy, y^2, yz; xz, yz, z^2; ] \f$
   *
   * \relates Matrix
   **/
  template<class T>
  inline Matrix<3,3,T> quadSymmetric(const Matrix<3,1,T> &m)
  {
    enum {X=0, Y, Z};
    ColVector<3,T> v(m);

    T xy = v[X]*v[Y];
    T xz = v[X]*v[Z];
    T yz = v[Y]*v[Z];
        
    Matrix<3,3,T> result;
    result[0][0] = v[X]*v[X];
    result[0][1] = xy;
    result[0][2] = xz;
    result[1][0] = xy;
    result[1][1] = v[Y]*v[Y];
    result[1][2] = yz;
    result[2][0] = xz;
    result[2][1] = yz;
    result[2][2] = v[Z]*v[Z];
    return result;
  }

  /** \brief Create a 3x3 quad-symmetric Matrix from a 1x3 row vector
   *
   * \f$ [ x, y, z; ] \rightarrow [ x^2, xy, xz; xy, y^2, yz; xz, yz, z^2; ] \f$
   *
   * \relates Matrix
   **/
  template<class T>
  inline Matrix<3,3,T> quadSymmetric(const Matrix<1,3,T> &m)
  {
    enum {X=0, Y, Z};
    RowVector<3,T> v(m);

    T xy = v[X]*v[Y];
    T xz = v[X]*v[Z];
    T yz = v[Y]*v[Z];
        
    Matrix<3,3,T> result;
    result[0][0] = v[X]*v[X];
    result[0][1] = xy;
    result[0][2] = xz;
    result[1][0] = xy;
    result[1][1] = v[Y]*v[Y];
    result[1][2] = yz;
    result[2][0] = xz;
    result[2][1] = yz;
    result[2][2] = v[Z]*v[Z];
    return result;
  }

  // Note: Cross products are only defined in 3 dimensions

  /** \brief ColVector cross product
   *
   * \relates ColVector
   **/
  template <class T>
  inline ColVector<3,T> cross(const Matrix<3,1,T> &v1, const Matrix<3,1,T> &v2)
  {
    enum {X=0, Y, Z};
    ColVector<3,T> result;
    result[X] = v1[Y][0]*v2[Z][0] - v1[Z][0]*v2[Y][0];
    result[Y] = v1[Z][0]*v2[X][0] - v1[X][0]*v2[Z][0];
    result[Z] = v1[X][0]*v2[Y][0] - v1[Y][0]*v2[X][0];
    return result;
  }

  /** \brief RowVector cross product
   * \relates RowVector 
   **/
  template <class T>
  inline RowVector<3,T> cross(const Matrix<1,3,T> &v1, const Matrix<1,3,T> &v2)
  {
    enum {X=0, Y, Z};
    RowVector<3,T> result;
    result[X] = v1[0][Y]*v2[0][Z] - v1[0][Z]*v2[0][Y];
    result[Y] = v1[0][Z]*v2[0][X] - v1[0][X]*v2[0][Z];
    result[Z] = v1[0][X]*v2[0][Y] - v1[0][Y]*v2[0][X];
    return result;
  }


  /** \brief Specialization of inverse for a 3x3 T Matrix. 
   *
   * \relates Matrix
   **/
  template <class T> inline Matrix<3,3,T> inv(const Matrix<3,3,T> &A) 
  {
    Matrix<3,3,T> result;

    T m11 = A[1][1]*A[2][2] - A[1][2]*A[2][1];
    T m12 = A[0][2]*A[2][1] - A[0][1]*A[2][2];
    T m13 = A[0][1]*A[1][2] - A[0][2]*A[1][1];
    T d = A[0][0]*m11 + A[1][0]*m12 + A[2][0]*m13;
    if (d != 0) {
      d = T(1.0)/d;
    }
    result[0][0] = d*m11; 
    result[0][1] = d*m12; 
    result[0][2] = d*m13;
    result[1][0] = d*(A[1][2]*A[2][0] - A[1][0]*A[2][2]);
    result[1][1] = d*(A[0][0]*A[2][2] - A[0][2]*A[2][0]);
    result[1][2] = d*(A[0][2]*A[1][0] - A[0][0]*A[1][2]);
    result[2][0] = d*(A[1][0]*A[2][1] - A[1][1]*A[2][0]);
    result[2][1] = d*(A[0][1]*A[2][0] - A[0][0]*A[2][1]);
    result[2][2] = d*(A[0][0]*A[1][1] - A[0][1]*A[1][0]);
    return result;
  }


  /** \brief Specialization of determinant for a 3x3 T Matrix.
   *
   * \relates Matrix
   **/
  template <class T> inline T det(const Matrix<3,3,T> &M)
  {
    return (M[0][0]*(M[1][1]*M[2][2] - M[1][2]*M[2][1]) +
            M[0][1]*(M[1][2]*M[2][0] - M[1][0]*M[2][2]) +
            M[0][2]*(M[1][0]*M[2][1] - M[1][1]*M[2][0]));
  }




// Macros for eig
#define SQR(x)      ((x)*(x))                        // x^2

 /** \brief Compute eigenvectors and eigenvalues for an NxN Matrix (N > 3)
   *
   *  Matrix must be real, symmetric, and strictly diagonally dominant
   *  (e.g. a covariance matrix)
   *  The eigenvectors are returned in an MxM Matrix,
   *  and the eigenvalues are returned in a Mx1 ColVector
   *
   *  \note Template specializations exist for 3x3 and 2x2 case:
   *  \see Matrix33::eigen<Matrix33 v, Vector3D d>
   *  \see Matrix33::eigen<Matrix22 v, Vector2D d>
   *  \note values are not sorted
   *
   *  Uses Jacobi method adapted from:
   *      Joachim Kopp,
   *      Efficient numerical diagonalization of hermitian 3x3 matrices,
   *      Int. J. Mod. Phys. C 19 (2008) 523-548,
   *      arXiv.org: physics/0610206
   *  The code library is available from Joachim's home page at:
   *    http://www.mpi-hd.mpg.de/personalhomes/globes/3x3/index.html
   *  In particular, the method makes use of the dsyevj3.c, with minor
   *  modifications for SMALL types.
   *  This code is governed by the GNU Lesser General Public License (LGPL)
   *  which is availble from http://www.gnu.org/licenses/
   *
   * \relates Matrix
   *
   * \param v Output matrix for eigenvectors
   * \param d Output vector for eigenvalues
   *
   * \warning Logarithmically distributed eigenvalues can lead to large errors
   * in the estimation of both eigenvectors and eigenvalues.
   */
  template<int Mval, class T>
  inline void eig(const Matrix<Mval,Mval,T> &M, Matrix<Mval,Mval,T> &v, ColVector<Mval,T> &d) 
// ----------------------------------------------------------------------------
// Calculates the eigenvalues and normalized eigenvectors of a symmetric NxN
// matrix A using the Jacobi algorithm.
// ----------------------------------------------------------------------------
// Parameters:
//   A: The symmetric input matrix
//   Q: Storage buffer for eigenvectors
//   w: Storage buffer for eigenvalues
// ----------------------------------------------------------------------------
{
  const unsigned int n = Mval;        // Alias for more terse notation
  T sd, so;                  // Sums of diagonal resp. off-diagonal elements
  T s, c, t;                 // sin(phi), cos(phi), tan(phi) and temporary storage
  T g, h, z, theta;          // More temporary storage
  T thresh;
  unsigned int i,p,q,r;    // loop vars

  // Get underlying 2D arrary from the SMALL types
  // so that we can use the notation of the supplied methods
  Matrix<Mval,Mval,T> tmp(M);
  T *A = const_cast<T*>(&tmp[0][0]);  // The matrix to diagonlaize
  T *w = &(d[0]);             // The output eigenvalues
  T *Q = &(v[0][0]);          // The output eigenvectors

  // Initialize Q to the identitity matrix (through v)
  v.setIdentity();

  // Initialize w to diag(A)
  for (i=0; i < n; i++)
    w[i] = A[i*(n+1)];  // A[i][i]

  // Calculate SQR(tr(A))
  sd = 0.0;
  for (i=0; i < n; ++i)
    sd += fabs(w[i]);
  sd = SQR(sd);

  // Main iteration loop
  for (unsigned int nIter=0; nIter < 50; nIter++)
  {
    // Test for convergence
    so = 0.0;
    for (p=0; p < n; ++p)
      for (q=p+1; q < n; ++q)
        so += fabs(A[p*n+q]);
    if (so == 0.0)
      return; // Success

    if (nIter < 4)
      thresh = 0.2 * so / SQR(n);
    else
      thresh = 0.0;

    // Do sweep
    for (p=0; p < n; ++p)
      for (q=p+1; q < n; ++q)
      {
        const unsigned int pq = p*n+q;  // for accessing element [p][q]
        g = 100.0 * fabs(A[pq]);
        if (nIter > 4  &&  fabs(w[p]) + g == fabs(w[p])
                       &&  fabs(w[q]) + g == fabs(w[q]))
        {
          A[pq] = 0.0;
        }
        else if (fabs(A[pq]) > thresh)
        {
          // Calculate Jacobi transformation
          h = w[q] - w[p];
          if (fabs(h) + g == fabs(h))
          {
            t = A[pq] / h;
          }
          else
          {
            theta = 0.5 * h / A[pq];
            if (theta < 0.0)
              t = -1.0 / (sqrt(1.0 + SQR(theta)) - theta);
            else
              t = 1.0 / (sqrt(1.0 + SQR(theta)) + theta);
          }
          c = 1.0/sqrt(1.0 + SQR(t));
          s = t * c;
          z = t * A[pq];

          // Apply Jacobi transformation
          A[pq] = 0.0;
          w[p] -= z;
          w[q] += z;
          for (r=0; r < p; ++r)
          {
            const unsigned int rp = r*n+p;
            const unsigned int rq = r*n+q;
            t = A[rp];
            A[rp] = c*t - s*A[rq];
            A[rq] = s*t + c*A[rq];
          }
          for (r=p+1; r < q; ++r)
          {
            t = A[p*n+r];
            A[p*n+r] = c*t - s*A[r*n+q];
            A[r*n+q] = s*t + c*A[r*n+q];
          }
          for (r=q+1; r < n; ++r)
          {
            t = A[p*n+r];
            A[p*n+r] = c*t - s*A[q*n+r];
            A[q*n+r] = s*t + c*A[q*n+r];
          }

          // Update eigenvectors
          for (r=0; r < n; ++r)
          {
            t = Q[r*n+p];
            Q[r*n+p] = c*t - s*Q[r*n+q];
            Q[r*n+q] = s*t + c*Q[r*n+q];
          }
        }
      }
  }

  // If we are here, the iterations did not converge
  // TODO: Set sentinel values in Q,v (e.g. NaN)??
  // TODO: Sort eigenvalues ??
  return; // failure
}

#undef SQR


  // Preprocessor defs for eigen specializations below
  // Constants
#define M_SQRT3    1.73205080756887729352744634151   // sqrt(3)

  // Macros
#define SQR(x)      ((x)*(x))                        // x^2
#define SQR_ABS(x)  (SQR(creal(x)) + SQR(cimag(x)))  // |x|^2


// ----------------------------------------------------------------------------
    /** \brief Specialization of eig for 2x2 hermitian double Matrix.
   *
   *  \relates Matrix
   *
   *  Compute eigenvalues and eigenvectors
   *  Uses the direct analytical method
   *  This method is adapted from the C code accomanying the paper:
   *      Joachim Kopp
   *      Efficient numerical diagonalization of hermitian 3x3 matrices
   *      Int. J. Mod. Phys. C 19 (2008) 523-548
   *      arXiv.org: physics/0610206
   *  The code library is available from Joachim's home page at:
   *    http://www.mpi-hd.mpg.de/personalhomes/globes/3x3/index.html
   *  In particular, the method makes use of the dsyev2.c, with minor
   *  modifications for SMALL types and sorted values.
   *  This code is governed by the GNU Lesser General Public License (LGPL)
   *  which is availble from http://www.gnu.org/licenses/
   *
   * \param v Output matrix for eigenvectors
   * \param d Output vector for eigenvalues
   */

  template<class T>
  inline void eig(const Matrix<2,2,T> &M, Matrix<2,2,T> &v, ColVector<2,T> &d) {

    double A = M[0][0];
    double B = M[1][0]; // assume M[0][1] == M[1][0]
    double C = M[1][1];

    double sm = A + C;
    double df = A - C;
    double rt = sqrt(SQR(df) + 4.0*B*B);
    double t;

    if (sm > 0.0) {
      d[0] = 0.5 * (sm + rt);
      t = 1.0/(d[0]);
      d[1] = (A*t)*C - (B*t)*B;
    }
    else if (sm < 0.0) {
      d[1] = 0.5 * (sm - rt);
      t = 1.0/(d[1]);
      d[0] = (A*t)*C - (B*t)*B;
    }
    else {      // This case needs to be treated separately to avoid div by 0
      d[0] = 0.5 * rt;
      d[1] = -0.5 * rt;
    }

    // Calculate eigenvectors
    if (df > 0.0) {
      v(1,1) = df + rt;
    } else {
      v(1,1) = df - rt;
    }

    if (fabs(v(1,1)) > 2.0*fabs(B)) {
      t   = -2.0 * B / v(1,1);
      v(2,1) = 1.0 / sqrt(1.0 + SQR(t));
      v(1,1) = t * (v(2,1));
    } else if (fabs(B) == 0.0) {
      v(1,1) = 1.0;
      v(2,1) = 0.0;
    } else {
      t   = -0.5 * (v(1,1)) / B;
      v(1,1) = 1.0 / sqrt(1.0 + SQR(t));
      v(2,1) = t * (v(1,1));
    }

    if (df > 0.0) {
      t   = v(1,1);
      v(1,1) = -(v(2,1));
      v(2,1) = t;
    }

    // make v skew symmetric (special case for 2x2 eigenvectors)
    v(1,2) = -v(2,1);
    v(2,2) = v(1,1);

  }


#undef SQR_ABS

  /** \brief Specialization of eigen for 3x3 hermitian double Matrix.
   *
   *  \relates Matrix
   *
   *  Compute eigenvalues and eigenvectors in descending order of magnitude.
   *  Uses the direct analytical method attributed to G. Cardano, Ars Magna (1545).
   *  This method is adapted from the C code accomanying the paper:
   *      Joachim Kopp
   *      Efficient numerical diagonalization of hermitian 3x3 matrices
   *      Int. J. Mod. Phys. C 19 (2008) 523-548
   *      arXiv.org: physics/0610206
   *  The code library is available from Joachim's home page at:
   *    http://www.mpi-hd.mpg.de/personalhomes/globes/3x3/index.html
   *  In particular, the method makes use of the dsyevv3.c and
   *  dsyevc3.c files, with minor modifications for SMALL types and sorted values.
   *  This code is governed by the GNU Lesser General Public License (LGPL)
   *  which is availble from http://www.gnu.org/licenses/
   *
   * \param v Output matrix for eigenvectors
   * \param d Output vector for eigenvalues
   *
   * \warning Logarithmically distributed eigenvalues can lead to errors
   * in the estimation of both eigenvectors and eigenvalues.
   * In practice this is observed to be within 1e-14 of the value given by the
   * more accurate Jacobi Method.
   */
  template<class T>
  inline void eig(const Matrix<3,3,T> &M, Matrix<3,3,T> &v, ColVector<3,T> &d)   {
      // TODO: Rename? Why: Jacobi method is more accurate,
      //       and currently unable to call the full template
      //       method for 3x3 matrices

      // Get underlying 2D arrary from the SMALL types
      // so that we can use the notation of the supplied methods
      Matrix<3,3,double> tmp(M);
      double *A = const_cast<double*>(&tmp[0][0]);  // The matrix to diagonlaize
      double *w = &(d[0]);          // The output eigenvalues
      double *Q = &(v[0][0]);       // The output eigenvectors


      ////////////////////////////////////////
      // Compute Eigenvalues
      ////////////////////////////////////////

      double m, c1, c0;

      // Determine coefficients of characteristic poynomial. We write
      //       | a   d   f  |
      //  A =  | d*  b   e  |
      //       | f*  e*  c  |
      double de = A[1] * A[5];                                    // d * e
      double dd = SQR(A[1]);                                      // d^2
      double ee = SQR(A[5]);                                      // e^2
      double ff = SQR(A[2]);                                      // f^2
      m  = A[0] + A[4] + A[8];
      c1 = (A[0]*A[4] + A[0]*A[8] + A[4]*A[8])        // a*b + a*c + b*c - d^2 - e^2 - f^2
              - (dd + ee + ff);
      c0 = A[8]*dd + A[0]*ee + A[4]*ff - A[0]*A[4]*A[8]
                - 2.0 * A[2]*de;                      // c*d^2 + a*e^2 + b*f^2 - a*b*c - 2*f*d*e)

      double p, sqrt_p, q, c, s, phi;
      p = SQR(m) - 3.0*c1;
      q = m*(p - (3.0/2.0)*c1) - (27.0/2.0)*c0;
      sqrt_p = sqrt(fabs(p));

      phi = 27.0 * ( 0.25*SQR(c1)*(p - c1) + c0*(q + 27.0/4.0*c0));
      phi = (1.0/3.0) * atan2(sqrt(fabs(phi)), q);

      c = sqrt_p*cos(phi);
      s = (1.0/M_SQRT3)*sqrt_p*sin(phi);

      //compute eigenvalues
      double e2  = (1.0/3.0)*(m - c);
      double e3  = e2 + s;
      double e1  = e2 + c;
      e2 -= s;

      // sort eigenvalues
      if(e2 > e1) std::swap(e2, e1);
      if(e3 > e2) std::swap(e3, e2);
      if(e2 > e1) std::swap(e2, e1);

      // write out the eigenvalues
      w[0] = e1;
      w[1] = e2;
      w[2] = e3;

      
      /////////////////////////////////
      // Compute Eigenvectors
      /////////////////////////////////

      // Set up state for eigenvector computation
      double norm;          // Squared norm or inverse norm of current eigenvector
      double n0, n1;        // Norm of first and second columns of A
      double n0tmp, n1tmp;  // "Templates" for the calculation of n0/n1 - saves a few FLOPS
      double thresh;        // Small number used as threshold for floating point comparisons
      double error;         // Estimated maximum roundoff error in some steps
      double wmax;          // The eigenvalue of maximum modulus
      double f, t;          // Intermediate storage
      int i, j;             // Loop counters

      wmax = fabs(w[0]);
      if ((t=fabs(w[1])) > wmax)
        wmax = t;
      if ((t=fabs(w[2])) > wmax)
        wmax = t;
      thresh = SQR(8.0 * DBL_EPSILON * wmax);

      // Prepare calculation of eigenvectors
      n0tmp   = SQR(A[1]) + SQR(A[2]);
      n1tmp   = SQR(A[1]) + SQR(A[5]);
      Q[1] = A[1]*A[5] - A[2]*A[4];
      Q[4] = A[2]*A[3] - A[5]*A[0];
      Q[7] = SQR(A[1]);

      // Calculate first eigenvector by the formula
      //   v[0] = (A - w[0]).e1 x (A - w[0]).e2
      A[0] -= w[0];
      A[4] -= w[0];
      Q[0] = Q[1] + A[2]*w[0];
      Q[3] = Q[4] + A[5]*w[0];
      Q[6] = A[0]*A[4] - Q[7];
      norm    = SQR(Q[0]) + SQR(Q[3]) + SQR(Q[6]);
      n0      = n0tmp + SQR(A[0]);
      n1      = n1tmp + SQR(A[4]);
      error   = n0 * n1;

      if (n0 <= thresh)         // If the first column is zero, then (1,0,0) is an eigenvector
      {
        Q[0] = 1.0;
        Q[3] = 0.0;
        Q[6] = 0.0;
      }
      else if (n1 <= thresh)    // If the second column is zero, then (0,1,0) is an eigenvector
      {
        Q[0] = 0.0;
        Q[3] = 1.0;
        Q[6] = 0.0;
      }
      else if (norm < SQR(64.0 * DBL_EPSILON) * error)
      {                         // If angle between A[0] and A[1] is too small, don't use
        t = SQR(A[1]);       // cross product, but calculate v ~ (1, -A0/A1, 0)
        f = -A[0] / A[1];
        if (SQR(A[4]) > t)
        {
          t = SQR(A[4]);
          f = -A[1] / A[4];
        }
        if (SQR(A[5]) > t)
          f = -A[2] / A[5];
        norm    = 1.0/sqrt(1 + SQR(f));
        Q[0] = norm;
        Q[3] = f * norm;
        Q[6] = 0.0;
      }
      else                      // This is the standard branch
      {
        norm = sqrt(1.0 / norm);
        for (j=0; j < 3; j++)
          Q[j*3] = Q[j*3] * norm;
      }


      // Prepare calculation of second eigenvector
      t = w[0] - w[1];
      if (fabs(t) > 8.0 * DBL_EPSILON * wmax)
      {
        // For non-degenerate eigenvalue, calculate second eigenvector by the formula
        //   v[1] = (A - w[1]).e1 x (A - w[1]).e2
        A[0] += t;
        A[4] += t;
        Q[1]  = Q[1] + A[2]*w[1];
        Q[4]  = Q[4] + A[5]*w[1];
        Q[7]  = A[0]*A[4] - Q[7];
        norm     = SQR(Q[1]) + SQR(Q[4]) + SQR(Q[7]);
        n0       = n0tmp + SQR(A[0]);
        n1       = n1tmp + SQR(A[4]);
        error    = n0 * n1;

        if (n0 <= thresh)       // If the first column is zero, then (1,0,0) is an eigenvector
        {
          Q[1] = 1.0;
          Q[4] = 0.0;
          Q[7] = 0.0;
        }
        else if (n1 <= thresh)  // If the second column is zero, then (0,1,0) is an eigenvector
        {
          Q[1] = 0.0;
          Q[4] = 1.0;
          Q[7] = 0.0;
        }
        else if (norm < SQR(64.0 * DBL_EPSILON) * error)
        {                       // If angle between A[0] and A[1] is too small, don't use
          t = SQR(A[1]);     // cross product, but calculate v ~ (1, -A0/A1, 0)
          f = -A[0] / A[1];
          if (SQR(A[4]) > t)
          {
            t = SQR(A[4]);
            f = -A[1] / A[4];
          }
          if (SQR(A[5]) > t)
            f = -A[2] / A[5];
          norm    = 1.0/sqrt(1 + SQR(f));
          Q[1] = norm;
          Q[4] = f * norm;
          Q[7] = 0.0;
        }
        else
        {
          norm = sqrt(1.0 / norm);
          for (j=0; j < 3; j++)
            Q[j*3+1] = Q[j*3+1] * norm;
        }
      }
      else
      {
        // For degenerate eigenvalue, calculate second eigenvector according to
        //   v[1] = v[0] x (A - w[1]).e[i]
        //
        // This would really get to complicated if we could not assume all of A to
        // contain meaningful values.
        A[3]  = A[1];
        A[6]  = A[2];
        A[7]  = A[5];
        A[0] += w[0];
        A[4] += w[0];
        for (i=0; i < 3; i++)
        {
          A[i*3+i] -= w[1];
          n0       = SQR(A[i]) + SQR(A[3+i]) + SQR(A[6+i]);
          if (n0 > thresh)
          {
            Q[1]  = Q[3]*A[6+i] - Q[6]*A[3+i];
            Q[4]  = Q[6]*A[i] - Q[0]*A[6+i];
            Q[7]  = Q[0]*A[3+i] - Q[3]*A[i];
            norm     = SQR(Q[1]) + SQR(Q[4]) + SQR(Q[7]);
            if (norm > SQR(256.0 * DBL_EPSILON) * n0) // Accept cross product only if the angle between
            {                                         // the two vectors was not too small
              norm = sqrt(1.0 / norm);
              for (j=0; j < 3; j++)
                Q[j*3+1] = Q[j*3+1] * norm;
              break;
            }
          }
        }

        if (i == 3)    // This means that any vector orthogonal to v[0] is an EV.
        {
          for (j=0; j < 3; j++)
            if (Q[j*3] != 0.0)                                   // Find nonzero element of v[0] ...
            {                                                     // ... and swap it with the next one
              norm          = 1.0 / sqrt(SQR(Q[j*3]) + SQR(Q[3*((j+1)%3)]));
              Q[3*j+1]       = Q[3*((j+1)%3)] * norm;
              Q[3*((j+1)%3)+1] = -Q[j*3] * norm;
              Q[3*((j+2)%3)+1] = 0.0;
              break;
            }
        }
      }

      // Calculate third eigenvector according to
      //   v[2] = v[0] x v[1]
      Q[2] = Q[3]*Q[7] - Q[6]*Q[4];
      Q[5] = Q[6]*Q[1] - Q[0]*Q[7];
      Q[8] = Q[0]*Q[4] - Q[3]*Q[1];

  }


#undef SQR
#undef M_SQRT3

  template<int Mval, int Nval, class T> 
  void Matrix<Mval,Nval,T>::eigen(Matrix<Mval,Mval,T> &v, ColVector<Mval,T> &d) const {
    eig(*this, v, d);
    return;
  }

  /// @}

  /** \name Angle Conversion */
  /// @{
  /**
   * \brief Converts an angle (in radians) to the range \f$[-\pi,+\pi]\f$ 
   *
   * \param[in] angleRad The angle to re-limit
   * \return The angle in the range \f$[-\pi,+\pi)\f$ in radians
   */
  inline double angleLimitPI( double angleRad ) {

    // if the angle is large (quicker to check exponent on the floating
    // point value than using fabs), then use remainder
    int angleFPexp = ilogb( angleRad );
    if( angleFPexp > 3 ){ // exp > 3
      double a = remainder(angleRad,2*M_PI); 
      if( a >= M_PI )
	a -= 2*M_PI;
      if( a < -M_PI)
	a += 2*M_PI;
      angleRad = a;

    } else if ( angleFPexp > 0 ) {
      // float exponent is pretty small, so don't expect many loops here

      // this is faster when angles are not too far from 0
      while (angleRad >= M_PI) angleRad -= 2*M_PI;
      while (angleRad < -M_PI) angleRad += 2*M_PI; 

    } // else we don't need to change it
    return angleRad;
  }

  /**
   * \brief Converts an angle (in radians) to the range \f$[0,2\pi]\f$
   *
   * \param[in] angleRad The angle to re-limit
   * \return The angle in the range \f$[0, 2 \pi)\f$ in radians
   */
  inline double angleLimit2PI( double angleRad ) {


    // if the angle is large (quicker to check exponent on the floating
    // point value than using fabs), then use remainder
    int angleFPexp = ilogb( angleRad );
    if( angleFPexp > 4 ){ // exp > 4
      double a = remainder(angleRad,2*M_PI); 
      if( a < 0)
	a += 2*M_PI;
      angleRad = a;
    } else if ( angleRad < 0 ) { // negative angles
      while (angleRad < 0) angleRad += 2*M_PI;
    } else if ( angleFPexp > 0 ) { // positive angles
      // float exponent is pretty small, so don't expect many loops here

      // this is faster when angles are not too far from 0
      while (angleRad >= 2*M_PI) angleRad -= 2*M_PI;
    }
    return angleRad;
  }

  /** \brief Convert and angle in degrees to radians */
  inline double  deg2Rad(double a) { return (M_PI*(a)/180.0); }
  /** \brief Convert and angle in radians to degrees */
  inline double  rad2Deg(double a) { return (180.0*(a)*M_1_PI); }



  /// @}

}; // end namespace SMALL

#endif /* _SMALL__LINALG_HH_ */


