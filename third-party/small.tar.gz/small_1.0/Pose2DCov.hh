/** 
 * \file Pose2DCov.hh
 * \brief Covariances of Poses in 2D.
 *
 * \author Mike Bosse
 * \date Aug 2007
 * \version $Revision $ 
 * 
 * Copyright (c) 2007-2011 CSIRO Autonomous Systems Laboratory
 * 
 */

/***********************************************************
 *
 *
 * This file is part of SMALL.
 *
 *  SMALL is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SMALL is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with SMALL.  If not, see <http://www.gnu.org/licenses/>.
 *
 ************************************************************/

#ifndef _SMALL__POSE_2D_COV_HH_
#define _SMALL__POSE_2D_COV_HH_

/* Standard includes */
#include <iostream>
#include <cmath>
#include <cassert>
#include <vector>

/* ASL includes */
#include "linalg.hh"
#include "Pose2D.hh"

/** \namespace SMALL 
 * \brief Spatial Math And LinAlg Library
 **/
namespace SMALL
{

  /**
   * \class Pose2DCov
   *
   * \brief Implements the covariance of the 3 degrees of freedom in a
   * 2D pose (two positional and one orientation value).
   *
   * The class does not ensure that the covariance matrices are always
   * positive semi-definite.  This will be up to the user to maintain.
   **/
  class Pose2DCov {

  private:
    Matrix33 Cov;

  public:

    /** \name Pose2DCov Constructors */
    /// @{
    /** \brief Initialize with zero covariance */
    Pose2DCov ( void ) { Cov.zero(); }

    /** \brief Initialize given covariance matrix elements
     * 
     * The implied matrix should be positive semi-definite
     **/
    Pose2DCov ( double Cxx, double Cxy, double Cyy, double Cxt, double Cyt, double Ctt)
    { setCov(Cxx,Cxy,Cyy,Cxt,Cyt,Ctt); }

    /** \brief Initialize given diagonal covariance matrix elements 
     *
     * The diagonal elements should be non-negative.
     **/
    Pose2DCov ( double Cxx, double Cyy, double Ctt)
    { setCov(Cxx,0.0,Cyy,0.0,0.0,Ctt); }

    /** \brief Initialize given a symmetric covariance matrix 
     *
     * \note Uses only the upper triangle part of the Matrix
     * \param m A positive semi-definite Matrix
     **/
    Pose2DCov ( const Matrix33 &m )
    { setCov(m); }

    /// @}
  

    /** \name Pose2DCov Access and conversion
     * Pose Covariance access and conversion. 
     */

    /// @{
    /** \brief Get XX component of covariance
     *  \return XX */
    double getXX( void ) const { return Cov[0][0]; }
    /** \brief Get XY component of covariance
     *  \return XY */
    double getXY( void ) const { return Cov[0][1]; }
    /** \brief Get YY component of covariance
     *  \return YY */
    double getYY( void ) const { return Cov[1][1]; }
    /** \brief Get XT component of covariance
     *  \return XT */
    double getXT( void ) const { return Cov[0][2]; }
    /** \brief Get YT component of covariance
     *  \return YT */
    double getYT( void ) const { return Cov[1][2]; }
    /** \brief Get TT component of covariance
     *  \return TT */
    double getTT( void ) const { return Cov[2][2]; }

    /** \brief Get the full 3x3 covariance matrix
     * return The 3x3 covariance matrix
     */
    const Matrix33 &getCov( void ) const { return Cov; }

    /** \brief Operator for 1-based covariance matrix indexing
     */    
    double operator()(unsigned int i, unsigned int j) const
    {
      return Cov(i,j);
    }


    /** \brief Get the magnitude of the covariance
     *  \return determinant of the covariance matrix */
    double getNorm( void ) const { return Cov.determinant(); }

    /// @}

    /** \name Pose2DCov Assignment and conversion 
     * Set pose using a variety of representations. 
     */
    /// @{

    /** \brief Set the covariance from a list of elements. 
     * 
     * The implied matrix should be positive semi-definite.
     **/
    Pose2DCov &setCov( double Cxx, double Cxy, double Cyy, double Cxt, double Cyt, double Ctt) {
      Cov = 
        Cxx,Cxy,Cxt,
        Cxy,Cyy,Cyt,
        Cxt,Cyt,Ctt;
      return *this;
    }
    /** \brief Set the diagonal elements of a covariance. 
     *
     * The diagonal elements should be non-negative. <br>
     * Other elements are set to zero.
     *
     **/
    Pose2DCov &setCov( double Cxx, double Cyy, double Ctt) {
      Cov = 
        Cxx,0.0,0.0,
        0.0,Cyy,0.0,
        0.0,0.0,Ctt;
      return *this;
    }

    /** \brief Set the covariance from a symmetric covariance Matrix.
     * 
     * \note Uses only the upper triangle part of the Matrix
     * \param m A positive semi-definite Matrix
     **/
    Pose2DCov &setCov( const Matrix33 &m) {
      Cov = 
        m[0][0],m[0][1],m[0][2],
        m[0][1],m[1][1],m[1][2],
        m[0][2],m[1][2],m[2][2];
      return *this;
    }
    
    /** \brief Set the covariance to zero. */
    Pose2DCov &zero() {
      Cov.zero();
      return *this;
    }

    /// @}

    /** \brief Compute the normalized residual of a Pose2D
     *
     * \return \f$ \delta^T \Sigma^{-1} \delta \f$
     */
    double normalizedResidual(const Pose2D &delta) const
    {
      Vector3D res; res = delta.getX(), delta.getY(), delta.getThetaRad();
      /// \todo cache the inverse for more efficient processing
      double nres2 = res.dot( Cov.inverse()*res );
      return nres2;
    }

    /** \brief Compute the covariance transformed by a Jacobian matrix.
     * \return The transformed covariance \f$ J \Sigma J^T \f$
     */
    Pose2DCov transformed(const Matrix33 &J) const {
      return Pose2DCov( J*this->Cov*J.transposed() );
    }

    /** \brief Compute the covariance transformed by the coordinate transform represented by a Pose2D
     *
     * Given a covariance in frame B, transform the covariance to frame A through the transformation
     * defined by Pose2D Tab.
     * \returns The transformed covariance
     */
    Pose2DCov transformed(const Pose2D &Tab) const {
      return transformed(Tab.JMdMi());
    }

    /** \brief Add two covariances
     *
     * The covariances are added element-wise.
     *
     * \warning This does not ensure that the resulting matrix is
     * positive semi-definite (<i>i.e.</i>, if B is not a valid
     * covariance).
     * \return A new Pose2DCov object containing the sum
     **/
    Pose2DCov operator+(const Pose2DCov &B) const
    {
      return Pose2DCov(Cov + B.Cov);
    }
    /** \brief Subtract two covariances
     *
     * The covariances are subtracted element-wise.
     *
     * \warning This does not ensure that the resulting matrix is
     * positive semi-definite.
     * \return A new Pose2DCov object containing the difference
     **/
    Pose2DCov operator-(const Pose2DCov &B) const
    {
      return Pose2DCov(Cov - B.Cov);
    }
     
    /** \brief Add the information of two covariances
     *
     * C = (A^-1 + B^-1)^-1
     *
     * \warning This does not ensure that the resulting matrix is
     * positive semi-definite.
     * \return A new Pose2DCov object containing the fusion
     **/
    Pose2DCov operator|(const Pose2DCov &B) const
    {
      Matrix33 iA = Cov.inverse();
      Matrix33 iB = B.Cov.inverse();
      Matrix33 iC = iA+iB;
      return Pose2DCov(iC.inverse());
    }

    /** \brief Return a vector of N points on the translational part of the numSigma*sigma covariance ellipse contour
     *
     * This is useful for visualization purposes.
     * \param N The number of desired points returned
     * \param vPnts A vector to store points on the ellipse
     * \param numSigma The scale factor on sigma for the contour to return, defaults to 3.0
     **/
    void getEllipse(int N, std::vector<Vector2D> &vPnts, double numSigma=3.0) const
    {
      Matrix22 Cov22;
      Matrix22 V;
      Vector2D d;
      Cov22 = this->Cov.sub<0,1,0,1>();
      Cov22.eigen(V,d);
      d(1) = numSigma*sqrt(d(1));
      d(2) = numSigma*sqrt(d(2));
      V = V*diagonalMatrix(d);
      int i;
      for (i=0; i<N; i++)
	{
	  double the = double(i)/double(N-1)*2*M_PI;
	  // generate points on a unit circle
	  Vector2D pnt;
	  pnt(1) = cos(the);
	  pnt(2) = sin(the);
	  // transform to ellipse
	  pnt = V*pnt;
	  vPnts.push_back(pnt);
	}
    }
    /** \brief Return a vector of 20 points on the translational part of the numSigma*sigma covariance ellipse
     *
     * This version is more efficient as it caches some of the intermediate data
     *
     * \param vPnts A vector to store the 20 points on the ellipse contour
     * \param numSigma The scale factor on sigma for the contour to return, defaults to 3.0
     **/
    void getEllipse(std::vector<Vector2D> &vPnts, double numSigma=3.0) const
    {     
      // This version caches the circle of 20 points used before transforming
      const int N=20;
      static Vector2D circle_pnts[N];
      static bool first_time = true;
      // initilize: generate points on a unit circle
      int i;
      if (first_time)
	{
	  first_time = false;
	  for (i=0;i<N; i++)
	    {
	      double the = double(i)/double(N-1)*2*M_PI;
	      circle_pnts[i](1) = cos(the);
	      circle_pnts[i](2) = sin(the);
	    }
	}
      // compute an eigen decomposition
      Matrix22 Cov22;
      Matrix22 V;
      Vector2D d;
      Cov22 = this->Cov.sub<0,1,0,1>();
      Cov22.eigen(V,d);
      d(1) = numSigma*sqrt(d(1));
      d(2) = numSigma*sqrt(d(2));
      V = V*diagonalMatrix(d);

      // transform the circle points by multiplying by V to get the ellipse
      for (i=0;i<N; i++)
	{
	  //double the = double(i)/double(N-1)*2*PI;
	  const Vector2D &cpnt = circle_pnts[i];
	  Vector2D pnt = V*cpnt;
	  vPnts.push_back(pnt);
	}
    }

    /** \brief Draws a random vector from the Gaussian distribution
     *  defined by the covariance with mean 0
     **/
    Pose2D getRandomDelta() const
    {
      Vector3D z,r;
      Matrix33 V; Vector3D d;
      this->getCov().eigen(V,d);
      r.fillRandomGaussian(); // fill vector from a standard Gaussian (mean=0, sigma=1)
      z = V*(diagonalMatrix(d)*r);
      return Pose2D(z(1),z(2),z(3));
    }


    /** \brief Represent the pose covariance as a string.
     *
     * \return A string containing the unique values of the covariance matrix <br>
     * <i>e.g.</i> Cxx=1.2,Cxy=0.0,Cyy=2.1,Cxt=0.2,Cyt=0.1,Ctt=0.5
     **/
    std::string toString( void ) const{
      char buf[256];
      sprintf(buf,"Cxx=%g,Cxy=%g,Cyy=%g,Cxt=%g,Cyt=%g,Ctt=%g",
              getXX(),getXY(),getYY(),getXT(),getYT(),getTT());
      return std::string(buf);
    }

    /* PRINTING */
    /** \brief Print a pose covariance to an output stream.
     *
     * <i>e.g.</i> Cxx=1.2,Cxy=0.0,Cyy=2.1,Cxt=0.2,Cyt=0.1,Ctt=0.5
     * \param os An output stream
     * \param p A pose covariance
     */
    friend std::ostream &operator<<(std::ostream &os, const Pose2DCov &p) {
      return os << p.toString();
    }

    /** \brief Parses a string to create a covariance.
     *
     * The string must have the same format output by toString() <br>
     * <i>e.g.</i> Cxx=1.2,Cxy=0.0,Cyy=2.1,Cxt=0.2,Cyt=0.1,Ctt=0.5
     **/
    bool fromString(const std::string &sData)
    {
      double Cxx,Cxy,Cyy,Cxt,Cyt,Ctt;
      int num = sscanf(sData.c_str(),"Cxx=%lg,Cxy=%lg,Cyy=%lg,Cxt=%lg,Cyt=%lg,Ctt=%lg",
                       &Cxx,&Cxy,&Cyy,&Cxt,&Cyt,&Ctt);
      if (num != 6)
        {
          return false;
        }
      setCov(Cxx,Cxy,Cyy,Cxt,Cyt,Ctt);
      return true;
    }

    /// Return the transformation that will diagonalize the covariance
    Pose2D center() const {

      // compute an eigen decomposition
      Matrix22 C;
      Vector2D c;
      double c3;
      Matrix22 R;
      Vector2D d;

      c3 = this->Cov(3,3);
      C = this->Cov.sub<0,1,0,1>() / c3;
      c = this->Cov.sub<0,1,2,2>() / c3;
      Matrix22 Cmcc = C - c*c.transposed();
      Cmcc.eigen(R,d);
      if (det(R) < 0) {
        R.column(0) = -R.column(0);
      }
      return Pose2D(stack(-c.row(1),c.row(0)),Rotation2D(R));
    }

  };  /* -- End of class Pose2DCov -- */


} // end of namespace SMALL

#endif /* _SMALL__POSE_2D_COV_HH_ */
