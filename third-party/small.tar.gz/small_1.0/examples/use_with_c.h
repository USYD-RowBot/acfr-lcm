#ifndef __USE_WITH_C_H__
#define __USE_WITH_C_H__
#ifdef  __cplusplus
extern "C" {
#endif

void SetQRPY(double r, double p, double y, double *quat);
void GetQRPY(double *quat, double *r, double *p, double *y);
void RotVecQ(double *quatC, double *vectorin, double *vectorout);

#ifdef  __cplusplus
}
#endif
#endif
