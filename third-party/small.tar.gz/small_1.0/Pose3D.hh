/** 
 * \file Pose3D.hh
 * \brief Poses in 3D.
 * A pose in three dimensions for a rigid object. A pose includes three spatial dimensions (position)
 * and three orientational dimensions (rotation) for a total of 6 DOF.
 *
 * \author Mike Bosse and Robert Zlot
 * \date July 2007
 * \version $Revision $ 
 * 
 * Copyright (c) 2007-2011  CSIRO Autonomous Systems Laboratory
 * 
 */


/***********************************************************
 *
 *
 * This file is part of SMALL.
 *
 *  SMALL is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SMALL is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with SMALL.  If not, see <http://www.gnu.org/licenses/>.
 *
 ************************************************************/

#ifndef _SMALL__POSE_3D_HH_
#define _SMALL__POSE_3D_HH_


/* Standard includes */
#include <iostream>
#include <cmath>
#include <cassert>

/* ASL includes */
#include "linalg.hh"
#include "Rotation3D.hh"
#include "Pose2D.hh"

/** \namespace SMALL 
 * \brief Spatial Math And LinAlg Library
 **/
namespace SMALL
{

  /**
   * \class Pose3D
   *
   * \brief Implements a 3D pose (three positional and three
   * orientation values)
   *
   * A pose in three dimensions for a rigid object. A pose includes three spatial dimensions (position)
   * and three orientational dimensions (rotation) for a total of 6 DOF.
   *
   * Positions are implemented in Cartesian space, and rotations may be expressed in several formats: 
   * including quaternions, roll/pitch/yaw, unit axis,angle, scaled axis-angle, and 3x3 rotation 
   * matrices.  Additionally, poses may be represented as 4x4 transformation matrices in homogeneous
   * coordinates, or 3x4 transformation matrix with the rotation matrix as the first 3x3 block and the 
   * position vector as the fourth column.
   *
   * Poses may be interpreted as the location/orientation of a rigid object, or as a coordinate
   * transform, or both. Thus they can be applied to vectors in 3-space or composed with other poses. 
   *
   **/
  class Pose3D : public Rotation3D {

  private:
    Vector3D t;

  public:

    /** \name Pose3D Constructors */
    /// @{
    /** \brief Initialize with identity pose: position 0,0,0 with identity rotation */
    Pose3D () { setIdentity(); }

    /** \brief Initialize given a position/translation and a rotation */
    Pose3D ( const Vector3D &t_, const Rotation3D &R) : Rotation3D(R), t(t_) {}  
    /** \brief Initialize given a position/translation and a rotation */
    Pose3D ( const Rotation3D &R, const Vector3D &t_) : Rotation3D(R), t(t_) {}  

    /** \brief Initialize given only a rotation (positional part is set to zero). */
    Pose3D ( const Rotation3D &R) : Rotation3D(R) { t.zero(); }  

    /** \brief Initialize given only a translation (rotation is set to identity). */
    Pose3D ( const Vector3D &t_ ) : t(t_) { Rotation3D::setIdentity(); }

    /** \brief Initialize given a 4x4 homogeneous transformation Matrix */
    Pose3D ( const Matrix44 &Rt ){
      Matrix33 R = Rt.sub<0,2,0,2>();
      setRotation(R);
      t = Rt.sub<0,2,3,3>();
    }

    /** \brief Initialize given a 3x4 transformation Matrix */
    Pose3D ( const Matrix34 &Rt ){
      Matrix33 R = Rt.sub<0,2,0,2>();
      setRotation(R);
      t = Rt.sub<0,2,3,3>();
    }

    /** \brief Initialize given a Pose2D
     *
     * This is equivalent to setting the X,Y position from the Pose2D and using its heading as a yaw angle.
     * The Z position and remaining rotation components (roll and pitch angles) are set to zero. 
     * Note that the roll,pitch,yaw angle representation is being used here for explanatory purposes only: 
     * this does not imply a requirement to use RPY.
     **/
    Pose3D ( const Pose2D &p2 ){ set(p2); }

    /// @}
  

    /* ACCESSORS (GETTING) */

    /** \name Pose3D Access and Conversion
     * Pose access and conversion to various representations. 
     */

    /// @{
    /** \brief Get positional values
     *  \return A vector containing (X,Y,Z) values */
    Vector3D getPosition() const { return t; }
    /** \brief Get X component of position
     *  \return X */
    double getX( void ) const { return t[0]; }
    /** \brief Get Y component of position
     *  \return Y */
    double getY( void ) const { return t[1]; }
    /** \brief Get Z component of position
     *  \return Z */
    double getZ( void ) const { return t[2]; }

    /** \brief Get the rotation */
    const Rotation3D &getRotation() const { return *((Rotation3D *)this); }

    /** \brief Get the pose represented as a 3x4 transformation matrix [R t] 
     * \return A 3x4 transformation Matrix with the first 3x3 submatrix the rotation 
     * Matrix, and the 4th column the 3x1 position (translation)
     **/
    Matrix34 get3x4TransformationMatrix() const {
      Matrix33 R = getRotationMatrix();
      Vector3D t = getPosition();
      return concat(R,t);
    }

    /** \brief Get the pose represented as a 4x4 homogeneous coord transformation matrix 
     *  \return A 4x4 transformation Matrix in homogeneous coordinates with the rotation 
     * Matrix the upper left 3x3 submatrix, and the position (translation) the 4th column. 
     * The fourth row is 0,0,0,1. 
     **/
    Matrix44 get4x4TransformationMatrix() const {
      Matrix<1,4,double> bottom; bottom = 0.0,0.0,0.0,1.0;
      return stack(get3x4TransformationMatrix(),bottom);
    }
   
    /** \brief Get the adjoint representation of the pose as a 6x6 transformation matrix 
     *  \return A 6x6 transformation Matrix (as the adjoint representation) in 
     * homogeneous coordinates with the rotation Matrix the upper left and lower right
     *  3x3 submatrices, the skew-symmetric form of the position (translation) multiplied 
     * by the 3x3 rotation matrix in the lower left and the 3x3 zero matrix in the upper right. 
     **/
    Matrix66 get6x6TransformationMatrix() const {
      Matrix33 R = getRotationMatrix();
      return stack(concat(R, zerosMatrix<3,3,double>()),
                   concat( SMALL::skewSymmetric(getPosition())*R, R));
    }

    /** \brief Return the pose as a screw representation
     *
     * A screw represents a transformation as a rotation about an
     * axis and a translation along that same axis.
     * Here, we use the translational and rotational velocity
     * integrated by dt in a 6 D vector, the first 3 dimensions
     * for the rotational velocity and the later 3 dimensions for
     * the translational velocity.
     * 
     * (Implements Rodrigues formula for SE(3) -> se(3))
     **/
    Vector6D getScrew() const {
      Matrix33 R = getRotationMatrix();
      Vector3D w;
      double rmag;
      getAxisAngle(w,rmag);
      if (rmag)
        {
          // rodrigues formula for SE(3) -> se(3)
          // todo: see if this can be simplified
          const Matrix33 I3 = identityMatrix<3,double>();
          Matrix33 W = skewSymmetric(w);
          Matrix33 W2 = quadSymmetric(w);
	  Matrix33 X = ((I3-R)*W)/rmag + W2;
          Vector3D tvel = X.inverse()*getPosition();
          Vector3D rvel = w*rmag;
          return stack(rvel,tvel);
        }
      else
        {
          Vector3D rvel = zerosMatrix<3,1,double>();
          Vector3D tvel = getPosition();
          return stack(rvel,tvel);
        }
    }

    /// @}

    /** \name Pose3D Assignment and Conversion 
     * Set pose using a variety of representations. 
     */
    /// @{

    /** \brief Set the pose given a position vector and a rotation. */
    Pose3D &set( const Vector3D &t, const Rotation3D &R) {this->t = t; setRotation(R); return *this; }
    /** \brief Set the pose given a position vector and a rotation. */
    Pose3D &set( const Rotation3D &R, const Vector3D &t) {this->t = t; setRotation(R); return *this; }

    /** \brief Set the X position. */
    Pose3D &setX( double X ){ t[0]=X; return *this; };
    /** \brief Set the Y position. */
    Pose3D &setY( double Y ){ t[1]=Y; return *this; };
    /** \brief Set the Z position. */
    Pose3D &setZ( double Z ){ t[2]=Z; return *this; };
    /** \brief Set the X,Y,Z position */
    Pose3D &setPosition( double X, double Y, double Z ){
      t = X,Y,Z;
      return *this;
    }
    /** \brief Set the position given a vector */
    Pose3D &setPosition( const Vector3D &t_ ) { t = t_; return *this; }

    /** \brief Set the position and rotation from a 4x4 homogeneous transform matrix */
    Pose3D &set( const Matrix44 &Rt ) {
      Matrix33 R = Rt.sub<0,2,0,2>();
      setRotation(R);
      t = Rt.sub<0,2,3,3>();
      return *this;
    }

    /** \brief Set the position and rotation from a 3x4 transform matrix (4x4 with last row implicitly 0,0,0,1) */
    Pose3D &set( const Matrix34 &Rt ) {
      Matrix33 R = Rt.sub<0,2,0,2>();
      setRotation(R);
      t = Rt.sub<0,2,3,3>();
      return *this;
    }
    

    /** \brief Set the Pose3D from a Pose2D.
     *
     * This is equivalent to setting the X,Y position from the Pose2D and using its heading as a yaw angle.
     * The Z position and remaining rotation components (roll and pitch angles) are set to zero. 
     * Note that the roll,pitch,yaw angle representation is being used here for explanatory purposes only: 
     * this does not imply a requirement to use RPY.
     **/
    Pose3D &set( const Pose2D &p2 ) {
      setPosition(p2.getX(), p2.getY(), 0.0);
      setRotation2D( p2.getRotation() );
      return *this;
    }

    /** \brief Sets the pose to the identity transformation */
    Pose3D &setIdentity() {
      Rotation3D::setIdentity();
      t.zero();
      return *this;
    }

    /** \brief Set the pose from a screw representation
     *
     * A screw represents a transformation as a rotation about an
     * axis and a translation along that same axis.
     * Here, we use the translational and rotational velocity
     * integrated by dt in a 6 D vector, the first 3 dimensions
     * for the rotational velocity and the later 3 dimensions for
     * the translational velocity.
     * 
     * (Implements Rodrigues formula for se(3) -> SE(3).)
     **/
    Pose3D &setScrew( const Vector6D &screw, double dt=1.0) {

      Vector3D w; // the rotational velocity
      Vector3D v; // the translational velocity
      screw.split(w,v);
      return setScrew(w,v,dt);
    }

    /** \brief Set the pose from a screw representation
     *
     * A screw represents a transformation as a rotation about an
     * axis and a translation along that same axis.
     * Here, we use the translational and rotational velocity
     * integrated by dt as two 3D vector, the first 3-vector
     * for the translational velocity and the second vector for
     * the rotational velocity.
     * 
     * (Implements Rodrigues formula for se(3) -> SE(3).)
     **/
    Pose3D &setScrew(Vector3D w, const Vector3D &v, double dt=1.0) { 
      double rmag = w.norm();
      w = w*(1.0/rmag);
      rmag *= dt;
      if (rmag) 
        {
          const Matrix33 I3 = identityMatrix<3,double>();
          Matrix33 W = SMALL::skewSymmetric(w);
          Matrix33 W2 = SMALL::quadSymmetric(w) - I3;
          Matrix33 R = I3 + W*sin(rmag) + W2*(1-cos(rmag));
          Matrix33 X = ((I3-R)*W + (W2 + I3)*rmag)/rmag; 
          setPosition(Vector3D(X*v*dt));
          setRotation(R);
        }
      else
        {
          Rotation3D::setIdentity();
          this->t = v*dt;
        }
      return *this;
    }
    
    /// @}
 


  public:
    /** \name Pose3D Transformations and Compositions
     *  
     *  Transform vectors between pose coordinate frames; compose and invert transformations.
     *
     *  These transformations provide the ability to transform a vector represented in
     *  the coordinate frame represented by the pose into a base frame (at the origin)
     *  or vice versa.
     *
     *  For example if the Pose3D represents a robot frame with respect to
     *  a ground frame, then the vector can be transformed from the robot
     *  frame representation to a ground frame representation.  
     *
     */
    ///@{
    /**  
     * \brief Transform a vector from the Pose3D frame to the base coordinate frame.
     *
     * \note Equivalent to operator*(x)
     *
     * \param x A vector represented in the Pose3D frame
     * \return The vector represented in the base frame
     */
    Vector3D transformFrom(const Vector3D &x) const {
      return t + rotate(x);
    }
    
    /**  
     * \brief Transform a vector from the Pose3D frame to the base coordinate frame.
     *
     * \note Equivalent to operator*(x)
     *
     * \param screw A 6D vector represented in the Pose3D frame
     * \return The vector represented in the base frame
     */
    Vector6D transformFrom(const Vector6D &screw) const {
      Vector3D w; // the rotational velocity
      Vector3D v; // the translational velocity
      screw.split(w,v);
      
      w = rotate(w);
      v = cross(this->t,w)+rotate(v);
     
      return stack(w,v);
    }

    /** \brief Transform a vector from the Pose3D frame to the base coordinate frame.
     *
     * \note Equivalent to transformFrom(x)
     *
     * \param x A vector represented in the Pose3D frame
     * \return The vector represented in the base frame
     */
    Vector3D operator*(const Vector3D &x) const { return transformFrom(x); }

     /** \brief Transform a vector from the Pose3D frame to the base coordinate frame.
     *
     * \note Equivalent to transformFrom(x)
     *
     * \param x A vector represented in the Pose3D frame
     * \return The vector represented in the base frame
     */
    Vector6D operator*(const Vector6D &x) const { return transformFrom(x); }

    /**    
     * \brief Transform a vector from the Pose3D frame to the base coordinate frame.
     *
     * \details The coordinates are given in the Pose3D frame and overwritten to be
     * in the base frame.
     *
     * \param x X-coordinate 
     * \param y Y-coordinate
     * \param z Z-coordinate 
     */
    void transformFrom(double &x, double &y, double &z) {
      Vector3D v; v = x,y,z;
      Vector3D vt = transformFrom(v);
      x = vt[0]; y = vt[1]; z = vt[2];
    }

    /** \brief Transform a vector from the base coordinate frame to the Pose3D frame. 
     *  \note Same as inverse().transformFrom()
     *
     *  \param x A vector represented in the base frame
     *  \return The vector represented in the Pose3D frame
     */
    Vector3D transformTo(const Vector3D &x) const { return inverse().transformFrom(x); }
    
    /** \brief Transform a screw from the base coordinate frame to the Pose3D frame. 
     *  \note Same as inverse().transformFrom()
     *
     *  \param x A screw (as a 6D vector) represented in the base frame
     *  \return The screw (as a 6D vector) represented in the Pose3D frame
     */
    Vector6D transformTo(const Vector6D &x) const { return inverse().transformFrom(x); }

    /** \brief Transform a vector from the base coordinate frame to the Pose3D frame. 
     *  \note Same as inverse().transformFrom()
     *
     * \details The coordinates are given in the base frame and overwritten to be
     * in the Pose3D frame.
     *
     * \param x X-coordinate
     * \param y Y-coordinate
     * \param z Z-coordinate 
     */
    void transformTo(double &x, double &y, double &z) {
      inverse().transformFrom(x,y,z);
    }

    /** \brief Composes two poses (transformations).  
     * 
     * For example, if the Pose3D A represents a body frame with respect to
     * a ground frame, and the Pose3D B represents a sensor frame with
     * respect to the body frame, then A.compose(B) represents the
     * the sensor frame with respect to the ground frame. 
     *
     * \note Equivalent to operator*(B)
     *
     * \param B The Pose3D to compose with in the body frame
     * \return The composite pose 
     */
    Pose3D compose(const Pose3D &B) const { 
      return Pose3D(transformFrom(B.t), Rotation3D::compose(B.getRotation()));
    }
    /** \brief Composes two poses (transformations).  
     * 
     * For example, if the Pose3D A represents a body frame with respect to
     * a ground frame, and the Pose3D B represents a sensor frame with
     * respect to the body frame, then A.compose(B) represents the
     * the sensor frame with respect to the ground frame. 
     *
     * \note Equivalent to compose(B)
     *
     * \param B The Pose3D to compose with in the body frame
     * \return The composite pose 
     */
    Pose3D operator*(const Pose3D &B) const { return this->compose(B); }
  
    /** \brief Invert a pose (transformation).
     * 
     * For example, if the Pose3D A represents a body frame with respect to
     * a ground frame, and the A.inverse() Pose3D represents the ground frame with
     * respect to the body frame.
     *
     * \note Equivalent to A.i()
     *
     * \return The inverse pose */
    Pose3D inverse() const {
      Rotation3D Ri = getRotation().inverse();
      return Pose3D( Ri.rotate(-t), Ri);
    }
  
    /** \brief Invert a pose (transformation).
     * 
     * For example, if the Pose3D A represents a body frame with respect to
     * a ground frame, and the A.inverse() Pose3D  represents the ground frame with
     * respect to the body frame.  
     *
     * \note Equivalent to A.inverse()
     *
     * \return The inverse pose */
    Pose3D i() const { return inverse(); }
    ///@}


    /** \name Pose3D Queries */
    /// @{
    /** \brief Find the transformation required to take this pose to another pose.  
     * 
     * For example if the Pose3D A represents a body frame with respect
     * to a ground frame, and the Pose3D B represents a sensor frame
     * with respect to the ground frame, then A.delta(B) represents the
     * sensor frame with respect to the body frame.
     *
     **/
    Pose3D delta(const Pose3D &B) const {
      const Pose3D &A = *this;
      return A.i()*B;
    }

    /** \brief Test equality: position and angles must all be equal. 
     * 
     * \param B A pose to compare to
     */
    bool operator== (const Pose3D &B) const {
      const double maxError = 1e-8;
      Vector3D dt = t - B.t;
      double normt = dt.normSq();
      return (normt < maxError && (getRotation() == B.getRotation()));
    }

    /** \brief Test inequality: any of the position or angles are not equal 
     *
     * \param B A pose to compare to
     */
    bool operator!= (const Pose3D &B) const {
      return !(*this==B);
    }

    /** \brief Compute the positional distance between this pose and another pose B. 
     * \return The distance between the position represented by this pose and pose B.
     */
    double positionDistance(const Pose3D &B) const {
      return Vector3D(this->t-B.t).norm();
    }

    /** \brief Compute the positional distance between this pose and a point. 
     * \return The distance between the position represented by this pose and v.
     */
    double positionDistance(const Vector3D &v) const {
      return Vector3D(this->t-v).norm();
    }

    /** \brief Compute the square of the positional distance between this pose and another pose B.
     * \return The squared distance between the position represented by this pose and pose B.
     */
    double positionDistanceSq(const Pose3D &B) const {
      return Vector3D(this->t-B.t).normSq();
    }

    /** \brief Compute the square of the positional distance between this pose and a point.
     * \return The squared distance between the position represented by this pose and v.
     */
    double positionDistanceSq(const Vector3D &v) const {
      return Vector3D(this->t-v).normSq();
    }
    /** \brief Linear interpolation of a Pose3D 
     *
     * This interpolates the translation and rotation parts independently.
     **/
    Pose3D interp(const Pose3D &B, double alpha, const bool checkWrap=true) const {
      const Pose3D &A = *this;
      return Pose3D(A.getPosition()*(1.0-alpha)+B.getPosition()*alpha,
                    A.getRotation().interp(B.getRotation(),alpha,checkWrap));
    }

    /// @}


    /** \brief Represent the pose as a string.
     *
     * \return A string containing the Cartesian position followed by the rotation as a quaternion.
     * E.g., ([ 1.2; 3.14; 5.0; ], [ 1.0; 0.0; 0.0; 0.0; ])
     **/
    std::string toString( void ) const{
      return "(" + getPosition().toString() + ", \n " + getRotation().toString() + ")";
    }

    /* PRINTING */
    /** \brief Print a pose to an output stream.
     * The Cartesian position is printed followed by the rotation as a quaternion.
     * E.g., ([ 1.2; 3.14; 5.0; ], [ 1.0; 0.0; 0.0; 0.0; ])
     *
     * \param os An output stream
     * \param p A pose
     */
    friend std::ostream &operator<<(std::ostream &os, const Pose3D &p) {
      return os << "(" << p.getPosition() << ", " << p.getRotation() << ")";
    }


  private:
    /* These are defined to overwrite the inherited functions from Rotation3D */

    /** \brief Find the rotation required to take this orientation to 
     *  another orientation.  
     * 
     * For example if the Rotation3D A represents a body orientation with 
     * respect to a ground orientation, and the Rotation3D B represents a 
     * sensor orientation with respect to the ground orientation, then A.delta(B) 
     * represents the sensor orientation with respect to the body orientation.
     *
     * Should fail on assertion (don't compare a pose to a rotation!)
     **/
    Rotation3D delta(const Rotation3D &B) const {
      bool thisFunctionIsAvailable = false;
      assert( thisFunctionIsAvailable );
      return B; // using B to avoid compiler warning
    }

    /** \brief Equality test: reimplemented from Rotation3D class. 
     *
     * Should fail on assertion (don't compare a pose to a rotation!)
     **/
    bool operator== (const Rotation3D &B) const {
      bool thisFunctionIsAvailable = false;
      assert( thisFunctionIsAvailable );
      return false && (B == Rotation3D()); // using B to avoid compiler warning
    }
    /** \brief Inequality test: reimplemented from Rotation3D class.
     *
     * Should fail on assertion (don't compare a pose to a rotation!)
     **/
    bool operator!= (const Rotation3D &B) const {
      bool thisFunctionIsAvailable = false;
      assert( thisFunctionIsAvailable );
      return true || (B == Rotation3D()); // using B to avoid compiler warning
    }

    /** \brief Linear Interpolation: reimplemented from Rotation3D class
     *
     * Should fail on assertion (don't interpolate a pose with a rotation)
     **/
    Rotation3D interp(const Rotation3D &B, double alpha) const{
      bool thisFunctionIsAvailable = false;
      assert( thisFunctionIsAvailable );
      return Rotation3D(Rotation2D(alpha))*B; // using B,alpha to avoid compiler warning
    }
    
  };  /* -- End of class Pose3D -- */


} // end of namespace SMALL

#endif /* _SMALL__POSE_3D_HH_ */
