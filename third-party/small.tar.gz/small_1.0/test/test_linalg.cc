/** 
 * \file test_linalg.cc 
 * \brief Test linear algebra operation in linalg.hh.
 *
 * \author Mike Bosse
 * \date Aug 2007
 * \version $Revision $ 
 * 
 * Copyright (c) 2007-2011 CSIRO Autonomous Systems Laboratory
 * 
 */


/***********************************************************
 *
 *
 * This file is part of SMALL.
 *
 *  SMALL is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SMALL is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with SMALL.  If not, see <http://www.gnu.org/licenses/>.
 *
 ************************************************************/

#include "linalg.hh"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cmath>
#include "Rotation3D.hh"
#include "Pose3D.hh"
#include <sys/time.h>

using namespace SMALL;
using namespace std;

template<int Mval, class T> 
bool test_inv(Matrix<Mval, Mval, T> m)
{
    Matrix<Mval, Mval, T> minv, mI;
    mI.setIdentity();
    minv = m.inverse();
    //cout << "test_inv: " << Mval << endl << "m: " <<  m << endl << "minv: " << minv << endl << "I?: "<< minv*m << endl;
    return (minv*m == mI);
}

/** \brief Generate an NxN covariance matrix from random N-dimensional points
    \param max_val Maximum coordinate value magnitude (default is 10)
    \param n_pts number of points to generate for computing the covariance
    \param centralize centralise the covariance about the mean?
    \return An NxN covariance matrix with the required properties
 */
template<int Mval, class T>
Matrix<Mval,Mval,T> makeCovariance(double max_val = 10.0, int n_pts = 5, bool centralize=true) {

    srand(time(NULL)); // seed random number generator

    Matrix<Mval,Mval,T> A;
    ColVector<Mval,T> pt, mu;
    A.zero();
    mu.zero();

    for(unsigned int j=0; j<n_pts; ++j)
    {
        pt.fillRandom();
        pt = (pt - 0.5)*(2*max_val); // range is [-max_val, max_val]
        mu += pt;
        A += pt*pt.transposed();
    }
    A /= n_pts;  // normalize

    if(centralize) {
        mu /= n_pts;
        A -= mu*mu.transposed(); // centralize
    }

    return A;
}

/** \brief Test the eigen method
 *  \param A the matrix to use for testing
 *  \return true if eigen vectors and eigenvalues recombine to give A
 *  \note A must be symmetric (e.g. from call to makeCovariance) */
template<int Mval, class T>
bool testEigen(Matrix<Mval,Mval,T> A)
{
    assert(A.isSymmetric());

    Matrix<Mval,Mval,T> v;     // eigenvectors of A
    ColVector<Mval,T> d;       // eigenvalues of A
    Matrix<Mval,Mval,T> sigma; // diagonal matrix containing eigenvalues of A
    Matrix<Mval,Mval,T> Aeig;  // re-combined matrix from singular values

    A.eigen(v,d); // note: calls 3x3 specialization if A is 3x3

    // check that eigen was correct using the property:
    //  A = v*sigma*v.transposed() for hermitian matrix A with v and sigma as above
    sigma = diagonalMatrix(d);
    Aeig = v*(sigma*v.transposed());

    return (A==Aeig);
}


/** \brief Test the gaussJordanElimination method (solve Ax=b for x)
 *  \param A the matrix to use for testing
 *  \param b the RHS
 *  \return true if the Ax=b. false otherwise
 */
template<int Mval, int Nval, class T>
bool testGaussJordan(Matrix<Mval,Mval,T> A, Matrix<Mval,Nval,T> b)
{
    Matrix<Mval,Nval,T> x = b.gaussJordanElimination(A);
    Matrix<Mval,Nval,T> x2 = b/A;
    return (A*x==b && x==x2);
}


int main(){
  
  srandom(time(NULL));

  Matrix<6,5,double> m65[10];
  Matrix<5,6,double> m56[10];
  Matrix<5,5,double> m55[10];
  Matrix<6,6,double> m66[10];
  Matrix33 m33[10], n33;
  Matrix22 m22;
  ColVector<5,double> v5[10];
  Vector3D v3[10];
  Vector6D v6[10];

  m65[0] = 1,2,3,4,5,
    6,7,8,9,10,
    1,2,3,4,5,
    6,7,8,9,10,
    1,2,3,4,5,
    6,7,8,9,10;

  cout << "m65[0] = " << m65[0] << endl;
  printf("m65[0] is %dx%d\n", m65[0].nrows(), m65[0].ncols() );

  m65[1].fillRandom();
  cout << "m65[1] = " << m65[1] << endl;

  m66[0] = double(5)*m66[0].setIdentity();

  m56[0] = m65[1].transposed() * m66[0];
  cout << "m56[0] = " << m56[0] << endl;

  m55[0] = m56[0]*m56[0].transposed();
  cout << "m55[0] = " << m55[0] << endl;

  v3[0] = 1,0,0;

  m33[0] = m56[0].sub<0,2,0,2>();
  cout << "m33[0] = " << m33[0] << endl;

  v3[1] = m33[0]*v3[0];
  cout << "v3[1] = " << v3[1] << endl;
  cout << "v3[0] is of size " << v3[0].size() << endl;

  for(int i=0;i<10;i++){
    v5[i].fillRandomGaussian();
    cout << v5[i] << endl;
    m65[i].fillRandomGaussian();
    v6[i] = m65[i]*v5[i];
    cout << v6[i] << endl;
    m66[i] = v6[i]*v6[i].transposed();
    m66[i] = m66[i] * m66[i];
    cout << "m66:" << m66[i] << endl;
    cout << m66[i].column(2) << endl;
    cout << m66[i].column<2>() << endl;
    cout << m66[i].transposed().row(2) << endl;
    cout << m66[i].transposed().row<2>() << endl;
    cout << m66[i].transposed().row<2>().abs() << endl;
    n33 = m33[i] = m66[i].sub<0,2,0,2>() + onesMatrix<3,3,double>();
    m33[i] = n33 + double(5)*m33[i].setIdentity();
    cout << "m33:" << m33[i] << endl;
    printf("Deteminant of m33[%d] is %g\n", i, m33[i].determinant());
    printf("Deteminant of m33[%d].abs() is %g\n", i, m33[i].abs().determinant());
    // test some inverses
    m22.fillRandomGaussian();
    assert((test_inv<2,double>(m22))); // test 2x2 specific inverse
    assert((test_inv<3,double>(m33[i]))); // test 3x3 specific inverse
    // make another m66 as above is rank deficient
    //m66[i].fillRandomGaussian(); // only a small chance of not being invertible
    //assert((test_inv<6,double>(m66[i]))); // test general inverse
  }

  //test inverse
  m66[0] = 0.39751386,  0.29504038,  0.2063067 ,  0.04136744,  0.205385, 0.99082274,
        0.06446518,  0.81476941,  0.6635975 ,  0.65424941,  0.18075292, 0.04691596,
        0.15583412,  0.28548041,  0.34704305,  0.48083554,  0.15401746, 0.75409379,
        0.71477283,  0.0055119 ,  0.88538338,  0.10577691,  0.23367652, 0.64659428,
        0.48871372,  0.81743299,  0.8681426 ,  0.28771487,  0.74690102, 0.01038426,
        0.2055806 ,  0.26527066,  0.99371668,  0.55750524,  0.9827087 , 0.39006941;
  assert((test_inv<6,double>(m66[0])));
  // inverse of above is:
  // [[-4.29550391, -4.43115029,  6.96662625,  0.44360862,  4.46513341, -2.87824895],
  //  [ 1.7382577 ,  1.51613559, -1.90879982, -0.51674092, -0.23057395, -0.04487937],
  //  [ 2.71172893,  3.63578436, -5.62929953,  1.07688045, -3.24715347,  1.85868295],
  //  [-4.48138759, -3.1988606 ,  7.14619141, -0.24500928,  2.86919129, -1.71747138],
  //  [-0.54451101, -1.76850715,  1.3436045 , -0.88125999,  1.35871689,  0.4229752 ],
  //  [ 1.95033493,  1.06940347, -1.63134236, -0.05542444, -1.44805461,  0.76512269]]




  m33[4] = m33[1]+m33[2]-m33[3];
  m33[9] = m33[0] / (m33[1]+m33[2]-m33[3]);
  cout << "m33[9] = " << m33[9] << endl;

  // Test eigen, inverse, gaussJordanElimination and operator\

  const int n_iters = 1000;
  bool OK = false;
  for(int i=0; i<n_iters; ++i) {
      // 2x2 case 
      Matrix22 cov22 = makeCovariance<2,double>(100., 10, true);
      assert(testEigen(cov22)); //- calls specialization for 2x2 matrices
      assert(test_inv(cov22));
      Matrix<2,5,double> b25;
      b25.fillRandom();
      OK = testGaussJordan<2,5,double>(cov22,b25);
      assert(OK);


      // 3x3 case
      Matrix33 cov33 = makeCovariance<3,double>(100., 10, true);
      assert(testEigen(cov33)); // - calls specialization for 3x3 matrices
      assert(test_inv(cov33));
      Matrix<3,5,double> b35;
      b35.fillRandom();
      OK = testGaussJordan<3,5,double>(cov33,b35);
      assert(OK);

      // 4x4 case
      Matrix44 cov44 = makeCovariance<4,double>(100., 10, true);
      assert(testEigen(cov44));
      assert(test_inv(cov44));
      Matrix<4,5,double> b45;
      b45.fillRandom();
      OK = testGaussJordan<4,5,double>(cov44,b45);
      assert(OK);

      // 9x9 case
      Matrix<9,9,double> cov99 = makeCovariance<9,double>(100., 10, true);
      assert(testEigen(cov99));
      assert(test_inv(cov99));
      Matrix<9,5,double> b95;
      b95.fillRandom();
      OK = testGaussJordan<9,5,double>(cov99,b95);
      assert(OK);
}

  
  m66[0] = m33[0].stack(m33[1]).concat(m33[2].stack(m33[3]));
  cout << m33[0] << endl;
  cout << m33[1] << endl;
  cout << m33[2] << endl;
  cout << m33[3] << endl;
  cout << "m66 " << m66[0] << endl;

  Matrix<6,3,double> tmp1, tmp2;
  m66[0].split(tmp1,tmp2);
  tmp1.split(m33[4],m33[5]);
  tmp2.split(m33[6],m33[7]);

  cout << m33[0] << endl;
  cout << m33[4] << endl;
  cout << m33[1] << endl;
  cout << m33[5] << endl;
  cout << m33[2] << endl;
  cout << m33[6] << endl;
  cout << m33[3] << endl;
  cout << m33[7] << endl;
  
  cout << "m33[7].trace = " << m33[7].trace() << endl;
  
#if 0
  for (double a=-20*M_PI; a<20.1*M_PI; a+=M_PI/4){
    printf("angle %.2f is %.2f\n", a, angleLimitPI(a));
  }
#endif

  double mArr[9];
  m33[7].copyToArray(mArr);
  printf("Matrix as an array: ");
  for(int i=0;i<9;i++){
    printf("%.2f ", mArr[i]);
  }
  printf("\n");

  cout << "m65[2] " << m65[2] << endl;
  double mArr65[30];
  m65[2].copyToArray(mArr65);
  printf("Matrix as an array: ");
  for(int i=0;i<30;i++){
    printf("%.2f ", mArr65[i]);
  }
  printf("\n");

  Vector3D a,b,c,d;
  a = 2.0,3.0,4.0;
  b = 1.0, 1.0, 1.0;
  c = 5.0,6.0,1.0;
  d = a-b;

  printf("Distance between a and b is %g\n", dist(a,b));
  printf("Distance between b and a is %g\n", dist(b,a));
  printf("Distance between b and c is %g\n", dist(b,c));

  for (double a=-20*M_PI; a<20.1*M_PI; a+=M_PI/3.251){
    double b = angleLimitPI(a);
    double d = (a-b)/(2*M_PI);
    double f = d-round(d);
    printf("angle %g is %g   ", a, b);
    printf("   exp is %d   " , ilogb(a) );
    printf("   diff is %g\n", f);
    assert( fabs (f) < 1e-4 );
    assert( fabs(b) <= M_PI );
  }

  for (double a=-20*M_PI; a<20.1*M_PI; a+=M_PI/4){
    double b = angleLimit2PI(a);
    double d = (a-b)/(2*M_PI);
    double f = d-round(d);
    printf("angle %g is %g   ", a, b);
    printf("   exp is %d   " , ilogb(a) );
    printf("   diff is %g\n", f);
    assert( fabs (f) < 1e-4 );
    assert( b < 2*M_PI && b >= 0 );
  }
  double ang = 2*M_PI;
  double al2pi = angleLimit2PI(ang);
  printf("al2PI = %g\n", al2pi);
  assert( fabs(al2pi) < 1e-4 );


  for( double n=-5.00001;n<5;n+=0.1 ){
    printf(" n=%g \t exp=%d\n", n, ilogb(n) );
  }

  // test double == and !=
  Vector3D ev1, ev2, ev3, ev4, ev5, ev6;
  ev1 = 3.2,4.1,5.5;
  ev2 = 3.2,4.1,5.5;
  ev3 = 3.2001,4.1,5.5;
  ev4 = 3.2,4.1,5.50000001;
  ev5 = -2.2,100.3,-97.1;
  ev6 = -2.2,100.3,-97.10000000714;
  assert (ev1==ev2);
  assert (ev2==ev1);
  assert (ev1!=ev3);
  assert (ev3!=ev1);
  assert (ev1!=ev4);
  assert (ev4!=ev1);
  assert (ev3!=ev4);
  assert (ev4!=ev3);
  assert (ev5==ev6);
  assert (ev6==ev5);
  assert (ev1!=ev6);

  // test integer == and !=
  ColVector<3,int> evi1,evi2,evi3;
  evi1 = 3,2,8;
  evi2 = 3,3,8;
  evi3 = 3,2,8;
  assert(evi1!=evi2);
  assert(evi2!=evi1);
  assert(evi1==evi3);
  assert(evi3==evi1);


  Vector3D threeVec;
  threeVec = 1.0,2.0,3.0;
  
  Matrix<3,3,double> mid = identityMatrix<3,double>()*5;
  std::cout << mid << std::endl;
  
  std::cout << mid*onesMatrix<3,3,double>() << std::endl;

  assert( (threeVec.transposed()*threeVec)[0][0] == Scalar(threeVec.transposed()*threeVec) );
  assert( (threeVec.transposed()*mid*threeVec)[0][0] == Scalar(threeVec.transposed()*mid*threeVec) );
  
  return 0;
}
