/** 
 * \file test_pose3d 
 * \brief test SMALL::Poses3D
 *
 * \author Mike Bosse
 * \date Aug 2007
 * \version $Revision $ 
 * 
 * Copyright (c) 2007-2011 CSIRO Autonomous Systems Laboratory
 * 
 */


/***********************************************************
 *
 * This file is part of SMALL.
 *
 *  SMALL is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SMALL is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with SMALL.  If not, see <http://www.gnu.org/licenses/>.
 *
 ************************************************************/

#include "Pose3D.hh"
#include "Pose2D.hh"
#include "Pose2DCov.hh"

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

using namespace SMALL;

using namespace std;

#define TEST(condition) {num_tests++; if (condition) { err++; fprintf(stderr,"%s:%d: error: [%s]\n", __FILE__,__LINE__, #condition); }}

int main(int argc, char **argv)
{
  int err = 0;
  int num_tests = 0;

  Rotation3D q0;

  Rotation3D q1; q1.setIdentity();

  Rotation3D q2 = q1.inverse();

  Rotation3D q3 = q1*q2;
  
  TEST(q3 != q0);
  
  q3 = q2*q1;

  TEST(q3 != q0);

  Rotation3D q4; q4.setRollPitchYawRad(deg2Rad(0),deg2Rad(40),deg2Rad(30));
  Rotation3D q5; q5.setRollPitchYawRad(deg2Rad(180),deg2Rad(180-40),deg2Rad(30-180));

  TEST(fabs(1.0-q4.getQuaternion().normSq())>1e-6);
  TEST(fabs(1.0-q5.getQuaternion().normSq())>1e-6);

  cout << "q4 = " << q4 << endl;
  cout << "q5 = " << q5 << endl;

  cout << q5.getRollRad()*180/M_PI << endl;

  TEST(fabs(q5.getRollRad()*180/M_PI-0)>1e-6);
  TEST(fabs(q5.getPitchRad()*180/M_PI-40)>1e-6);
  TEST(fabs(q5.getYawRad()*180/M_PI-30)>1e-6);
  
  TEST(q4 != q5);

  Vector3D axis; axis = 0.0,1.0,0.0;
  double angle = deg2Rad(30);
  TEST(q4.setAxisAngle(axis,angle) != q5.setAxisAngle(axis*angle));

  q4.setAxisAngle(axis,angle);
  q5.setAxisAngle(axis*(angle + 2*M_PI));
  cout << "q4 = " << q4 << endl;
  cout << "q5 = " << q5 << endl;
  cout << q4.getAxisAngle() << endl;  
  cout << axis*angle << endl;

  TEST((q4.getAxisAngle()-(axis*angle)).normSq() > 1e-8);

  Vector3D point; point = 1.0,0.0,0.0;
  Vector3D pointr = q4.rotate(point);
  cout << "pointr = " << pointr << endl;

  Matrix33 R = q4.getRotationMatrix();
  cout << "R = " << R << endl;
  Vector3D pointr2 = R*point;
  cout << "pointr2 = " << pointr2 << endl;

  TEST((pointr-pointr2).normSq()>1e-8);

  TEST(fabs(pointr[0] - cos(angle))>1e-6);
  TEST(fabs(pointr[1] - 0)>1e-8);
  TEST(fabs(pointr[2] - -sin(angle))>1e-8);

  q5.setRotation(R);
  TEST(q4 != q5);

  Vector4D q; q= rand(),rand(),rand(),rand();
  q.normalize();
  q4.setQuaternion(q);
  R = q4.getRotationMatrix();
  cout << "q = " << q4 << "\nR = " << R << endl;
  q5.setIdentity();
  
  double roll,pitch,yaw;
  q4.getRollPitchYawRad(roll,pitch,yaw);
  q5.setRollPitchYawRad(roll,pitch,yaw);
  TEST(q4 != q5);

  cout << "rpy = [" << rad2Deg(roll) << ", " << rad2Deg(pitch) << ", " << rad2Deg(yaw) << "];" << endl;

  Pose3D p1;
  Pose3D p2; p2.setIdentity();
  TEST(p1 != p2);

  double x=1.0; 
  double y=-2.0; 
  double z=3.1;
  p1.setRotation(q4);
  p1.setPosition( x, y ,z);

  cout << "p1 = " << p1.toString() << endl;

  Vector3D t; t=x,y,z;
  p2.set(t,Rotation3D(R));
  TEST(p1 != p2);

  Matrix34 Rt = concat( R, t );

  p2.set(Rt);
  TEST(p1 != p2);

  Vector6D screw = p1.getScrew();
  p2.setIdentity();
  p2.setScrew(screw);
  TEST(p1 != p2);
  cout << "p2 = " << p2 << endl; 
  cout << "screw = " << screw << endl;

  p1.setIdentity();
  p1.setScrew(screw/7.0,7.0);
  TEST(p1 != p2);

  Vector2D t2; t2 = 1.0, 2.0;
  Rotation2D r2(10*M_PI/180);
  Pose2D pp;
  Pose2D pp1(t2,r2);
 
  cout << "pp = " << pp1 << endl;

  Pose2D ppi = pp1.inverse();

  cout << "ppi = " << ppi << endl;
  TEST( ppi*pp1 != pp);

  ppi = pp.interp(pp1,0.1);

  cout << ppi << endl;

  Pose2DCov cov(1.0,1.0,M_PI/180*M_PI/180);
  Pose2DCov cov2 = cov.transformed(pp1);

  cout << "cov2 = " << cov2 << endl;

  Pose2D p( M_PI, makeVector(1,2) );

  printf("\nPose composition test\n\n");

  Vector3D vec1, vec2, vec3, pvec1, pvec2;
  Rotation3D rot1, rot2;

  vec1 = 108.0, -12.0, 4.0;
  pvec1 = 10.0,8.0,-19.2;
  pvec2 = 2.0,-1.2,8.5;
  rot1.setRollPitchYawRad(0.0,1.2,2.0);
  rot2.setRollPitchYawRad(6.0,2.2,-0.3);
  
  Pose3D pos1(rot1,pvec1), pos2(rot2,pvec2);
  Pose3D pos12 = pos1*pos2;
  
  vec2 = pos12.transformFrom(vec1);
  vec3 = pos2.transformFrom(vec1);
  vec1 = pos1.transformFrom(vec3);
  
  TEST( vec2 != vec1 );
  std::cout << vec1 << " " << vec2 << std::endl;

  Matrix66 T66 = pos2.get6x6TransformationMatrix();
  Vector6D s1 = pos1.getScrew();
  Vector6D s2 = pos2 * s1;
  Vector6D s3 = T66 * s1;
  
  std::cout << s2 << " " << s3 << std::endl;
  TEST(s2 != s3);

  {
    Pose3D pos12b(pos12.getPosition(),Rotation3D(-pos12.getQuaternion()));
    double alpha = .1;
    {
      Pose3D posi = pos1.interp(pos12,alpha);
      Pose3D posib = pos1.interp(pos12b,alpha);
      std::cout << "posi = " << posi << "posib = " << posib << std::endl;
      TEST(posi != posib);
    }
    {
      Pose3D posi = pos1.interp(pos12,alpha,false);
      Pose3D posib = pos1.interp(pos12b,alpha,false);
      std::cout << "posi = " << posi << "posib = " << posib << std::endl;
      TEST(posi == posib);
    }
  }


  fprintf(stderr,"Total errors = %d/%d\n", err,num_tests);

  return err;
}
