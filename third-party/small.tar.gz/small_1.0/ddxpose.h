/** 
 * \file ddxpose.h
 * \brief DDX store types for poses in 2 and 3 dimensions.
 *
 * \author Robert Zlot
 * \date Aug 2007
 * \version $Revision $ 
 * 
 * Copyright (c) CSIRO Autonomous Systems Laboratory
 * 
 **/
#ifndef _SMALL__DDX_POSE_H_
#define _SMALL__DDX_POSE_H_

#include <ddx.h>

/** 3D poses */
DDX_STORE_TYPE (DDX_POSE3D,
   struct {
	  double x;              /**< x-coordinate */
	  double y;              /**< y-coordinate */
	  double z;              /**< z-coordinate */
	  double quat[4];        /**< rotation as a quaternion */
   }
);


/** 2D poses */
DDX_STORE_TYPE (DDX_POSE2D,
   struct {
	  double x;              /**< x-coordinate */
	  double y;              /**< y-coordinate */
	  double th_rad;         /**< heading (theta) in radians */
   }
);

/** 2D pose covariance */
DDX_STORE_TYPE (DDX_POSE2D_COV,
   struct {
	  double xx;             /**< xx term */
	  double yy;             /**< yy term */
          double tt;             /**< tt term */       
          double xy;             /**< xy term */
          double xt;             /**< xt term */
	  double yt;             /**< yt term */
   }
);



#endif /* _SMALL__DDX_POSE_H_ */
