/** 
 * \file Rotation2D.hh
 * \brief Rotations in 2D.
 * 
 *
 * \author Mike Bosse and Robert Zlot
 * \date July 2007
 * \version $Revision $ 
 * 
 * Copyright (c) 2007-2011 CSIRO Autonomous Systems Laboratory
 * 
 */

/***********************************************************
 *
 *
 * This file is part of SMALL.
 *
 *  SMALL is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SMALL is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with SMALL.  If not, see <http://www.gnu.org/licenses/>.
 *
 ************************************************************/

#ifndef _SMALL__ROTATION2D_HH_
#define _SMALL__ROTATION2D_HH_

/* Standard includes */
#include <iostream>
#include <cmath>
#include <cstdio>
#include <vector>
#include <assert.h>

/* ASL includes */
#include "linalg.hh"

/** \namespace SMALL 
 * \brief Spatial Math And LinAlg Library
 **/
namespace SMALL
{

  /**
   * \class Rotation2D
   *
   * \brief Rotations in two dimensions. 
   * A rotation is a single angle (in radians). In addition, sines and cosines of these angles are
   * stored in order to avoid frequent recomputation of these values.
   */
  class Rotation2D 
  {
  private:
    
    double theta;
    double cosTh, sinTh;

  private: 
    /** \brief Private contructor for quick initialization that performs consistency checking  */
    Rotation2D( double t, double c, double s) 
      : theta(t), cosTh(c), sinTh(s) { assert(check()); }
    
  public: 

    /// @cond DOXYGEN_IGNORE_THIS
    /** \brief Consistency check. */
    bool check() const { 
      double dc = cos(theta)-cosTh;
      double ds = sin(theta)-sinTh;
      double err = fabs(dc)+fabs(ds);
      if ( err > 1e-5 ) {
        std::cerr << "Rotation check failed the=" << theta 
                  << " dc=" << dc 
                  << " ds=" << ds
                  << std::endl; 
        return false;
      } else return true;
    }
    /// @endcond

    // Fix the internal structure to be consistent (in case of accumulated roundoff errors)
    Rotation2D &fix() {
      cosTh = cos(theta);
      sinTh = sin(theta);
      return *this;
    }

    /** \name Constructors  */
    /// @{
    /** \brief Initialize rotation as identity (0)  */
    Rotation2D() { setIdentity(); }
    
    /** \brief Initialize from an angle (specified in radians) */
    Rotation2D( const double th) : theta(angleLimitPI(th)) { sinTh = sin(th); cosTh = cos(th); }
    
    /** \brief Initialize from a rotation matrix */
    Rotation2D( const Matrix22 &R) { setRotation(R); }

    /// @}
    
    /** \name Rotation2D Operations */
    /// @{
    
    
    /** \brief Compose two rotations.
     * \return this*B
     **/
    Rotation2D compose(const Rotation2D &B) const {
      return Rotation2D( theta + B.getThetaRad(),
                         cosTh*B.getCosTheta() - sinTh*B.getSinTheta(),
                         sinTh*B.getCosTheta() + cosTh*B.getSinTheta());
    }  
    
    /** \brief Compose two rotations (multiply by B). 
     * \return this*B
     */
    Rotation2D operator*(const Rotation2D &B) const { return compose(B); }
    // MIKE: should this be a '+'? Both? Reconsider the comments as well (this*B?)

    /** \brief Rotates a 2D vector by the Rotation2D */
    Vector2D rotate(const Vector2D &t) const
    {
      //Matrix22 R = getRotationMatrix();
      //return R*t;
      Vector2D tr;
      tr = 
        getCosTheta()*t[0] - getSinTheta()*t[1],
        getSinTheta()*t[0] + getCosTheta()*t[1];
      return tr;
    }
    /** \brief Rotates a vector by the Rotation */
    Vector2D operator*(const Vector2D &b) const { return rotate(b); }
    
    /** \brief Compute the inverse rotation */
    Rotation2D inverse() const {
      return Rotation2D( -theta, cosTh, -sinTh );
    }
    /** \brief Compute the inverse rotation (short name for formulas) */
    Rotation2D i() const {
      return this->inverse();
    }
    
    /** \brief Find the rotation required to take this orientation to 
     *  another orientation.  
     * 
     * For example if the Rotation2D A represents a body orientation with 
     * respect to a ground orientation, and the Rotation2D B represents a 
     * sensor orientation with respect to the ground orientation, then A.delta(B) 
     * represents the sensor orientation with respect to the body orientation.
     **/
    Rotation2D delta(const Rotation2D &B) const {
      const Rotation2D &A = *this;
      return A.i()*B;
    }
    /// @}
    
    /** \name Rotation2D Access and conversion 
     * Rotation access and conversion to various representations. */
    /// @{
    
    
    /** \brief Get the rotation angle (in radians) */
    double getThetaRad() const { return theta; }
    /** \brief Get the rotation angle (in degrees) */
    double getThetaDeg() const { return rad2Deg(theta); }
    /** \brief Get the sine of the rotation angle */
    double getSinTheta() const { return sinTh; }
    /** \brief Get the cosine of the rotation angle */
    double getCosTheta() const { return cosTh; }
    
    /** \brief Get the rotation as a 2x2 rotation matrix */
    Matrix22 getRotationMatrix() const {
      Matrix22 R;
      R = diagonalMatrix<2,double>(cosTh);
      R[0][1] = -sinTh;
      R[1][0] = sinTh;
      return R;
    }
    
    
    
    /** \brief linear interpolation of a rotation. 
     *
     * Computes the interpolation between this rotation and another with
     * the linear factor alpha.
     * When alpha is zero it returns this rotation, when alpha is 1.0
     * it returns the other rotation.  
     *
     * \param B The other rotation 
     * \param alpha The linear interpolant factor
     * \returns The interpolated rotation  */
    Rotation2D interp(const Rotation2D &B, double alpha) const 
    {
      const Rotation2D &A = *this;
      double angleDiff = angleLimitPI(B.getThetaRad()-A.getThetaRad());
      return Rotation2D( A.getThetaRad() + alpha*angleDiff );
    }
    
    /// @}
    
    
    /** \name Rotation2D Assignment and conversion 
     * Set the rotation using a variety of representations. */
    /// @{
    
    /** \brief Set the rotation angle (in radians)
     *
     * The rotation angle is maintained between [-pi,+pi]
     **/
    Rotation2D &setThetaRad( const double th ){
      theta = angleLimitPI(th);
      sinTh = sin(theta);
      cosTh = cos(theta);
      return *this;
    }

    /** \brief Set the rotation angle (in degrees)
     *
     * The rotation angle is maintained in radians between [-pi,+pi]
     **/
    Rotation2D &setThetaDeg( const double th ) { return setThetaRad(deg2Rad(th)); }

    /** \brief Set the rotation angle (in radians) */
    Rotation2D &setRotation( const double th ){
      return setThetaRad(th);
    }
    
    /** \brief Set from another rotation object */
    Rotation2D &setRotation(const Rotation2D &B) {
      *this = B;
      return *this;
    }
    
    /** \brief Set from a 2x2 rotation matrix */
    Rotation2D &setRotation( const Matrix22 &R )
    {
      return setThetaRad( atan2(R[1][0],R[0][0]) ); 
    }
    
    /** \brief Set to be identity rotation */
    Rotation2D &setIdentity() {
      setThetaRad(0.0);
      return *this;
    }

    /** \brief Make sure that the angle is in the range \f$[ -\pi, \pi ] \f$  */
    Rotation2D &wrapAngle() {
      this->theta = angleLimitPI(this->theta);
      return *this;
    }


    /// @}
    
    /** \name Rotation2D Queries */
    /// @{
    /** \brief Equality test. 
     * \param B A rotation to compare to
     * \return true if rotations are equal, false otherwise
     *
     */
    bool operator== (const Rotation2D &B) const {
      const double maxError = 1e-8;
      return ( fabs( theta - B.getThetaRad() ) < maxError );
    }
    
    /** \brief Inequality test. 
     * \param B A rotation to compare to
     * \return true if the rotations are not equal, false otherwise */
    bool operator!= (const Rotation2D &B) const {
      return !(*this==B);
    }
    
    /// @}
    /** \brief Represent the rotation as a string **/
    std::string toString( void ) const{
      char buf[64];
      sprintf(buf,"%g", this->getThetaRad());
      return std::string(buf);
    }
    
    /** \brief Output the rotation to a output stream **/
    friend std::ostream &operator<<(std::ostream &os, const Rotation2D &r) {
      return os << r.getThetaRad();
    }
    
   
}; /* End of class Rotation2D */


} // end namespace SMALL

#endif /* _SMALL__ROTATION2D_H_ */
