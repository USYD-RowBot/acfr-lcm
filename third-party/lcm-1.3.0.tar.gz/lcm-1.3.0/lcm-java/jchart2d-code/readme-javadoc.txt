The generated Javadoc API documentation. 
Especially the description of info.monitorenter.gui.chart.Chart2D provides a quick intro. 
